"""Rebuild the index of the organisation's own files after one was added or changed.

Run in the folder the person works in:  python3 <this skill's folder>/reindex.py
It reads the top of every file in organisation/, rewrites organisation/index.md, and stops
with a message if a file lacks what the kit needs.

This is the one script that ships: build/release.py copies it into the skill package.
"""
import pathlib, re, sys

ORG = pathlib.Path.cwd() / "organisation"
NEED = ("type", "title", "description", "status")

if not ORG.is_dir():
    sys.exit("no organisation/ folder here; run this in the folder the person works in")
entries, problems = [], []
for f in sorted(ORG.glob("*.md")):
    if f.name == "index.md": continue
    head = re.match(r"\A---\n(.*?)\n---\n", f.read_text(encoding="utf-8"), re.S)
    # shortcut: reads one "key: value" per line, upgrade to a YAML parser if a value ever spans lines
    fm = {k: v.strip().strip("\"'") for k, v in re.findall(r"^(\w+):[ \t]*(.*)$", head.group(1), re.M)} if head else {}
    missing = [k for k in NEED if not fm.get(k)]
    if missing or fm["type"] != "Context" or not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*\.md", f.name):
        problems.append(f"{f.name}: " + (f"missing {', '.join(missing)}" if missing else "type must be Context and the name lowercase with hyphens"))
        continue
    entries.append(f"- [{fm['title']}]({f.name}): {fm['description']}" + (f" Use when {fm['use_when']}." if fm.get("use_when") else ""))
if problems:
    sys.exit("nothing indexed; put these right first:\n" + "\n".join(problems))
(ORG / "index.md").write_text("\n".join(["# Organisation", "", *entries]).rstrip() + "\n", encoding="utf-8")
print(f"indexed {len(entries)} file(s) in organisation/")
