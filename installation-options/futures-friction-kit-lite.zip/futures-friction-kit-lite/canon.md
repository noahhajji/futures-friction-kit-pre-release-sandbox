# canon

How CIFS thinks: principles, methods and concepts.

This file holds everything under /canon/. A bundle path such as /canon/<folder>/<name>.md is not a separate file: it is an entry below, headed by that exact path and listed by title in the index here. The path finds the entry; it is never cited.

## Index

### /canon/concepts

- [The AI-mediated framework](/canon/concepts/ai-mediated-framework.md): when the person needs to see how AI now sits between people, information and organisations, layer by layer, how agents act in their own loop, or what mediation does to a news brand.
- [Assumptions](/canon/concepts/assumptions.md): when a plan or view of the future rests on beliefs nobody has tested or said aloud, and they need surfacing and questioning.
- [Berkana two-loop model](/canon/concepts/berkana-two-loop-model.md): when a new initiative or its champion is being marginalised by the dominant system, or the person needs to see which role they and their organisation play in a transition.
- [Cognitive biases in futures thinking](/canon/concepts/cognitive-biases-in-futures-thinking.md): when a team's reading of change looks coloured by attachment to the status quo, confirmation, expertise, recent events or consensus, and the bias needs naming.
- [Communicating foresight work](/canon/concepts/communicating-foresight-work.md): when foresight findings or scenarios must reach people who were not in the process, so that they move them, convince them and bear on a decision.
- [Complicated versus complex](/canon/concepts/complicated-versus-complex.md): when the person needs to judge whether a problem can be analysed to a right answer or must be explored, and so whether forecasting or foresight fits.
- [Constructive paranoia and no-regret moves](/canon/concepts/constructive-paranoia.md): when a leader asks what to do now when the organisation's future cannot be known, or a legacy newsroom is deciding what to change first and what to protect.
- [Drivers of change](/canon/concepts/drivers-of-change.md): when someone asks what is pushing a trend along, or how to tell a driving force from the trend it shapes.
- [Embedding foresight in the organisation](/canon/concepts/embedding-foresight.md): when the person wants foresight to take root in a busy organisation, or meets leadership resistance, inertia or a lack of time for the future.
- [Emergence](/canon/concepts/emergence.md): when someone asks why the future cannot be known in advance, or how complex systems keep producing genuine novelty.
- [Emerging technologies within a wider nexus](/canon/concepts/emerging-technologies-within-a-wider-nexus.md): when a technology question is being treated on its own and needs setting against the demographic, geopolitical, trust and lifestyle shifts it interacts with.
- [Existential innovation](/canon/concepts/existential-innovation.md): when a news organisation under pressure on its survival and identity must decide whether incremental change is enough or its core purpose needs rethinking.
- [First principles](/canon/concepts/first-principles.md): when a plan starts from today's format, distribution or metrics rather than from the medium's basic value assumption, or a brief already assumes the form of the answer.
- [Forecasting](/canon/concepts/forecasting.md): when someone wants a projection or prediction, or asks when extrapolating from past data can be trusted and when it gives a false sense of knowing.
- [Foresight set-up archetypes](/canon/concepts/foresight-set-up-archetypes.md): when the person is working out where foresight sits in their organisation, who carries it, and what that set-up can and cannot reach.
- [Four responses to public scepticism of AI](/canon/concepts/four-responses-to-ai-scepticism.md): when an organisation is choosing how much generative AI to use in its journalism and whether and how to tell its public.
- [From adoption to enablement](/canon/concepts/from-adoption-to-enablement.md): when a plan assumes a rolled-out AI tool will be used, starts from guidelines rather than value, or bypasses the middle managers who would have to integrate it.
- [From foresight to strategy](/canon/concepts/from-foresight-to-strategy.md): when foresight work is done and the person must turn it into strategic choices by testing current plans, deriving new options or probing with prototypes.
- [Future-preparedness and performance](/canon/concepts/future-preparedness-and-performance.md): when someone questions whether foresight pays off, or how much foresight an organisation actually needs for its environment.
- [Futures-driven innovation model](/canon/concepts/futures-driven-innovation-model.md): when an innovation or strategic choice is being made from the present alone, without the contexts and structures that shaped today's patterns or the possible futures that could change them.
- [Futures-driven innovation](/canon/concepts/futures-driven-innovation.md): when an innovation decision should start from where today's models will fall short, and be placed deliberately on a time horizon rather than all treated as near term.
- [Futures fallacies](/canon/concepts/futures-fallacies.md): when reasoning about the future leans on straight-line projection, holding all else equal, a fixed destination, prediction or personal exemption.
- [Futures friction](/canon/concepts/futures-friction.md): when an idea feels settled by a convincing answer, a plan is judged only by today's metrics, or a team wants to test what must remain true for an idea to make sense.
- [Futures literacy](/canon/concepts/futures-literacy.md): when someone asks what it means to be capable with the future, or how people learn to hold many futures in mind.
- [How to build a good scenario](/canon/concepts/how-to-build-a-good-scenario.md): when a scenario draft needs checking for whether it is plausible, consistent, distinct, memorable, challenging and useful to decision-makers.
- [Humanistic and scientific journalism](/canon/concepts/humanistic-and-scientific-journalism.md): when a plan sits between human voice and automated scale, or a newsroom cannot say which of its work is craft and which is system.
- [Liquid content](/canon/concepts/liquid-content.md): when the person is weighing content that adapts to each user and context against fixed formats, and what that shift does to where value lies.
- [Liquid foresight](/canon/concepts/liquid-foresight.md): when someone asks how foresight itself could become a continuous, AI-supported capability inside the organisation rather than a one-off deliverable.
- [Use the liquid wisely or choose human first](/canon/concepts/liquid-or-human-first.md): when a medium must choose between personalised, AI-adapted content and content carried by clear human voices, or risks drifting into the half-hearted middle.
- [Megatrends](/canon/concepts/megatrends.md): when someone asks what counts as a megatrend, how it differs from trends and weak signals, or which long-term forces can be treated as relatively certain.
- [Organisational preparedness](/canon/concepts/organisational-preparedness.md): when the person asks whether their organisation is ready for change beyond the technology, or needs to tell incremental from radical innovation.
- [Reperception](/canon/concepts/reperception.md): when someone asks what foresight is ultimately for, or how scenarios shift people's sense of what the future could be.
- [Rewiring starts in our heads](/canon/concepts/rewiring-starts-in-our-heads.md): when a plan assumes people can question assumptions on top of daily work, or an idea was dismissed before anyone asked what the user needed.
- [Scenarios](/canon/concepts/scenarios.md): when someone asks what a scenario is and what it is for, or treats scenarios as forecasts to be judged right or wrong.
- [Scoping a foresight project](/canon/concepts/scoping-a-foresight-project.md): when a foresight project is being set up and its purpose, the decisions it should influence, realistic expectations or who to involve are not yet settled.
- [Second brains](/canon/concepts/second-brains.md): when an organisation wants to learn from what others have tried and why, or is deciding who controls shared knowledge, what can be reused and which AI systems may access it.
- [Service, not publication](/canon/concepts/service-not-publication.md): when a plan's responsibility ends at publication, measures stories produced, or begins and ends with a box where someone types a question.
- [Strategic foresight fallacies](/canon/concepts/strategic-foresight-fallacies.md): when an organisation seeks certainty from foresight, squeezes it into planning routines, or expects it to hand over a strategy by itself.
- [Strategic foresight](/canon/concepts/strategic-foresight.md): when someone asks what strategic foresight is and is not, or how it should feed strategy rather than predict.
- [The agentic information economy](/canon/concepts/the-agentic-information-economy.md): when a plan assumes articles read by people remain the unit of value, or asks what journalism is for when answers reach people through agents.
- [The CIFS foresight process](/canon/concepts/the-cifs-foresight-process.md): when the person needs to see where a piece of foresight work sits in the arc from scoping through uncertainties and scenarios to strategic action.
- [The friction field](/canon/concepts/the-friction-field.md): when a trend looks set to continue and the person needs to weigh the forces pushing it against those that slow, stop or divert it, including timing.
- [The futures cone](/canon/concepts/the-futures-cone.md): when someone confuses probable with plausible futures, or asks where foresight, forecasting, scenarios and wild cards sit in the space of futures.
- [The human-centred newsroom](/canon/concepts/the-human-centred-newsroom.md): when a plan competes on speed and volume, measures output, or recruits for shifts rather than for voice and relationships.
- [The Scoping Circle](/canon/concepts/the-scoping-circle.md): when stakeholders need to agree a foresight project's focal question, context, decisions to influence, approach and research before the work starts.
- [The story that acts](/canon/concepts/the-story-that-acts.md): when a plan optimises for attention or for intention so completely that it closes the space for judgement, surprise and stopping.
- [The three horizons of AI-mediated transformation](/canon/concepts/three-horizons-of-ai-mediated-transformation.md): when an organisation's AI work is mostly efficiency gains and the person needs to see what reorganising workflows and reshaping business models would demand.
- [Three information ecologies](/canon/concepts/three-information-ecologies.md): when a plan needs placing in the information value chain, or treats AI as another distribution shift rather than a reorganisation of how information is produced, maintained, discovered and used.
- [Three publisher positions](/canon/concepts/three-publisher-positions.md): when a publisher is deciding where it creates and captures value as AI systems mediate between its journalism and the people and organisations that use it.
- [Trends](/canon/concepts/trends.md): when someone asks what a trend is, how firmly it is grounded, or whether an observed shift will simply carry on.
- [True truth as gold](/canon/concepts/truth-as-gold.md): when the person is deciding how a news medium can make verified truth valuable, and worth paying for, as AI-made content floods and personalises information.
- [Uncertainty](/canon/concepts/uncertainty.md): when the person needs to tell risk from uncertainty, or find which high-impact, unresolved forces a plan must be prepared for.
- [Weak signals](/canon/concepts/weak-signals.md): when someone has spotted a faint early development at the fringes and needs to judge whether it could grow into a trend or fade away.
- [What tools to use when?](/canon/concepts/what-tools-to-use-when.md): when the person must choose or combine foresight tools for a given purpose and audience, pitched to challenge without seeming implausible.
- [Wild cards](/canon/concepts/wild-cards.md): when the conversation turns to low-probability, high-impact surprises that a plan cannot forecast but should be able to absorb.
- [Worldview](/canon/concepts/worldview.md): when a view of the future seems bound by an unexamined frame from the present, or one official future is crowding out others.

### /canon/methods

- [Backcasting](/canon/methods/backcasting.md): when the person has a scenario, vision or target future and needs to work out the steps back to today, and which of them lie within the organisation's control.
- [Causal layered analysis](/canon/methods/causal-layered-analysis.md): when an issue is being read only at the surface and the person needs to uncover the systemic causes, assumptions and worldviews beneath it, or build a new narrative from them.
- [Cross-impact analysis](/canon/methods/cross-impact-analysis.md): when the person has a list of drivers and needs to see how they act on one another, which shape the whole system, or whether a scenario's logic holds together.
- [Delphi method](/canon/methods/delphi-method.md): when a question about the future needs structured expert judgement, showing where experts converge, where they diverge and where genuine uncertainty remains.
- [Driver mapping](/canon/methods/driver-mapping.md): when the person has gathered signals or trends and needs to sort them into the underlying drivers of change and judge which matter most.
- [Enablers and blockers](/canon/methods/enablers-and-blockers.md): when someone is taking a trend at face value and needs to understand the forces that speed it up or hold it back, and where it might shift or break.
- [Five Whys](/canon/methods/five-whys.md): when an explanation of a product stops at because this is how the product works, or a problem's causes need following back with evidence.
- [Futures SWOT-TOWS](/canon/methods/futures-swot-tows.md): when the person has a scenario in hand and needs to turn its opportunities and threats, set against today's strengths and weaknesses, into concrete strategic initiatives.
- [Futures triangle](/canon/methods/futures-triangle.md): when the person needs a quick, shared map of what is pushing change, what is pulling towards particular futures and what history holds back, before naming the issues that matter.
- [Futures wheel](/canon/methods/futures-wheel.md): when the person needs to think through the knock-on effects of a change, development, scenario or strategy, including second-order and counterintuitive consequences.
- [Horizon and environmental scanning](/canon/methods/horizon-and-environmental-scanning.md): when the person needs to look beyond what is on their radar for early signals and driving forces in the wider environment, or to set up ongoing monitoring of change.
- [Organisational memory and contextual reuse](/canon/methods/organisational-memory-and-contextual-reuse.md): when someone says we tried that already, nobody knows why an earlier attempt was shelved, or an idea is about to be built that someone has probably built before.
- [Pace layers](/canon/methods/pace-layers.md): when the person needs to tell fast-moving change from slow, foundational change in a system and see how the layers pull on each other.
- [Pre-mortem](/canon/methods/premortem.md): when a plan is concrete enough to brief but not yet locked in, and the team needs to surface the reasons it could fail, including doubts no one has voiced.
- [Reimagine](/canon/methods/reimagine.md): when incremental improvement keeps returning the team to the same design, or a future condition changes who needs the service, how it is encountered or what creates trust.
- [Scenario development](/canon/methods/scenario-development.md): when the organisation needs a set of contrasting plausible futures to challenge its assumptions and stress-test strategy, or someone asks how to build scenarios.
- [Scenario immersion](/canon/methods/scenario-immersion.md): when scenarios exist and the person needs to work out what one future would mean for users, the competitive landscape and the organisation's strategic direction.
- [Signposting](/canon/methods/signposting.md): when the person needs to know which future is arriving and when to act, by defining indicators and trigger thresholds to monitor after foresight work.
- [The Ma brief](/canon/methods/the-ma-brief.md): when a team wants to try a story that acts on one continuing issue and needs to settle its limits before any feature list, code or prompt is written.
- [The Seven Provocations](/canon/methods/the-seven-provocations.md): when a plan or outlook rests on unexamined assumptions about the future and the person needs a light way to surface, flip and play them out.
- [Three horizons](/canon/methods/three-horizons.md): when the person needs to see how today's dominant way of working may decline as a transformed one rises, and what is transitional between them.
- [Uncertainties assessment](/canon/methods/uncertainties-assessment.md): when the person has a set of drivers or future issues and needs to know which are high impact and genuinely uncertain, the critical uncertainties to plan for.
- [Visioning (preferred future)](/canon/methods/visioning.md): when a team needs to agree on a shared preferred future and the challenges, enablers and actions that lead towards it.
- [Wind-tunnelling](/canon/methods/wind-tunnelling.md): when the person has strategic options or initiatives and needs to test them across scenarios to find no-regret moves, contingent options and big bets.

### /canon/principles

- [Strategic foresight can be applied to a broad range of organisational contexts](/canon/principles/broad-range-of-organisational-contexts.md): when someone asks what foresight is good for or whether it fits their purpose, from anticipating risks and innovation to stress-testing strategy or thought leadership.
- [Strategic foresight seeks to challenge mental models and organisational perspectives](/canon/principles/challenge-mental-models.md): when a conversation defaults to the business-as-usual future or an outdated image of it, and the person needs a reason to question the assumptions behind it.
- [Strategic foresight explores the future before considering implications for the present](/canon/principles/explore-the-future-before-the-present.md): when the person wants to start from today's situation or plan, and needs to see why foresight first explores the future and then reads the present through it.
- [Foresight and strategy are complementary parts of one process](/canon/principles/foresight-and-strategy-are-one-process.md): when someone expects foresight to deliver a strategy, or plans strategy without foresight, and needs to see how the two connect.
- [Strategic foresight should be approached as a form of collective intelligence](/canon/principles/foresight-as-collective-intelligence.md): when the person plans to do foresight alone or with a like-minded group and needs to see why diverse perspectives and dialogue are essential.
- [Strategic foresight looks beyond the traditional strategic planning time horizon](/canon/principles/look-beyond-the-planning-horizon.md): when the discussion is confined to the three-to-five-year planning horizon and the person needs a reason to look ten or more years out.
- [Strategic foresight explores plausible futures rather than making predictions](/canon/principles/plausible-futures-not-predictions.md): when someone asks what will happen or wants a forecast, and needs to understand why foresight explores plausible futures instead of predicting.
- [Applying strategic foresight in practice is not an academic exercise](/canon/principles/practice-not-academic-exercise.md): when someone doubts foresight is rigorous, or fears it is too theoretical to use, and needs to see how method and practical judgement combine.
- [The strategic foresight process is at least as important as the final outcomes](/canon/principles/process-matters-as-much-as-outcomes.md): when the person judges foresight only by its outputs and needs to see the value of the process in learning and shared understanding.
- [Strategic foresight is a systems-thinking approach to support resilient organisational futures](/canon/principles/systems-thinking-for-resilient-futures.md): when the person relies on forecasts and numbers alone and needs to see why external change, outcomes beyond the numbers and overlooked signals should shape decisions.


<!-- /canon/concepts/ai-mediated-framework.md -->

---
type: Concept
title: The AI-mediated framework
description: Humans sit at the centre of layers from AI-mediated intelligence to worldview that each shape the next, while AI agents now form their own closed loop alongside the human one.
status: stable
use_when: "the person needs to see how AI now sits between people, information and organisations, layer by layer, how agents act in their own loop, or what mediation does to a news brand"
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, section When AI-mediation becomes agentic"
  - id: root-roy-2025
    resource: "Roy, N. (December 2025), AI will rewrite the architecture of the newsroom, Nieman Journalism Lab, Predictions for Journalism 2026"
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, printed pp. 30 to 31"
---

# The AI-mediated framework

AI increasingly surrounds us as human beings. Work, information, consumption and communication are shaped by systems that filter signals, interpret context and recommend actions. In short, we become mediated by AI. CIFS designed the AI-mediated framework to illustrate this shift. It describes how humans operate within today's interconnected layers, ranging from contextual AI and hardware to foundational infrastructure and worldview. Each layer shapes the next, creating a system with AI in a constant loop.

## When mediation becomes agentic

- The 'intelligence' surrounding humans is not only becoming more contextual and embedded, but also agentic. AI agents can retrieve information, coordinate actions, and interact with other systems across their own digital systems without iterative human input.
- The framework introduces a new dynamic where AI agents begin to interact with each other directly, forming emerging agentic loops that circulate information, decisions and actions across the layers, without always requiring a human in the loop. AI is no longer only at everyone's fingertips; it is also beginning to interact in its own closed system.

## The machine-readable layer

- Alongside the internet designed primarily for human communication, a machine-readable layer is emerging where information is structured so AI systems can interpret and act upon it.
- The human-facing internet remains the landscape we know, where we publish stories, create content, design interfaces and communicate in formats created for people. At the same time a parallel environment is forming where value increasingly depends on structured data, interoperable systems and machine-readable metadata that AI systems and agents can interpret.
- Content is therefore not only written to be read by humans, but also structured to be processed, recombined and acted upon by machines.

## Augmentation and mediation

- Augmentation focuses on the individual and describes how AI enhances human capabilities by helping people analyse information, automate tasks, or generate new forms of content.
- Mediation focuses on the broader system and describes how intelligent technologies shape how information flows, how decisions are structured, and how people interact with organisations, markets and each other.
- In practice both dynamics unfold at the same time. AI augments human capabilities while simultaneously mediating the structures in which those capabilities are exercised. The result is not only more capable individuals, but organisations and societies operating within increasingly AI-mediated environments.

## The individual at the centre

- Humans move across physical, digital and quasi realms where identities, roles and participation become more fluid, being present many places at once, and being exposed to new ways of interacting with content through (several) agents, while navigating new challenges such as cognitive fatigue and growing reliance on algorithmic systems.
- Each layer of the framework both enables and constrains the others. Infrastructure shapes what can be built, technologies shape the experiences that emerge, experiences influence behaviour and expectations, and behaviour feeds back into governance, norms and societal narratives. When these layers are evolving simultaneously, change becomes systemic rather than incremental.

## Mediation seen from the newsroom

- Nikita Roy reads the same shift for news: AI is becoming the system that controls how news flows. Quoted by Mosbech, she puts it as whoever controls the aggregation of information has the power, and no news medium has that control; the result can be their gradually disappearing relevance.
- When the AI interface answers, the journalism may be seen while the brand is not, and the interface develops an editorial voice of its own, which is not the newsroom's.
- A business model built on volume cannot survive when generative AI produces effectively infinite text.
- The response Roy argues for is a rebuild around the unique value a newsroom provides rather than its legacy forms, from a content factory to a knowledge and community institution. Mosbech puts the same choice as a question: whether news media are to be content factories, or can build a new trusted layer, interfaces that people will use, also as an alternative to AI products and platforms.

## Figure: the AI-mediated framework with an agentic loop

A set of concentric rings with a sphere at the centre. From the outermost ring inward: worldview (narratives, cultural norms and values, ethics and governance; for example regulation and ethical frameworks guiding technological development), foundational infrastructure (scalable systems enabling everything in the inner layers; for example data infrastructures and simulation environments), experience-enabling technologies (physical technologies bridging digital and physical worlds; for example immersive interfaces, humanoids and physical AI), AI-mediated intelligence (AI systems personalising and adapting interactions; for example context awareness and agentic systems), and at the centre the augmented human (liquid identity, multiple representations, participatory; distributed presence across physical, digital and immersive environments). A line loops out from the ring structure and encircles a second, smaller copy of the same rings with an AI agent at its centre instead of the human. This is the agentic loop: AI agents interacting within their own system, influencing the AI-mediated layers surrounding the human. The model was developed by Sofie Hvitved and Bugge Holm Hansen, Copenhagen Institute for Futures Studies, 2025.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="ffaim" viewBox="0 0 560 352" style="display:block;width:100%;max-width:480px" role="img" aria-label="The AI-mediated framework: rings from worldview through foundational infrastructure, experience-enabling technologies and AI-mediated intelligence to the augmented human, with the agentic loop running out to the AI agents' own set of rings and back">
<style>
.ffaim text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.ffaim .b{font-weight:500;fill-opacity:.95}
.ffaim .s{font-size:10.5px}
.ffaim .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.ffaim .m{stroke-opacity:.5}
.ffaim .f{stroke-opacity:.2}
.ffaim .o{fill:#FFC7A5;stroke:#413C38;stroke-opacity:.5;stroke-width:.75}
.ffaim .x{font-size:9px}
.ffaim .c{font-size:7.2px;font-weight:500;letter-spacing:.7px;fill-opacity:.85}
.ffaim .t{stroke-width:2.2;stroke-opacity:.9}
.ffaim .u{stroke-dasharray:1 2.6}
.ffaim text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="352" rx="14" fill="#fff"/>
<path id="ffaim-1" fill="none" d="M154,208 A116,116 0 0 1 386,208"/>
<path id="ffaim-2" fill="none" d="M165,208 A105,105 0 0 0 375,208"/>
<path id="ffaim-3" fill="none" d="M187,208 A83,83 0 0 0 353,208"/>
<path id="ffaim-4" fill="none" d="M221,208 A49,49 0 0 1 319,208"/>
<path id="ffaim-5" fill="none" d="M231,208 A39,39 0 0 0 309,208"/>
<circle class="l m" cx="270" cy="208" r="110"/>
<circle class="l m" cx="270" cy="208" r="88"/>
<circle class="l m" cx="270" cy="208" r="44"/>
<circle class="o" cx="270" cy="208" r="14"/>
<circle class="l m" cx="462" cy="94" r="44"/>
<circle class="l m" cx="462" cy="94" r="34"/>
<circle class="l m" cx="462" cy="94" r="24"/>
<circle class="l m" cx="462" cy="94" r="14"/>
<circle class="o" cx="462" cy="94" r="5"/>
<path class="l t" d="M272.1,142 A66,66 0 1 0 328.9,237.8 L413.8,69.7 A54,54 0 1 1 460.3,148 Z"/>
<text x="462" y="26" class="b s" text-anchor="middle">The agentic loop</text>
<text x="462" y="160" class="x" text-anchor="middle">AI agents</text>
<text class="c" text-anchor="middle"><textPath href="#ffaim-1" startOffset="34%">WORLDVIEW</textPath></text>
<text class="c" text-anchor="middle"><textPath href="#ffaim-2" startOffset="40%">FOUNDATIONAL INFRASTRUCTURE</textPath></text>
<text class="c" text-anchor="middle"><textPath href="#ffaim-3" startOffset="58%">EXPERIENCE-ENABLING TECHNOLOGIES</textPath></text>
<text class="c" text-anchor="middle"><textPath href="#ffaim-4" startOffset="42%">AI-MEDIATED INTELLIGENCE</textPath></text>
<text class="c" text-anchor="middle"><textPath href="#ffaim-5" startOffset="50%">THE AUGMENTED HUMAN</textPath></text>
<text x="24" y="100" class="x"><tspan class="b">Narratives</tspan>, cultural norms</text>
<text x="24" y="111" class="x">and values, ethics,</text>
<text x="24" y="122" class="x">and governance.</text>
<path class="l f u" d="M142,97 H236"/>
<text x="24" y="200" class="x"><tspan class="b">Liquid identity</tspan>,</text>
<text x="24" y="211" class="x">multiple representations,</text>
<text x="24" y="222" class="x">participatory.</text>
<path class="l f u" d="M136,208 H255"/>
<text x="24" y="284" class="x"><tspan class="b">Scalable systems</tspan></text>
<text x="24" y="295" class="x">enabling everything</text>
<text x="24" y="306" class="x">in the inner layers.</text>
<path class="l f u" d="M118,290 H232"/>
<text x="402" y="190" class="x"><tspan class="b">AI systems</tspan> personalising</text>
<text x="402" y="201" class="x">and adapting interactions.</text>
<path class="l f u" d="M398,187 H318"/>
<text x="402" y="234" class="x"><tspan class="b">Physical technologies</tspan></text>
<text x="402" y="245" class="x">bridging digital and</text>
<text x="402" y="256" class="x">physical worlds.</text>
<path class="l f u" d="M398,231 H348"/>
<text class="ref" x="536" y="336" text-anchor="end">AI-mediated framework · Source: CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0.</text>
</svg>
```

<!-- /canon/concepts/assumptions.md -->

---
type: Concept
title: Assumptions
description: Beliefs taken as true without being tested shape decisions and forecasts alike, and the most dangerous are the ones nobody has said aloud.
status: stable
use_when: "a plan or view of the future rests on beliefs nobody has tested or said aloud, and they need surfacing and questioning"
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 14 and 34"
---

# Assumptions

Assumptions are the underlying beliefs and expectations that shape how we make decisions and anticipate change. They are what we take to be true, or likely to unfold in a certain way, often without being explicitly tested or questioned.

## Two kinds

- In decision-making: beliefs, expectations or perceived constraints taken as given when making choices and setting priorities.
- In forecasting: foundational premises about future conditions that guide models or predictions.

## Why they matter for foresight

- The worst assumptions are sometimes the ones left unchallenged.
- Assumptions about the future are mostly rooted in the present and in a path-dependent view of the future, often based on beliefs never thought about critically. A critical futures thinker is attentive to them because they are sometimes incorrect or misguided, frozen in time as the world has shifted around them.
- Foresight exists to question the entrenched and misguided assumptions that underpin an understanding of the future that is rarely tested or questioned explicitly, and that so remains disconnected from emerging realities.
- Everyone involved in a foresight process brings their own beliefs and assumptions about what the future holds, consciously and subconsciously, and these influence planning, decisions and actions.

<!-- /canon/concepts/berkana-two-loop-model.md -->

---
type: Concept
title: Berkana two-loop model
description: A dominant system peaks and declines while an emergent one grows from its margins, and the emergent system only becomes the next system of influence if its pioneers are named, connected, nourished and made visible.
status: draft
use_when: "a new initiative or its champion is being marginalised by the dominant system, or the person needs to see which role they and their organisation play in a transition"
sources:
  - id: ref-cifs-two-loops-slide
    resource: "CIFS, slide 'Berkana Two Loop Model', illustrated by CIFS, supplied 2026-10-29"
  - id: root-wheatley-frieze-emergence
    resource: "Wheatley, M. and Frieze, D. (2006), Using Emergence to Take Social Innovation to Scale, The Berkana Institute"
  - id: root-wheatley-frieze-walk-out
    resource: "Wheatley, M. and Frieze, D. (2011), Walk Out Walk On: A Learning Journey into Communities Daring to Live the Future Now, Berrett-Koehler"
---

# Berkana two-loop model

Margaret Wheatley and Deborah Frieze of the Berkana Institute describe how a living system changes as two loops. A dominant system rises, peaks and declines. While it declines, an emergent system begins at its margins, among people who have walked out of the dominant system to work differently, and grows until it becomes the next system of influence. The two loops overlap in time: the old system is still running while the new one forms.

## The dominant system

- Stewards keep the dominant system working well for as long as it is still needed.
- Stabilisers hold the system steady at its peak.
- Hospice workers help the dominant system die with dignity, and compost what it has learned so that the emergent system can draw on it.
- Bridge builders carry people, resources and legitimacy from the dominant system across the transition into the emergent one.

## The emergent system

- Pioneers, also called walk-outs, are the people who leave the dominant system, or work at its edge, to try something that the dominant system no longer provides.
- Networks form when pioneers find each other and share what they are doing.
- Communities of practice form when a network turns into deliberate, committed relationships in which members develop a shared practice and new knowledge.
- A system of influence has emerged when the practices of those communities become the accepted way of doing things.

## The four moves

The emergent system does not grow by itself. Those who want it to grow do four things, in order:

1. Naming: recognise the pioneers and name what they are doing, so that they and others can see it as the beginning of something.
2. Connecting: bring the pioneers into contact with each other, so that isolated efforts become a network.
3. Nourishing: give the network what it needs to become a community of practice, time, resources, attention and the chance to learn together.
4. Illuminating: make the new practice visible to the wider system, so that it can be seen, understood and taken up, and become a system of influence.

## Key things to consider

- Living systems do not scale by replicating a programme. They scale through emergence: separate local efforts become connected, and a system of influence appears from the connections, often suddenly.
- The pioneers are easy to overlook or dismiss from inside the dominant system, because what they do looks marginal by its measures. The CIFS reading of the model is that change agents on the edges need visibility and support, not marginalisation.
- Both loops need people. Stewards and hospice workers are as necessary as pioneers, and the transition fails without the bridge builders between them.

## Figure: the two loops

Two curves drawn against a dashed horizontal line. The upper curve, the dominant system, rises from the left, peaks and falls to the right, ending at a point marked death and compost. Along it sit the stewards on the rising side, the stabilisers at the peak and hospice on the falling side. The lower curve, the emergent system, begins below the line near the start of the dominant system's decline, dips, and rises steeply on the right to a point marked new system of influence. Its stages are numbered along the curve: 1 naming, 2 connecting, 3 nourishing, 4 illuminating. Pioneers are shown as scattered dots below the line at the start of the emergent curve, with an arrow to a cluster labelled networks, from which an arrow leads to a ring labelled community of practice, and from there an arrow up to the new system of influence. A dashed line labelled transition runs from hospice on the dominant curve to bridge builders near the top of the emergent one.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="fflps" viewBox="0 0 560 374" style="display:block;width:100%;max-width:480px" role="img" aria-label="The Berkana two loops: a dominant system rises and declines through stabilisers, hospice work and death or compost, while pioneers connect into networks and communities of practice that grow into a new system of influence">
<style>
.fflps text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.fflps .b{font-weight:500;fill-opacity:.95}
.fflps .s{font-size:10.5px}
.fflps .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.fflps .m{stroke-opacity:.5}
.fflps .f{stroke-opacity:.2}
.fflps .d{stroke-dasharray:2 5}
.fflps .o{fill:#FFC7A5;stroke:#413C38;stroke-opacity:.5;stroke-width:.75}
.fflps .x{font-size:9px}
.fflps text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="374" rx="14" fill="#fff"/>
<path class="l m" d="M66,141 C66,73.5 125,48.5 190,48.5 C240,48.5 285,73.5 315,141"/>
<path class="l" d="M196,161 C196,218.5 240,253.5 305,253.5 C370,253.5 420,188.5 442.5,68.5"/>
<path class="l m" d="M249.8,69.5 L257.5,67.5 L251.6,62.1"/>
<path class="l" d="M423.9,170.4 L423,162.5 L416.8,167.6"/>
<path class="l d" d="M282.5,87 H440"/>
<path class="l" d="M378,90.8 L385,87 L378,83.2"/>
<path class="l f d" d="M200,183.5 H515"/>
<circle class="l" cx="232" cy="33.5" r="3.6"/>
<path class="l" d="M227.5,46.5 V42.5 a4.5,4.5 0 0 1 9,0 V46.5"/>
<circle class="l" cx="249.5" cy="33.5" r="3.6"/>
<path class="l" d="M245,46.5 V42.5 a4.5,4.5 0 0 1 9,0 V46.5"/>
<path class="l m" d="M138.5,160 L147.5,180 M161.5,160 L166,175.5 M179,165.5 L166,175.5 M147.5,180 L166,175.5 M147.5,180 L128,184.5 M147.5,180 L145,200 M145,200 L161.5,200 M161.5,200 L181,197 M161.5,200 L171.5,212.5 M171.5,212.5 L188,220.5 M188,220.5 L204,227.5 M188,220.5 L181,227.5 M181,227.5 L191.5,248 M191.5,248 L210.5,243.5 M191.5,248 L189,267.5 M189,267.5 L206.5,267.5 M206.5,267.5 L226,267 M226,267 L242.5,267 M242.5,267 L260.5,266 M242.5,267 L253,279.5 M206.5,267.5 L216,281" style="stroke-width:.9"/>
<circle class="o" cx="138.5" cy="160" r="2.3"/>
<circle class="o" cx="161.5" cy="160" r="2.3"/>
<circle class="o" cx="179" cy="165.5" r="2.3"/>
<circle class="o" cx="147.5" cy="180" r="2.3"/>
<circle class="o" cx="166" cy="175.5" r="2.3"/>
<circle class="o" cx="128" cy="184.5" r="2.3"/>
<circle class="o" cx="145" cy="200" r="2.3"/>
<circle class="o" cx="161.5" cy="200" r="2.3"/>
<circle class="o" cx="181" cy="197" r="2.3"/>
<circle class="o" cx="171.5" cy="212.5" r="2.3"/>
<circle class="o" cx="188" cy="220.5" r="2.3"/>
<circle class="o" cx="204" cy="227.5" r="2.3"/>
<circle class="o" cx="181" cy="227.5" r="2.3"/>
<circle class="o" cx="210.5" cy="243.5" r="2.3"/>
<circle class="o" cx="191.5" cy="248" r="2.3"/>
<circle class="o" cx="189" cy="267.5" r="2.3"/>
<circle class="o" cx="206.5" cy="267.5" r="2.3"/>
<circle class="o" cx="226" cy="267" r="2.3"/>
<circle class="o" cx="242.5" cy="267" r="2.3"/>
<circle class="o" cx="260.5" cy="266" r="2.3"/>
<circle class="o" cx="253" cy="279.5" r="2.3"/>
<circle class="o" cx="216" cy="281" r="2.3"/>
<circle class="o" cx="274.5" cy="280" r="9"/>
<circle class="o" cx="292.5" cy="268.5" r="5.4"/>
<circle class="o" cx="306.5" cy="295" r="8.6"/>
<circle class="o" cx="288.5" cy="307" r="5.4"/>
<circle class="o" cx="270" cy="297" r="3.6"/>
<circle class="o" cx="282.5" cy="295" r="2.9"/>
<circle class="o" cx="298.5" cy="279.5" r="2.5"/>
<circle class="o" cx="310" cy="278.5" r="2.9"/>
<circle class="o" cx="322.5" cy="277.5" r="2.5"/>
<circle class="o" cx="329.5" cy="289.5" r="5"/>
<circle class="o" cx="347" cy="278.5" r="8.3"/>
<circle class="o" cx="364.5" cy="265" r="5.4"/>
<circle class="o" cx="382.5" cy="254.5" r="8.3"/>
<circle class="o" cx="344" cy="254.5" r="2.5"/>
<circle class="o" cx="357.5" cy="254.5" r="2.5"/>
<circle class="o" cx="351" cy="261" r="2.2"/>
<circle class="o" cx="385" cy="238.5" r="2.5"/>
<circle class="l m" cx="161.5" cy="62" r="2.6"/>
<circle class="l m" cx="180" cy="75" r="2.6"/>
<circle class="l m" cx="165" cy="82" r="2.6"/>
<circle class="l m" cx="178.5" cy="89.5" r="2.6"/>
<circle class="l m" cx="200" cy="87.5" r="2.6"/>
<circle class="l m" cx="165" cy="109.5" r="2.6"/>
<circle class="l m" cx="181.5" cy="109.5" r="2.6"/>
<circle class="l m" cx="197" cy="101.5" r="2.6"/>
<circle class="l m" cx="465.5" cy="250.5" r="2.6"/>
<circle class="l m" cx="479.5" cy="243.5" r="2.6"/>
<circle class="l m" cx="508" cy="238.5" r="2.6"/>
<circle class="l m" cx="495.5" cy="266.5" r="2.6"/>
<text x="36.5" y="28.5" class="b s">The dominant system</text>
<text x="318" y="69.5" class="b s">The transition</text>
<text x="304" y="219.5" class="b s" text-anchor="middle">The emergent</text>
<text x="304" y="230.5" class="b s" text-anchor="middle">system</text>
<text x="262" y="37.5" class="x">Stabilisers</text>
<text x="150" y="97" class="x" text-anchor="end">The pioneers</text>
<text x="284" y="120.5" class="x" text-anchor="end">Hospice work</text>
<text x="288" y="156.5" class="x">Death / compost</text>
<text x="453.5" y="80" class="x">The system</text>
<text x="453.5" y="91" class="x">of influence</text>
<text x="121" y="207" class="x" text-anchor="end">Connect pioneers</text>
<text x="121" y="218" class="x" text-anchor="end">and build networks</text>
<text x="371" y="293.5" class="x">Form communities of</text>
<text x="371" y="304.5" class="x">practice, nourish and</text>
<text x="371" y="315.5" class="x">grow in influence</text>
<text x="468.5" y="213.5" class="x">Outliers /</text>
<text x="468.5" y="224.5" class="x">edge cases</text>
<text class="ref" x="536" y="346" text-anchor="end">Two loops · Source: Wheatley, M. and Frieze, D. (2006), Using Emergence to Take Social Innovation to Scale,</text>
<text class="ref" x="536" y="358" text-anchor="end">The Berkana Institute. Modified by CIFS.</text>
</svg>
```

<!-- /canon/concepts/cognitive-biases-in-futures-thinking.md -->

---
type: Concept
title: Cognitive biases in futures thinking
description: Five biases, from status quo to groupthink, distort how people read change before any method is applied.
status: stable
use_when: "a team's reading of change looks coloured by attachment to the status quo, confirmation, expertise, recent events or consensus, and the bias needs naming"
depends_on:
  - /canon/principles/foresight-as-collective-intelligence.md
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 27 to 33"
---

# Cognitive biases in futures thinking

Biases are subconscious errors in our thinking that lead us to misinterpret information from the world around us. They are rooted in the way the brain actually works: a personal judgement that is detrimental to objectivity and rationality. Humans have a cognitive and social bias to deny change and cast reality in familiar categories, which impairs the ability to see beyond existing systems and thinking patterns. There are said to be more than 180 cognitive biases; five relate specifically to the challenge of using the future for decision-making.

- Status quo bias: "change is bad for business". Predisposes you to ignore the facts because the alternatives are not desirable for you.
- Confirmation bias: interpreting information in a way that justifies existing beliefs. Extremely strong on issues a decision-maker is emotionally invested in; we quickly form an impression and then spend most of our time confirming it instead of collecting evidence.
- The expert problem: the more expert you are in a field, the less likely you are to see solutions at the fringes, outside the framework you were taught to think in.
- Availability heuristic: over-relying on the most readily available information or recent experiences, so that recent events disproportionately shape how future developments are evaluated.
- Groupthink: "how convenient that we all think the same". A lack of diversity in decision-making leads to inferior decisions; people who look alike and think alike are more likely to reach a consensus based on uninformed and misguided thinking.

Getting diverse thinking into a process is a mindset issue more than a tools issue. Being aware of your own and your group's biases is the place to start, remembering that foresight should be approached as a form of collective intelligence: quality outcomes can only be generated and assessed through dialogue between people bringing diverse perspectives, as non-partisan as possible.

<!-- /canon/concepts/communicating-foresight-work.md -->

---
type: Concept
title: Communicating foresight work
description: Foresight only becomes impactful when its narrative reaches heart, head and hands, moving the audience, holding up to scrutiny and bearing on a decision.
status: stable
use_when: "foresight findings or scenarios must reach people who were not in the process, so that they move them, convince them and bear on a decision"
depends_on:
  - /canon/concepts/scenarios.md
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 101 and 102"
  - id: root-soif-2023
    resource: "School of International Futures (2023), Beyond Strategic Planning: A Foresight Toolkit for Decision Makers"
---

# Communicating foresight work

Communication is key to ensuring that foresight work becomes impactful, and is not merely seen as interesting. The people it is communicated to often have not had the same rich experience of the future as those who did the work, unless they were part of the process. Effective communication speaks to the heart, the head and the hands of the audience.

## Heart, head and hands

- Heart: does the narrative about the future engage emotionally? Does it excite or alarm? Does it have an 'aha' moment, and does it provide fresh perspectives?
- Head: does the narrative add up? Does it create a reason to believe? Does it stand up to highly critical examination?
- Hands: does the narrative have relevance for decision-making? Is it actionable now, or at least in the next strategy or planning cycle?

## Matching the intended users

- The articulation and presentation of scenarios depends very much on the intended users. Scenarios that stay at the level of broad generalities, lacking supporting analysis and quantification, are not very operational and are not found useful by decision-makers, though the general public may appreciate them as a taste of the future. Scenarios presented in extremely technical and formalised ways may be hard for ordinary readers to assimilate.
- For scenarios to be used effectively, participants must be convinced of the soundness, relevance and value of the process. The foundations on which scenarios are built, the structures they use and the reasoning they employ must stand up to highly critical examination. Only then is there a chance that they will contribute to decisions and actions.

<!-- /canon/concepts/complicated-versus-complex.md -->

---
type: Concept
title: Complicated versus complex
description: Complicated problems can be analysed to a right answer, complex ones must be explored, and foresight belongs to the second kind.
status: stable
use_when: "the person needs to judge whether a problem can be analysed to a right answer or must be explored, and so whether forecasting or foresight fits"
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 19 and 40"
  - id: root-cynefin-framework
    resource: "The Cynefin framework, as cited in CIFS teaching material"
---

# Complicated versus complex

Complicated systems can be figured out. Complex systems have to be explored. The distinction, drawn from the Cynefin framework, decides which kind of thinking a problem needs.

| | Clear | Complicated | Complex | Chaotic |
|---|---|---|---|---|
| Characteristics | Problems are relatively simple and well understood; cause and effect are clear | Problems can be understood and addressed with sufficient analysis and expertise; cause and effect exist but are not immediately obvious; there is a right answer, or a limited set of good answers | Problems and systems are dynamic, unpredictable and constantly changing; traditional expertise has its limits as cause and effect are not predictable or fully knowable; outcomes are emergent and only apparent in hindsight | Problems are urgent; no clear cause and effect upfront; immediate action is required to stabilise the situation |
| How to approach | Predict, or sense and respond | Expert knowledge, detailed analysis | Exploration, systems thinking, lateral thinking | Decisive action to stabilise, followed by analysis |

- Complicated problems are predictable with enough analysis; we can analyse our way out of them.
- In complex problems the system and its dynamics are constantly changing, and outcomes are emergent and only apparent in hindsight.
- Forecasting belongs to the complicated; foresight to the complex. We are getting worse at making forecasts because the world is getting more complex, not merely more complicated.

<!-- /canon/concepts/constructive-paranoia.md -->

---
type: Concept
title: Constructive paranoia and no-regret moves
description: A legacy newsroom survives a transformation it cannot map by staying alert without paralysis and making the moves it will not regret, from understanding users' intentions to automating until it hurts and launching speedboats.
status: stable
sources:
  - id: root-naij-fojo-2026-steiro
    resource: "Steiro, G. (2026), The noble art of flogging dying horses, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
use_when: a leader asks what to do now when the organisation's future cannot be known, or a legacy newsroom is deciding what to change first and what to protect
depends_on:
  - /canon/concepts/liquid-content.md
---

# Constructive paranoia and no-regret moves

Many venerable news organisations will, in all likelihood, die an undignified death, and many talented journalists may no longer be needed in an AI-mediated reality. The future of journalism is nevertheless not predetermined. Gard Steiro's image is the Titanic's bandleader: a proud institution, shaped by a strong culture that has served it well and cemented its working methods, has hit an iceberg whose extent beneath the surface nobody knows, and keeps playing. A ship that size cannot change course in a second.

## Constructive paranoia

- The most dangerous thing a media leader can do is downplay the challenges. Genuine understanding of the need for change in a legacy organisation requires brutal honesty about the weaknesses of today's journalism and products.
- Steiro trusts people who are genuinely uncertain and dare to admit it over self-appointed oracles; uncertainty builds trust in organisations of thinking people.
- The culture to aim for: always alert, never taking users' trust for granted, always looking for ways to improve, incrementally and radically, and never paralysed by uncertainty.

## No-regret moves

In a landscape with no map, look for the moves that will not be regretted whatever comes.

1. Understand what users expect. Too many newsrooms still fail to navigate by signals from their audiences. The era when audiences came simply to receive information they had neither asked for nor needed is ending; we are moving from attention to intention, and a strategy of making the products we think brilliant and hoping audiences will understand will fail. Quantitative data, and meeting users face to face.
2. Structured journalism. The article is not sick; it is stone dead as the unit around which journalism is planned and produced. Journalists need to focus on the story, not the article, and prepare for a world in which much of the value lies in atoms of journalism: quotes, images, audio, verified facts and data, readable by machines as well as humans. Some form of liquid content, but in a way that preserves editorial, ethical and professional standards.
3. Culture eats everything. A new tool or CMS will not save the media; the ability to act quickly and a culture of innovation will. Hierarchical, top-down organisations will struggle. Invest in educating staff in AI, not to use tools but to apply the technology intelligently within their own domains, and give people with the will to rethink journalism the freedom to experiment.
4. Document every workflow. What actually happens in the newsroom, how journalism is produced and quality-assured, what the secret sauce is: surprisingly often undocumented. Without it the potential of AI cannot be realised and resources cannot be reprioritised. Schibsted mapped every editorial workflow across its brands, assessing time spent, tool support, AI potential and urgency, and so knows where capacity can be freed and where to focus AI to move resources towards unique journalism.
5. Automate as much as you can. Different organisations will choose different identities, some marketed as made by humans; all will benefit from automating wherever they can. Push towards the boundary, automate until it hurts a little, because only then are the possibilities understood, and only then is the most valuable resource freed: people.
6. Double down on what AI cannot replace. Adopting AI is not the hard part; identifying the journalism one can make a living from after the shift is. It will involve the classical virtues: source networks, finding what someone is trying to hide, analysing complex issues, being out in the real world with the people served. This is about competence as much as time; there may be fewer journalists, but the best may have a brighter future than ever.
7. Trust, trust, trust. Trust will be the most important KPI. If the trust dimension is lost, convenience wins and people might as well ask a chatbot. Trust has many drivers: relevance, the willingness to correct mistakes, adherence to publicly understood ethical standards. Be more transparent about editorial decisions and dilemmas, and build ethical standards and quality control directly into the automated systems.
8. Launch speedboats. Loyal users are happy with existing products and sceptical of radical change; a potentially huge new audience expects a different experience; satisfying both at once may be impossible, and changing established products too fast loses the people paying for the transformation. VG's answer is speedboats: real products in the market, designed for the next generation of news consumers, where bold decisions can be taken without risking the trust of the main products' users. The learning is the point; what works is brought back to the mothership once there is evidence.
9. Don't get lost. When everything changes and visibility is poor, hold the compass. Journalism is about giving citizens the information they need to make informed choices, and about the people who depend on it to be heard, seen and taken seriously. That part is unlikely to be replaced by technology.

## Key things to consider

- The dream scenario is that the core mission survives: that some organisations emerge stronger, preserve their role as providers of verified information, and that audiences still see the value in someone travelling out into the world to observe and document on their behalf, with interfaces that are different, much of today's work automated, and agents visiting at least as often as humans.
- When the hull is leaking, the stupidest thing to do is sit still. Keep on playing, but find a new tune.

<!-- /canon/concepts/drivers-of-change.md -->

---
type: Concept
title: Drivers of change
description: Underlying forces that shape and amplify trends, and often cannot usefully be distinguished from the trends they drive.
status: stable
use_when: "someone asks what is pushing a trend along, or how to tell a driving force from the trend it shapes"
depends_on:
  - /canon/concepts/trends.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Vocabulary of the Future"
---

# Drivers of change / driving forces

The forces causing change by shaping and amplifying trends, increasing or decreasing their potential impact.

- Drivers are dynamic and interconnected, and include such things as shifts in attitudes and awareness, as well as economic and technological forces that influence how something spreads and grows.
- In essence, a driver is an underlying force that acts on something else, and consequently a trend can itself act as a driver when it exerts influence in other areas.
- In practice it is often impossible, and often unimportant, to distinguish between the two.

<!-- /canon/concepts/embedding-foresight.md -->

---
type: Concept
title: Embedding foresight in the organisation
description: Culture beats foresight unless it is tied to existing work, kept to simple habits and given protected time, because leaders resist it for reasons that have nothing to do with its quality.
status: stable
use_when: "the person wants foresight to take root in a busy organisation, or meets leadership resistance, inertia or a lack of time for the future"
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 137 to 140"
  - id: root-hyper-island-cycle-of-change
    resource: "Hyper Island, natural cycle of change versus expected cycle of change, as cited in CIFS teaching material"
---

# Embedding foresight in the organisation

Building confidence in working strategically with the future is not easy. There will be obstacles, and sometimes frustration: resistance to change, inertia, lack of buy-in and even red tape that gets in the way. Foresight as an organisational activity needs room to grow and time to take root, and since it is about making changes to be better prepared for the future, inertia and resistance are its enemies. It always seems there is something more urgent. You cannot talk about corporate foresight without also talking about culture, and culture beats foresight.

## Why leaders resist

- When key stakeholders understand the value of foresight they are supportive and act as a catalyst for the organisation's foresight work. When they do not buy in, they create one of the most significant barriers to effective implementation.
- Foresight may not align with their short-term incentive structures or performance goals.
- Foresight requires embracing uncertainty and ambiguity, which is challenging for leaders who prefer a predictable and controlled environment.
- In organisations that have been successful in the past, official and unofficial ways of doing things get in the way.

## The natural cycle of change

Change is expected to follow a smooth curve from the status quo to a better state. The natural cycle instead dips: the status quo, then disruption met with shock and denial, then anger and fear, before exploration brings acceptance and rebuilding brings commitment.

| Stage | Status quo | Disruption | Exploration | Rebuilding |
|---|---|---|---|---|
| Reaction | Shock, denial | Anger, fear | Acceptance | Commitment |

## Making foresight more urgent

- Not all strategic projects must be foresight projects, but most would benefit from foresight elements.
- Align foresight efforts with the broader organisational effort. Establish a natural connection between foresight and existing ways of working and work priorities; this makes it easier for people to overcome barriers to engaging.
- Promote simple habits around engaging with foresight. For most people foresight appears complex and time-consuming in a fast-paced environment with obvious day-to-day priorities. Small steps can make a big difference, and micro habits, small, simple, easy-to-implement daily or weekly behaviours, can be very powerful: start small, be consistent, and choose one or two that the team can realistically commit to.
- Prioritise carving out space and time for the future. Bringing people out of their day-to-day context helps them break out of routines and be open to prioritising important but less urgent work. Sometimes it is simply a matter of making time and space, both mentally and physically.

<!-- /canon/concepts/emergence.md -->

---
type: Concept
title: Emergence
description: Complex systems produce patterns that cannot be inferred from their parts, which is why the future can only be anticipated, not known.
status: stable
use_when: "someone asks why the future cannot be known in advance, or how complex systems keep producing genuine novelty"
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Vocabulary of the Future"
---

# Emergence

A feature of complex systems, like societies.

- New patterns, behaviours or properties arise from the interactions within the system and could not have been inferred from the individual parts alone.
- Emergence is a source of genuine novelty, and a central reason the future cannot be known in advance, only anticipated, because complex systems continually produce what was not there before.

<!-- /canon/concepts/emerging-technologies-within-a-wider-nexus.md -->

---
type: Concept
title: Emerging technologies within a wider nexus
description: Technological change can only be understood through its interaction with demographic, geopolitical, trust and lifestyle shifts that reinforce one another.
status: stable
use_when: "a technology question is being treated on its own and needs setting against the demographic, geopolitical, trust and lifestyle shifts it interacts with"
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, section Emerging technologies within a wider nexus"
---

# Emerging technologies within a wider nexus

The future of technology has never been something that can be understood through technology alone. Technological change unfolds within a world already undergoing deep, perennial societal reorganisation. Understanding the future of technology requires recognising how technological systems intersect with other structural forces like demographic change, hybrid lifestyles, work, reconfigured sovereignty, a fragmenting geopolitical landscape and shifting structures of trust.

## Interaction between shifts

- Strategic implications come from the interaction between multiple shifts unfolding at the same time, across technology, geopolitics, infrastructure, societal developments, workforce, climate and human behaviour.
- When these forces begin to reinforce one another in a complex nexus, they most profoundly change the conditions under which organisations operate, as technological and societal shifts converge to reshape value creation and competitive advantage across the economy.

## The forces in the nexus

- Lifestyles are more fluid and uneven. Work, learning and everyday life now occur within both physical and digital spaces, but access to the conditions that enable this flexibility is far from equally distributed. Not everybody can participate across societal and cultural layers.
- Demographic changes add further strain, as ageing populations in some regions and expanding youth populations in others reshape labour markets and economic expectations.
- The nature of trust may be shifting. Trust is becoming more conditional and context-specific, as people appear to rely less on formal institutions alone and more on interpersonal networks, local community members, and hyper-personalised digital communities to make sense of the world.
- The world order is becoming more fragmented, and the geopolitical landscape affects us to a greater degree. Authorities are contested, dependencies are more political, and private digital infrastructures once treated as neutral, such as cloud storage, payment systems and data centres, are now bound up with questions of sovereignty, standards and control.

## Why foresight

- Strategic foresight allows technological futures to be considered within a complex nexus of forces driving change, working from the possible futures back to today's decisions, rather than only extending current assumptions forward.

<!-- /canon/concepts/existential-innovation.md -->

---
type: Concept
title: Existential innovation
description: Existential pressure on news media is met not by incremental development but by innovating both what secures the medium's survival and the core of who it is and what it is for.
status: stable
use_when: "a news organisation under pressure on its survival and identity must decide whether incremental change is enough or its core purpose needs rethinking"
depends_on:
  - /canon/concepts/liquid-content.md
sources:
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, sections Det eksistentielle pres, De fem principper and Konklusion og anbefalinger"
---

# Existential innovation

News media stand under an existential pressure. The pressure is existential because it challenges the identity of journalism and of news media: journalists have to a large degree defined themselves through their craft, such as making articles, and may now have to find other ways to fulfil their mission. The greatest existential threat arises if the connection between news medium or journalist and user, and with it relevance and economic sustainability, breaks down. That challenges the very existence of news media and quality journalism, and with it the foundation of the democratic conversation.

The investigation behind the concept points to the necessity that the pressure is not resolved through incremental development but handled through a far more fundamental approach to innovation. Existential innovation is a way to navigate that pressure.

## Definition

The definition holds two elements.

1. Fundamental innovations that secure the continued existence of the news medium, or of the individual journalist. This can cover innovation of business model, journalism, formats, technology, organisation, distribution and much else. The focus here is largely external and concrete.
2. Innovation of existence itself: who you are as a news medium, or as a journalist, and what your purpose is. Here the existential is understood more philosophically or even psychologically, but at organisational level, as innovation of, or increased clarity about, who and what one is in the new era. It concerns the medium's innermost values, core or soul. The focus here is more internal and fundamental.

The two elements interact closely, but the second, the core, is to a large extent an at times overlooked precondition for the first, the concrete innovations, leading to successful and meaningful existential innovation.

Figure: two black crescent shapes that together form an oval. The upper field reads "Specific innovations to secure the medium's existence. Concrete, external. Technology, content and business." The lower field reads "Clarity about the core, fundamental existence. Foundation, internal. Values and mission." Between the fields an arrow points up from the core towards the innovations, and curved arrows down both sides show the opposite movement back: a mutual circuit between the two levels.

## The five principles

Five principles together support how existential innovation can be done successfully. They are operationalised so that they answer many of the challenges journalism faces, internally and externally, technologically, commercially, organisationally and journalistically. They are relevant to media managers and editors, but also to the individual journalist, to journalism education, to unions and to other actors in the media field, and can be read at the level of the organisation and at the level of the individual.

1. Know yourself.
2. Be brave: test fast and deep, and evaluate at the same speed.
3. Use the liquid wisely, or choose "human first".
4. True truth as gold: build the new self-correcting mechanisms.
5. Deeper community and broader collaboration.

Figure: five concentric circles building outwards from the core, with principle 1 innermost and principle 5 outermost.

The principles interact and play closely together. Principle 1 is a kind of core on which the following principles build.

The existential pressure on news media and journalism mirrors a similar pressure in other sectors where AI fundamentally changes the conditions, so the strategies can, with some translation, be relevant beyond the media sector.

## How the principles relate

The principles hang together but move at the same time within opposing dimensions at the level of the medium. One way to understand the differences is to place them in external and internal categories, and to distinguish their degree of speed and movement from stabilisation and anchoring.

Figure: a four-field model inside a dashed circle. The vertical axis runs from "Acceleration (movement)" at the top to "Stabilisation (anchoring)" at the bottom; the horizontal axis from "Internal focus" on the left to "External focus" on the right. Top left, internal and acceleration: principle 2, be brave. Top right, external and acceleration: principle 3, use the liquid wisely or choose human first. Bottom left, internal and stabilisation: principle 1, know yourself. Bottom right, external and stabilisation: principle 4, true truth as gold. Along the dashed circle: principle 5, deeper community and broader collaboration.

- Know yourself (1) has largely an internal focus, is conditioned by calm, and secures stabilisation.
- Be brave (2) requires acceleration, as do the concrete experiments with liquid or human-first content (3), which also have a clear external focus.
- Developing self-correcting mechanisms (4) must interact externally, otherwise the mechanisms become worthless, while playing closely together with deep change within the medium.
- Broader collaborations and deeper communities (5) lie as a ring around the four other principles, interact with both the external and the internal, and contain both movement and anchoring.

The principles are often preconditions for one another. It is often a precondition to know oneself (1) before one can throw oneself into brave experiments (2), which can then lead to liquid or human-first content (3), which in turn can hold proposals for the new self-correcting principles that become so important for journalism (4). Brave choices and bets on 3a or 3b can also ensure that news media and journalists avoid the risky middle position that the barbell strategy warns against. All parts of the four steps play closely together with the creation of deeper communities and may require broader collaborations (5).

Figure: a step model inside a dashed circle. At the bottom "1. Know yourself", with an arrow up to "2. Be brave", from which two arrows split up towards "3a. Use the liquid wisely" on the left and "3b. Human first" on the right; from both, arrows point on up to "4. True truth as gold" at the top. In the middle between the four arrows stands the word "Collapse" over a cross that marks the risky middle position. Along the dashed circle: "5. Deeper community and broader collaboration".

For some media, individual principles will be far more relevant than others, and important elements are certainly missing. But it is a beginning.

## Recommendations to news media and journalists

Explore the five principles of existential innovation.

1. How will you define your core, do colleagues and users agree with that definition, and does it perhaps require development of the core itself?
2. How will you experiment and evaluate, and do you have the courage for it?
3. How will you work with liquid content, are you moving from content containers to content as atoms, and how do you approach human-first content strategically? Are the voices clear and genuine enough to create relationships?
4. Can you build the new self-correcting mechanisms of the era? If content becomes infrastructure, verification becomes the product. Can you develop formats for that within a new solution and intelligence economy, so that truth actually becomes gold?
5. How do you position yourself in relation to creating communities and collaborations? How will you ensure that you do not merely become a content factory for the tech giants but also build direct relationships with users, and can you help build alternative layers, formats or interfaces that deliver trustworthy knowledge directly to people, even if it requires unseen collaborations and difficult compromises?

Innovation is not a technical discipline. It is an existential necessity.

<!-- /canon/concepts/first-principles.md -->

---
type: Concept
title: First principles
description: Peels a problem down to the basic assumption that cannot be reduced further and asks what you would build today without the history of the newspaper, so innovation starts from the need rather than the inherited form.
status: draft
sources:
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, printed pp. 10 to 13 and 17"
  - id: root-roy-2025
    resource: "Roy, N. (December 2025), AI will rewrite the architecture of the newsroom, Nieman Journalism Lab, Predictions for Journalism 2026"
use_when: a plan starts from today's format, distribution or metrics rather than from the medium's basic value assumption, or a brief already assumes the form of the answer
depends_on:
  - /canon/concepts/existential-innovation.md
  - /canon/concepts/assumptions.md
---

# First principles

First Principles is an approach to fundamental, or existential, innovation. It comes from ancient Greece and consists of peeling a thing down to a basic assumption that cannot be reduced further: "the first basis from which a thing is known", in Aristotle's definition. Since then it has proved one of the most effective ways to solve complicated problems and create fundamental innovation, from Gutenberg's printing press to Musk's rockets. Taking a problem apart into its smallest parts makes it far easier to make new combinations, or other changes, that create fundamental innovation.

## The questions

- What are we completely sure is true or right?
- Ask why five times of every challenge you face, as Nikita Roy puts it.
- If we started today without the history of the newspaper, the news medium or journalism, what would we build to solve users' needs?

## Why it matters now

- AI holds enormous possibilities for developing entirely new ways of being a medium. To realise them so that the result stands out and matches the medium's mission, the core value assumptions must be in place first.
- The approach can lead to the existential innovations that create the journalism or news media of the future, whatever they come to be called. If news media do not create them, others will, probably the tech giants, and that is already happening.
- Seen from the newsroom, Roy's argument runs: when the infrastructure shifts, industries must return to first principles and re-engineer themselves to meet new realities, examining what value only their newsroom can create. The challenge is rebuilding around the unique value a newsroom provides, not around legacy forms built for another era. A business model built on volume cannot survive when generative AI produces effectively infinite text. The rebuild moves the newsroom from a content factory to a knowledge and community institution, and from production-heavy workflows to always-on knowledge environments. Her account is written as a prediction for 2026.

## Letting things fall

- An important part of the approach is the will to let things fall. Perhaps today's way of publishing is not what best realises the basic value assumption. Perhaps success should be measured quite differently; page views as a metric are already strongly challenged in many places. Perhaps the output should not be articles at all, but another format. Something must die for the new to grow.
- Innovation is often doing less. It leads back to the value of cutting away and focusing; often the task is not to add something but to remove something.

## Examples

Media that have taken the approach, in Mosbech's account: Patch's hyperlocal AI newsletters, published for every local area as long as a single user wants one; a one-person cycling-sport medium that rethought entirely how that journalism is made and spread; and VG X, a publication that thinks the Norwegian VG through from scratch, as if the paper were made today with AI and technologists as its load-bearing pillars, published as its own app alongside the ordinary VG, with the fear of cannibalising the main medium set aside.

## Key things to consider

- The approach belongs with knowing yourself. Clarity about the core, who the medium is and why it exists, is what allows choices and omissions, and a clear core vision is typically not about formats, distribution or business models, which is where innovation can then unfold.
- First Principles is the broader approach; Five Whys is one technique within it.

<!-- /canon/concepts/forecasting.md -->

---
type: Concept
title: Forecasting
description: Extrapolates past and present data forward, which works only where the environment is stable and the variables are understood.
status: stable
use_when: "someone wants a projection or prediction, or asks when extrapolating from past data can be trusted and when it gives a false sense of knowing"
depends_on:
  - /canon/concepts/complicated-versus-complex.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Vocabulary of the Future"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 17 to 21"
  - id: root-taleb-2007
    resource: "Taleb, N. N. (2007), The Black Swan"
---

# Forecasting

The process of projecting future developments or conditions based on the analysis of past and present data and observations.

- It involves identifying trends, patterns and relationships within the data to make informed projections.
- Forecasting is entirely extrapolative in nature and typically assumes that an observed relationship will continue into the future.
- Forecasting is useful when trying to understand an environment that is relatively stable and where you have a good understanding of the variables in play.

## Blind forecasts

- Consider a turkey that is fed every day. Every feeding firms up its belief that being fed by friendly humans is the general rule of life, until the afternoon before the feast, when it incurs a revision of belief. This is presupposing that a sequence of events in the future will occur as it always has in the past: a blind forecast. A chart of the turkey's well-being rises steadily for a thousand days and then drops to zero. This is what non-linearity looks like.
- We are getting worse at making forecasts because the world is getting more complex, not merely more complicated. A small change in a few variables can make predictions almost impossibly complex; economists have failed to predict 148 of the past 153 recessions. Complicated problems require expert knowledge and can be analysed to a predictable answer. In complex problems cause-and-effect relationships are not predictable or fully understood, the system and its dynamics are constantly changing, and outcomes are emergent and only apparent in hindsight.

## The limits of forecasting

- Forecasting gives value in a relatively stable environment where the variables in play are well understood. As the complexity and uncertainty of the external environment grow, predetermination decreases and forecasting gives a false sense of knowing, while the value of exploring plausibility, challenging assumptions and acknowledging emergence, rises.
- No timescale can be put on this, because the decreasing power of predetermination varies from industry to industry and within one industry over time. In very long-term futures foresight too loses its grip, because there are too many unknown unknowns.
- Prediction and forecast work when patterns hold; foresight helps when they break. Foresight exists to challenge the tendency to linear thinking and to question assumptions that become misguided or obsolete as reality shifts.

## Figure: forecasting versus strategic foresight

A chart with the complexity and uncertainty of the external environment along the horizontal axis and value on the vertical. A narrow band on the left is labelled forecasting, a wider band on the right strategic foresight. One curve, predicting predetermination with the risk of a false sense of knowing, starts high and falls as complexity rises; the other, exploring plausibility while challenging assumptions and acknowledging emergence, starts low and rises. The two cross near the boundary between the bands.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="fffor" viewBox="0 0 560 284" style="display:block;width:100%;max-width:480px" role="img" aria-label="Forecasting loses value and strategic foresight gains value as the complexity and uncertainty of the external environment rise">
<style>
.fffor text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.fffor .b{font-weight:500;fill-opacity:.95}
.fffor .s{font-size:10.5px}
.fffor .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.fffor .g{fill:#413C38;fill-opacity:.08}
.fffor .x{font-size:9px}
.fffor .t{stroke-width:2.2;stroke-opacity:.9}
.fffor .p{stroke:#FFC7A5;stroke-width:2.4;stroke-opacity:1;stroke-dasharray:5 4}
</style>
<rect width="560" height="284" rx="14" fill="#fff"/>
<rect class="g" x="70" y="46" width="110" height="196"/>
<path class="l" d="M70,242 L70,34"/><path class="l" d="M72.9,39.3 L70,34 L67.1,39.3"/>
<path class="l" d="M70,242 L530,242"/><path class="l" d="M524.7,244.9 L530,242 L524.7,239.1"/>
<text x="125" y="64" class="b" text-anchor="middle">Forecasting</text>
<text x="330" y="64" class="b" text-anchor="middle">Strategic foresight</text>
<path class="l p" d="M96,70 C112,150 250,198 510,222"/>
<path class="l t" d="M96,224 C106,150 190,104 510,72"/>
<text x="504" y="96" class="s" text-anchor="end">Exploring plausibility</text>
<text x="504" y="108" class="x" text-anchor="end">(asking the right questions)</text>
<text x="504" y="190" class="s" text-anchor="end">Predicting predetermination</text>
<text x="504" y="202" class="x" text-anchor="end">(answering the questions)</text>
<text x="46" y="144" class="b s" text-anchor="middle" transform="rotate(-90 46 144)">Value</text>
<text x="60" y="232" class="x" text-anchor="middle" transform="rotate(-90 60 232)">Low</text>
<text x="60" y="58" class="x" text-anchor="middle" transform="rotate(-90 60 58)">High</text>
<text x="82" y="256" class="x">Low</text>
<text x="516" y="256" class="x" text-anchor="end">High</text>
<text x="300" y="270" class="b s" text-anchor="middle">Complexity and uncertainty of the external environment</text>
</svg>
```

<!-- /canon/concepts/foresight-set-up-archetypes.md -->

---
type: Concept
title: Foresight set-up archetypes
description: Foresight lives in organisations as lone wolves, innovation teams, thought leaders, foresight-minded planners or a resident futurist, each with its own reach and blind spot.
status: stable
use_when: "the person is working out where foresight sits in their organisation, who carries it, and what that set-up can and cannot reach"
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 11 and 141"
  - id: root-iftf-2022
    resource: "Institute for the Future (2022), foresight set-up archetypes, as adapted in CIFS teaching material"
---

# Foresight set-up archetypes

Strategic foresight as a formal organisational activity is relatively new in businesses and public organisations, and not as commonly practised as one would think, though it is rapidly emerging as an essential complement to conventional strategic thinking. Many functions and people work with the future in some capacity, often out of insights or innovation departments, but very often it is not formalised. Five archetypes represent the most common forms in which foresight practice is found.

- The lone wolves. Just about every organisation has some people interested in foresight and futures thinking, even if they are not tasked with it. Some have a background in futures thinking, but if their organisation does not value foresight they tend to keep quiet and find ways to smuggle foresight into their work. They may have an official job in design, innovation or consumer insights, which is inherently futures-focused, and they often want to expand their networks and join conversations about the future outside their organisation.
- The innovation or insights team. Its main task is to find opportunities on the horizon and at the fringes.
- The thought leaders. They focus mostly on developing big, bold, captivating narratives about the future. They may not always prioritise the details of strategic foresight as an integrated organisational activity, but they recognise its power in setting the agenda for their organisation and influencing the direction of their domain or industry, and many work to ensure their narrative is reflected in the organisation's strategy.
- The foresight-focused strategic planners. They work to enhance the planning and strategy functions by using foresight to extend planning horizons, and may be responsible for providing the insights leadership needs to evaluate a future contextual environment that may differ significantly from today. They hold the potential for building a discipline of foresight and anticipation by working systematically with the future, through environmental scanning, scenario planning or other approaches.
- The resident futurist. In some organisations formal foresight capacity lies in a single individual, empowered to provide foresight 'on demand' across the organisation. They often function as a trusted adviser, capable of reading, navigating and anticipating change, with a strong focus on translating and filtering foresight into strategy. Without an internal team, they often draw research from external sources or bring in other foresight professionals for specific tasks; the resident futurist may not even be an employee, but an external practitioner with an ongoing relationship.

<!-- /canon/concepts/four-responses-to-ai-scepticism.md -->

---
type: Concept
title: Four responses to public scepticism of AI
description: Facing a public that expects AI-made news to be cheaper and less trustworthy, a newsroom's response sits on two axes, how much AI it uses and whether it explains, and the choice that matters is to decide and explain.
status: stable
sources:
  - id: root-naij-fojo-2026-nielsen
    resource: "Nielsen, R. K. (2026), Four different responses to public skepticism around AI in news, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
use_when: an organisation is choosing how much generative AI to use in its journalism and whether and how to tell its public
---

# Four responses to public scepticism of AI

The value of news is in large part in the eye of the beholder: a relationship between what journalists and publishers do and the members of the public who engage with it. That relationship is challenged from outside, by AI, by dominant platforms and in many countries by political attacks, and from inside, by an industry that tends to take it for granted. Rasmus Kleis Nielsen's typology sorts the responses available to a newsroom in a context where the public is sceptical of generative AI in news.

## The two axes

- Whether the journalist or publisher is a less or more intense user of generative AI.
- Whether they leave their choice implicit or explicitly tell the public a story about what they are doing and why.

## The four responses

- Resigned journalism: limited use of generative AI, and no explicit communication about it. Some end up here by default because they are not changing their practices; others hope for a fast-follower option. The position is complicated by the public's tendency to assume that news media already use AI intensely.
- Furtive AI journalism: increasingly intense use, and no explicit communication. Some feel the work should speak for itself and will not spend scarce resources explaining it; others want the "cheaper to make" part and privately suspect the public is right about "less transparent" and "less trustworthy" too. In the absence of explicit communication, much of the public will assume a publisher is here.
- Romantic journalism: limited use, at least on the editorial side, explicitly communicated. The romantic journalism manifesto is the clear example. It is the mirror twin of furtive AI journalism: if the public thinks AI makes news cheaper and less trustworthy, and you fear they may be right, differentiate clearly from the rest of the industry.
- Modernist journalism: increasingly intense use, explicitly communicated, in the sense "modernist" has in architecture, art and literature: make it new, in the belief that our best selves may be ahead of us. It is hard to find among established publishers, though individual journalists and projects are effectively pursuing it.

## The decision

- The proposal is not that a newsroom should commit to one response, but that it decides which comes closest to what it wants to do, and considers whether and how it communicates with the public about what it does, how, and why.
- Each response could be named differently, stoic, stealthy, retro, techno-solutionist, and each comes with risks and possible rewards. Some paths require little change; those committed to more AI use or more explicit communication require more, and probably a culture shift, since research suggests journalists often have a partial picture of how the public sees their work and do not prioritise investing in that relationship.
- Three starting questions: What does the part of the public we serve assume we do with AI? What do we do to explain what we do with AI? Would people see the principles we preach and what we practise as aligned, if they knew precisely what we do with AI?

## Key things to consider

- Communicating choices about AI is one small component of a wider, more foundational task: being clear about what you do, who you do it for and why, and keeping what you do and what you say you do aligned, explainable and intelligible to the public you want to engage.
- That wider work is cultural rather than technological. It could take longer than any AI rewiring. It could also begin tomorrow.

<!-- /canon/concepts/from-adoption-to-enablement.md -->

---
type: Concept
title: From adoption to enablement
description: Rolling out an AI tool is not using it, so broad use in a newsroom comes from bringing AI to journalists through usable interfaces, coaching, skills and a clear direction, not from guidelines, shiny projects or leaving it to individuals.
status: stable
sources:
  - id: root-naij-fojo-2026-zachrison
    resource: "Zachrison, O. (2026), From low adoption to real enablement – a journey, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
use_when: a plan assumes a rolled-out AI tool will be used, starts from guidelines rather than value, or bypasses the middle managers who would have to integrate it
---

# From adoption to enablement

Two years after an enterprise AI assistant was rolled out to every employee, with training modules and superusers demonstrating best practice, a colleague asks whether the organisation has access to it. Olle Zachrison's retrospective on six years of editorial AI leadership at Swedish Radio and BBC News starts there: AI is on everyone's lips, but how, when and where to use it at scale in editorial work is a nut the industry has not cracked.

## What the first years got wrong

- Four kinds of colleague: those too tied up in daily production to explore; the grumpily sceptical; the fierce opponents, a smaller group than some claim; and the pioneers, who built mind-boggling things from the first days after ChatGPT and rarely brought them into the light, for fear of being caught with non-sanctioned tools or accused of cheating, and because there was neither a culture nor time for sharing.
- Leaders rushed between forums and conferences, focused on theoretical possibilities and risks, and rarely talked to people further down the organisation about their needs, fears and dilemmas. Responsibility for practically exploring AI was left to the individual.
- The shiny new things: summary formats the audience had not asked for, archives you could ask anything though a search engine did it better, illustrations with six fingers. Enthusiasm and improvisation rather than strategic focus, under a super-narrative that the race was on.
- The policy trap. Much of 2023 and 2024 went into guidelines emphasising a human in the loop. Some of that was necessary, especially for public service trust, but the guidelines started from what not to do rather than what value the technology could add, and came with no direction on what to invest in. Guidelines are not strategy, and strategy must be matched with resources to implement it.
- The curse of the central innovation team: projects that could create value, but tinkering around the edges rather than rallying behind the direction, because involving hundreds of journalists takes time and blue-sky thinking was more fun.
- Meanwhile the news factory kept the lights on under an unprecedented news flow, new formats on more platforms and disappearing chairs. The middle managers were forgotten more than anyone: engagement went from the executive team straight to individuals, and nobody expected a manager to plan how AI would enter the team's core processes.

## What the organisation actually wanted

- A free-text question at the end of an introductory course, what would you use a perfect AI assistant for, drew 1,224 ideas from Swedish Radio employees, many smarter than anything a central team could devise. Research support, editorial feedback and audio processing featured; by far the largest area was administration: reporting, email, scheduling. Everyone wanted to free up time.
- A simple direction helped: use AI to improve and develop the journalism, create better user experiences, improve internal productivity.

## Launch is not use

- Switching on a feature for thousands of busy journalists does not mean they use it. Mandatory training and lunch sessions do not mean active participation; journalists are news avoiders when it comes to internal information. Critical research into how tech giants' assistants distort journalism, however valuable, makes reporters less inclined to embrace those same assistants the next day.
- Superusers, once asked, said: we do not know what we are allowed to do; AI is almost never discussed in the morning meeting; we want practical examples from other teams; the enterprise tool is hard to use for journalism. And good examples sprang up once attention turned their way, often built with home-made, unsustainable solutions by innovators navigating access, legal, security and governance barriers alone.
- Organisations that understood early that their own AI toolkit was central to broad adoption, a bespoke interface with the company's own branding, gave journalists the seal of approval they needed to feel safe. Bring AI to journalists rather than the other way around; like audiences, journalists care more about the user experience than the sophistication of the model.

## The next phase

- Three elements must go hand in hand: easy-to-use interfaces, hands-on coaching and continuous skills development.
- The possibility ahead is hyper-personalisation for audiences, moving from mass media towards an offering tailored to interests, intentions, behaviour and demographics, and for journalists, AI support adapting to each person's role, task and needs like a personal coach, with every journalist able to build and use their own tools at every step, breaking the code monopoly. A prototype multi-agent system scraping, summarising and translating social media from a dictatorship, built as a vibe-coded content system for one story, is a glimpse.
- The darker side: when everyone can build personal agents, nobody yet knows how to make sure they follow the journalistic guidelines; and whether quality journalism will reach people, be recognised as coming from its maker, or fragment society further through hyper-personalisation, is open.
- What to protect is not formats or the organisations themselves but the values: careful, methodical work with facts, a critical mindset, engaging storytelling, openness to perspectives, including underserved groups, accountability. The deskilling to worry about is not forgetting how to write but losing the ability to interact with people out in the world.

## The change in language

- Talk about enablement, giving people the chance to engage with new technologies, rather than adoption, which casts them as passive.
- Focus on local usefulness over centrally developed, ready-made solutions; let go of the fixation on formats and artefacts and talk about values and mission; make the strategic direction clearer rather than placing responsibility on the individual, which is where centralisation is actually needed; share inspiring examples from peers; connect journalists with specialist expertise elsewhere in the organisation.
- It is the people. An inspired, hard-working group who want to do something together can move mountains, and if they do not make it all the way, they will have tried.

<!-- /canon/concepts/from-foresight-to-strategy.md -->

---
type: Concept
title: From foresight to strategy
description: Foresight reaches strategy by testing existing initiatives against scenarios, by deriving new options from them, or by probing with prototypes that feed learning back.
status: stable
use_when: "foresight work is done and the person must turn it into strategic choices by testing current plans, deriving new options or probing with prototypes"
depends_on:
  - /canon/concepts/scenarios.md
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 117 and 118"
---

# From foresight to strategy

Having done the foresight, how does it link to the strategic choices about to be made? There are three bridges, and in practice organisations blend them.

## Strategy-forward: scenario-tested strategy

- Most, if not all, organisations already have a strategy and a portfolio of initiatives and responses. Start with the existing strategy, initiatives, products, services, projects and risk responses, and test their merits against the set of scenarios, to see whether they still provide a path to success. This is wind-tunnelling.

## Future-back: scenario-led strategy

- Put existing strategies to one side and start with the scenarios, using the picture of tomorrow as a resource for stimulating inspiration and imagination and for bridge-thinking. What solutions does this future indicate? What different or altogether new strategies are suggested here? From the scenarios, develop strategic options, initiatives, innovation ideas and risk responses.

## Strategic probing

- A newer approach that has come in from the product and service design professions. Test strategies and initiatives in the direction the foresight suggests, prototyping different solutions rapidly, and inject that learning back into the foresight process to create experimental proof.

## Figures

Scenario-tested strategy: chess pieces on a board, captioned start with existing strategy, initiatives, products, services, projects and risk responses, with a large arrow pointing to a scenario 2 x 2, captioned test merits against scenarios, wind-tunnelling. Scenario-led strategy: a scenario 2 x 2, captioned start with scenarios, with a large arrow pointing to a light bulb, captioned develop strategic options, initiatives, innovation ideas and risk responses.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="fff2s" viewBox="0 0 560 232" style="display:block;width:100%;max-width:480px" role="img" aria-label="Two routes from foresight to strategy: testing an existing strategy against scenarios, or starting with scenarios to develop options">
<style>
.fff2s text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.fff2s .b{font-weight:500;fill-opacity:.95}
.fff2s .s{font-size:10.5px}
.fff2s .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.fff2s .m{stroke-opacity:.5}
.fff2s .f{stroke-opacity:.2}
.fff2s .o{fill:#FFC7A5;stroke:#413C38;stroke-opacity:.5;stroke-width:.75}
</style>
<rect width="560" height="232" rx="14" fill="#fff"/>
<text x="40" y="38" class="b">Scenario-tested strategy</text>
<circle class="l" cx="56" cy="68" r="5"/><path class="l" d="M47,89 L52,74 H60 L65,89 Z"/>
<text x="82" y="73" class="s">Start with existing strategy,</text>
<text x="82" y="86" class="s">initiatives, products and projects</text>
<path class="l m" d="M266,76 L300,76"/><path class="l m" d="M294.7,78.9 L300,76 L294.7,73.1"/>
<rect class="o" x="317" y="63" width="26" height="26" rx="3"/><path class="l m" d="M330,63 V89 M317,76 H343"/>
<text x="356" y="73" class="s">Test merits against scenarios</text>
<text x="356" y="86" class="s">(wind-tunnelling)</text>
<path class="l f" d="M40,118 H520"/>
<text x="40" y="150" class="b">Scenario-led strategy</text>
<rect class="o" x="43" y="175" width="26" height="26" rx="3"/><path class="l m" d="M56,175 V201 M43,188 H69"/>
<text x="82" y="192" class="s">Start with scenarios</text>
<path class="l m" d="M266,188 L300,188"/><path class="l m" d="M294.7,190.9 L300,188 L294.7,185.1"/>
<circle class="l" cx="330" cy="185" r="9"/><path class="l" d="M326,197 H334 M327,201 H333"/>
<text x="356" y="185" class="s">Develop strategic options,</text>
<text x="356" y="198" class="s">initiatives and innovation ideas</text>
</svg>
```

<!-- /canon/concepts/future-preparedness-and-performance.md -->

---
type: Concept
title: Future-preparedness and performance
description: Firms with foresight adequate to their environment outperform on profit and growth, and firms with too much underperform as badly as those with too little.
status: stable
use_when: "someone questions whether foresight pays off, or how much foresight an organisation actually needs for its environment"
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 43 and 44"
  - id: root-rohrbeck-2018
    resource: "Rohrbeck, R., Kum, M. E., Jissink, T. & Gordon, A. (2018), Corporate Foresight Benchmarking Report 2018"
  - id: root-pwc-ceo-survey-2025
    resource: "PwC, 28th Annual Global CEO Survey (2025)"
---

# Future-preparedness and performance

In times of change, it is the organisations with a culture and organisational processes around strategic foresight that perform better. This is known both from research and from first-hand experience.

## Vigilant, vulnerable, in danger, neurotic

A longitudinal study of around 4,000 companies from 2008 to 2015 classified firms by how well their foresight practices fitted their business environment. Vigilant companies had adequate strategic foresight practices for their environment. Vulnerable and in-danger companies fell short on foresight at different levels. Neurotic companies had too much strategic foresight in relation to what their environment required.

| | All firms | Vigilant | Vulnerable | In danger | Neurotic |
|---|---|---|---|---|---|
| Average profitability | 12% | 16% | 10% | 10% | 9% |
| Average market capitalisation growth | 25% | 75% | 38% | -1% | -6% |

- Organisations with a structured approach to foresight outperform on both profitability and growth.
- Too much strategic foresight is also harmful, because it diverts too much attention away from the current business.

## The viability question

- Asked how long their business would remain economically viable if it continued on its current path, the share of chief executives answering ten years or less was 39% in 2023, 45% in 2024 and 42% in 2025.
- Six in ten chief executives judge strategic decisions by the result, not by the quality of the process. A predictable process leads to predictable outcomes, and business leaders are not happy with the outcomes and cannot rely on predictability.

<!-- /canon/concepts/futures-driven-innovation-model.md -->

---
type: Concept
title: Futures-driven innovation model
description: Knowledge of the past informs current patterns and behaviour, and the possible futures with their systemic changes and new logics inform the present decisions, so innovation and strategic choices are made from both directions at once.
status: draft
sources:
  - id: root-kahler-seelbach-2024
    resource: "Kähler, M. T. and Seelbach, A. (2024), Strategic Customer Foresight Management"
  - id: root-eller-hofmann-schwarz-2020
    resource: "Eller, E., Hofmann, R. and Schwarz, J. O. (2020), The Customer Foresight Territory, Marketing Review St. Gallen 2020(3), pp. 888 to 895"
use_when: an innovation or strategic choice is being made from the present alone, without the contexts and structures that shaped today's patterns or the possible futures that could change them
depends_on:
  - /canon/concepts/futures-driven-innovation.md
  - /canon/concepts/the-futures-cone.md
---

# Futures-driven innovation model

Using the possible futures to inform innovation and strategic choices. The model places current patterns and behaviour at the centre of a timeline that runs into the past on one side and into the possible futures on the other, and draws two movements across it.

## The three parts

- Contexts and structures from the past, on the left.
- Current patterns and behaviour, at the centre.
- Possible futures with systemic changes and new logics, on the right, opening out from the present as a cone.

## The two movements

- Using knowledge of the past to inform patterns: the contexts and structures from the past narrow towards the present and explain the patterns and behaviour found there.
- Using the possible futures to inform the present decisions: the possible futures loop back to the present, so that innovation and strategic choices are made with them in view.

## Figure: the futures-driven innovation model

A horizontal timeline with arrowheads at both ends. On the left, a wide cylinder labelled "Contexts and structures from the past" narrows, through a smaller ring and dashed lines, towards a circle at the centre labelled "Current patterns & behaviour"; a curved arrow beneath this section reads "Using knowledge of the past to inform patterns". From the central circle a cone opens to the right, ending in a curved rim with a dashed outer edge, labelled "Possible futures with systemic changes and new logics"; inside the cone, circles of different sizes sit at different distances from the present, each joined to it by a dashed line. A dashed arc runs from the far rim of the cone back under the diagram to the central circle, with a curved arrow and the bold label "Using the possible futures to inform the present decisions". The source line reads: CIFS, inspired by Malte Tobias Kähler and Alina Seelbach (2024), Strategic Customer Foresight Management, and Eller, Hoffman, Schwarz (2020).

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="fffdi" viewBox="0 0 560 328" style="display:block;width:100%;max-width:480px" role="img" aria-label="The futures-driven innovation model: the past narrows into current patterns and behaviour, a cone of possible futures opens ahead, and the futures inform present decisions">
<style>
.fffdi text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.fffdi .b{font-weight:500;fill-opacity:.95}
.fffdi .s{font-size:10.5px}
.fffdi .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.fffdi .m{stroke-opacity:.5}
.fffdi .f{stroke-opacity:.2}
.fffdi .d{stroke-dasharray:2 5}
.fffdi .o{fill:#FFC7A5;stroke:#413C38;stroke-opacity:.5;stroke-width:.75}
.fffdi .n{fill:#fff;stroke:#413C38;stroke-width:1.25;stroke-opacity:.5}
.fffdi text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="328" rx="14" fill="#fff"/>
<path class="l f" d="M30,130 H530"/>
<path class="l f" d="M525.6,132.4 L530,130 L525.6,127.6"/>
<path class="l f" d="M34.4,127.6 L30,130 L34.4,132.4"/>
<ellipse class="l m" cx="70" cy="130" rx="14" ry="62"/>
<ellipse class="l m" cx="165" cy="130" rx="8" ry="32"/>
<path class="l m" d="M70,68 L165,98 M70,192 L165,162"/>
<path class="l m d" d="M165,98 L240,124 M165,162 L240,136"/>
<path class="l m" d="M260,124 L470,52 M260,136 L470,208"/>
<path class="l m" d="M470,52 A18,78 0 0 0 470,208"/>
<path class="l m d" d="M470,52 A18,78 0 0 1 470,208"/>
<path class="l f d" d="M262,130 L330,116"/>
<circle class="n" cx="330" cy="116" r="6"/>
<path class="l f d" d="M262,130 L386,158"/>
<circle class="n" cx="386" cy="158" r="10"/>
<path class="l f d" d="M262,130 L432,96"/>
<circle class="n" cx="432" cy="96" r="14"/>
<circle class="o" cx="250" cy="130" r="12"/>
<text x="40" y="40">Contexts and structures</text>
<text x="40" y="54">from the past</text>
<text x="250" y="76" text-anchor="middle">Current patterns</text>
<text x="250" y="90" text-anchor="middle">and behaviour</text>
<text x="530" y="24" text-anchor="end">Possible futures with systemic</text>
<text x="530" y="38" text-anchor="end">changes and new logics</text>
<path class="l m" d="M78,204 Q160,238 240,150"/>
<path class="l m" d="M238.8,154.9 L240,150 L235.3,151.6"/>
<text x="40" y="250" class="s">Using knowledge of the past</text>
<text x="40" y="263" class="s">to inform patterns</text>
<path class="l d" d="M470,214 Q372,292 258,148"/>
<path class="l" d="M263.5,150.3 L258,148 L259,153.9"/>
<text x="530" y="262" class="b" text-anchor="end">Using the possible futures to</text>
<text x="530" y="277" class="b" text-anchor="end">inform the present decisions</text>
<text class="ref" x="536" y="300" text-anchor="end">Futures-driven innovation model · Source: Eller, E., Hofmann, R. and Schwarz, J. O. (2020), The Customer</text>
<text class="ref" x="536" y="312" text-anchor="end">Foresight Territory. Modified by CIFS.</text>
</svg>
```

<!-- /canon/concepts/futures-driven-innovation.md -->

---
type: Concept
title: Futures-driven innovation
description: Innovation that works backwards from the future, using signals and structural shifts to find where today's models will become insufficient, and acts across all three horizons with intent.
status: stable
use_when: "an innovation decision should start from where today's models will fall short, and be placed deliberately on a time horizon rather than all treated as near term"
depends_on:
  - /canon/concepts/three-horizons-of-ai-mediated-transformation.md
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, section Futures-driven innovation"
---

# Futures-driven innovation

Futures-driven innovation enables organisations to move beyond path dependency and act across all three horizons with greater intent. That requires both a clear sense of direction and a sharper understanding of where the most meaningful strategic fits are on the time horizon.

## A shift in mindset

- Rather than innovating forward from the present alone, organisations need to work backwards from the future, asking what it would take to get there.
- Signals and structural shifts are used as inputs informing innovation decisions today, inspired by existing strategic foresight methodologies from scenario-building to horizon scanning to critical uncertainty mapping.
- The purpose is not to invent for a made-up world. It is to use futures thinking to identify where today's models may become insufficient, where new needs are emerging, and where existing assumptions about markets, users, workflows and value creation may need to be challenged.

## The changing role of innovation

- Innovation is not only about producing the next product, service or pilot. It is also about building new organisational muscles: experimentation, scenario-informed decision-making, simulation, and the ability to learn from the edge rather than only from the core.
- Futures-driven innovation is therefore as much about organisational learning and cultural readiness and relevance as it is about invention.

## Across the horizons

- In Horizon 1, futures-driven innovation may improve current workflows through AI-supported research, better sensing, or more adaptive interfaces.
- In Horizon 2, it may involve piloting agentic collaboration, simulation-based decision settings, or new retail experiences built around context and user intent interfaces.
- In Horizon 3, it asks more radical questions. What happens when customers engage through machine-readable environments rather than traditional channels? What happens when AI agents become part of organisational infrastructure? What happens when human verification capabilities are dramatically outpaced by the intelligence of agentic systems? What happens when value shifts from content and product to system, context and model orchestration?
- These are not questions for later. They are questions that shape what capabilities organisations need to start building now. The challenge is to avoid treating all innovation as if it belongs to the same horizon.

## Long-term courage

- Futures-driven innovation depends on long-term courage, the willingness to invest, experiment and act before the outcome is certain.
- Many organisations struggle to create proper space for more transformative work, when profit, political or stakeholder incentives favour the measurable, the immediate and the low-risk.
- Futures-driven innovation challenges that logic by insisting that long-term relevance requires room for uncertainty, room for experimentation, and room for ideas that may initially look misaligned with the immediate present.

<!-- /canon/concepts/futures-fallacies.md -->

---
type: Concept
title: Futures fallacies
description: Five recurring errors in reasoning about the future, from linear projection to personal exemption, produce mistaken beliefs that feel like knowledge.
status: stable
use_when: "reasoning about the future leans on straight-line projection, holding all else equal, a fixed destination, prediction or personal exemption"
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 31 and 32"
  - id: root-milojevic-futures-fallacies
    resource: "Milojević, I., futures fallacies, as cited in CIFS teaching material"
---

# Futures fallacies

Fallacies are failures in our reasoning that lead to mistaken beliefs. Futures fallacies are the detrimental thinking patterns that appear when we think about the future.

- Linear projection: presuming that future change will be a simple and steady extension of past and current trends.
- All else unchanged: considering only a few aspects of change while holding everything else equal.
- The arrival: envisioning possible futures as static objects, such as a destination or a goal.
- The prediction, or planning: believing it is possible to predict or plan the future.
- Future personal exemption: being overly optimistic about one's own future despite a realistic or even dystopian take on our collective futures.

## Figure: the five fallacies

Five fallacies laid out as a grid, three above and two below, each with a thin-line icon: a rising line chart for linear projection, a 'not equal' sign for all else unchanged, a flag for the arrival, a crystal ball for prediction and planning, and a person with a shield for personal exemption.

<!-- /canon/concepts/futures-friction.md -->

---
type: Concept
title: Futures friction
description: Futures friction introduces deliberate friction into innovation to test ideas against contrasting possible futures before a convincing answer settles them, asking what would need to remain true for an idea to make sense.
status: stable
sources:
  - id: ref-hvitved-2026
    resource: "Hvitved, S. (2026), Futures friction: a new approach to how media organisations remember, learn and reimagine, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
  - id: root-wadinambiarachchi-2024
    resource: "Wadinambiarachchi, S. et al. (2024), The Effects of Generative AI on Design Fixation and Divergent Thinking"
use_when: an idea feels settled by a convincing answer, a plan is judged only by today's metrics, or a team wants to test what must remain true for an idea to make sense
depends_on:
  - /canon/concepts/second-brains.md
  - /canon/concepts/existential-innovation.md
---

# Futures friction

Will the formats, products or services you are investing your time and resources in still be relevant in a few years? The assumptions behind our choices often seem so obvious that we rarely question whether they still hold. If media organisations only make room for ideas that fit today's strategy, they risk rejecting the very ideas that could keep them relevant as the surrounding system changes. Sofie Hvitved's two connected questions: how do we make better use of our collective organisational memory, and how do we keep questioning what we know as the logics around us change?

## What it is

- Futures friction brings futures thinking and foresight into the innovation process. It introduces deliberate friction to test ideas against possible futures, considering changes that might happen in both the short and the long term.
- A convincing AI-generated answer can make an idea feel settled before other possibilities have been explored: the risk of premature convergence. Intentional futures friction challenges the assumptions and biases behind that sense of certainty, making room to stop, think and iterate.
- It builds on a futurist's way of thinking: the conditions we work within could develop in several plausible directions, and the task is to explore what those differences would mean for the decisions made today. That means looking beyond short-term strategies and attending to signals that could challenge what is taken for granted. Some changes are incremental; others could fundamentally alter how people access information or whom they trust, which are existential questions for media; many needs and behaviours may endure.

## The questions it asks

- What would need to remain true for an idea to make sense?
- Under what conditions might an overlooked idea become relevant?
- If this kind of information becomes widely available, what would make our own service useful?

## How it works with shared context

- Shared context and futures friction need each other. A second brain turns shared context into infrastructure for remembering and learning; futures friction brings questioning into that infrastructure, helping organisations explore possible futures and recognise what they may need to reimagine.
- It means staying willing to change our minds as we learn. Short cycles of testing and reflection explore the questions in ongoing innovation work, and each experiment should add to the context others can draw on.
- In Hvitved's imagined 2030 team, friction enters once the earlier experiment has been understood: would the idea make sense if residents increasingly expected information to reach them through their own AI assistants? An agent helps explore that alongside the alternative, that people resist AI mediation and want direct contact with local journalists, and observations residents have agreed to share give reasons to take both seriously. The team stress-tests several ways of accessing the service; its purpose stays the same while the assumptions about how to fulfil it stay open. When a competitor launches a similar service weeks later, the team revisits its assumptions, adjusts the experiment and records what changed and why.

## Where to start

- Bring futures friction into the work from the beginning. Ask what must remain true for the idea to make sense. Test it against contrasting plausible futures, including one where the underlying media logics change.
- Choose a small experiment and agree what you need to learn, so that today's performance metrics do not dismiss an idea before its future value can be explored.
- Record what changes in your thinking, and give someone responsibility for revisiting the assumptions.
- Before returning to quarterly goals, consider which ideas never make it onto the agenda because they challenge the current logic. Give one of them time, resources and the benefit of what others have already learned, then use futures friction to explore where it could become relevant.

## Key things to consider

- This takes practice, from organising shared context to questioning what AI retrieves and thinking in futures. Leadership needs to protect time for it, recognise contributions across teams and allow learning to change priorities; a second brain is of little use if people are rewarded for holding knowledge back or the organisation refuses to reconsider its direction.
- It connects to the call for existential innovation, rethinking how media organisations sustain themselves and what they exist to do. Shared context and futures friction could create the conditions for that work: learning across teams, questioning inherited assumptions, and giving unfamiliar ideas room to develop.
- A futures-driven media industry begins with the decision to take an idea seriously before it fits today's strategic environment.

<!-- /canon/concepts/futures-literacy.md -->

---
type: Concept
title: Futures literacy
description: The learnable capability to hold many futures in mind and use them to see the present differently.
status: stable
use_when: "someone asks what it means to be capable with the future, or how people learn to hold many futures in mind"
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Vocabulary of the Future"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 36 and 37"
---

# Futures literacy

The capability to imagine, question and use the future as a resource for better understanding the present and acting with intention.

- Developed within UNESCO as a core competency for the 21st century, it treats engaging with the future as something that can be learned and strengthened, much like reading and writing, and it enhances our ability to prepare, recover and invent in the face of change.
- A futures-literate person is able to hold many possible futures in mind, rather than a single expected one, and to draw on them to see the present differently, becoming more comfortable with uncertainty, novelty and emergence.

## Future as a verb

- Future as a noun means the distant time yet to come. Future as a verb means actions and processes, 'futuring', that anticipate and influence future outcomes in the present. Changing the term from noun to verb describes using the future to inform present-day decisions.

<!-- /canon/concepts/how-to-build-a-good-scenario.md -->

---
type: Concept
title: How to build a good scenario
description: A good scenario is a story that is plausible, consistent, differentiated, memorable, challenging and relevant to decisions.
status: stable
use_when: "a scenario draft needs checking for whether it is plausible, consistent, distinct, memorable, challenging and useful to decision-makers"
depends_on:
  - /canon/concepts/scenarios.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Scenario Development, Figure 15: How to Build a Good Scenario"
---

# How to build a good scenario

| Criterion | Requirement |
|---|---|
| Story | A vivid description for engaging stakeholders. We need to 'experience' the futures, so they should also involve emotion, not just logic |
| Plausibility | Future characteristics and events must be plausible, meaning that they must fall within the limits of what might conceivably happen |
| Consistency | Must be logically consistent. If the scenario has built-in inconsistencies, it will undermine the credibility of the scenario |
| Differentiation | Must be structurally or qualitatively different. Scenarios should not be so close to one another that they simply become variations of the same scenario |
| Memorable | Should be easy to remember. It helps to have catchy and descriptive titles |
| Challenging | Must challenge organisations' perceived wisdom about the future |
| Decision relevance | Should provide insights useful to decision-makers |

<!-- /canon/concepts/humanistic-and-scientific-journalism.md -->

---
type: Concept
title: Humanistic and scientific journalism
description: AI pulls journalism apart into a humanistic craft valued precisely because it is human and a scientific, systematic form that is automatable, and the middle between them declines, so each needs its own place, skills, products and values.
status: stable
sources:
  - id: root-naij-fojo-2026-caswell
    resource: "Caswell, D. (2026), Journalism as Science, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
use_when: a plan sits between human voice and automated scale, or a newsroom cannot say which of its work is craft and which is system
depends_on:
  - /canon/concepts/four-responses-to-ai-scepticism.md
---

# Humanistic and scientific journalism

The same division shows up again and again under different names: romantic and modernist journalism, the differentiated and the scale ends of the barbell effect, editorial and technical. David Caswell's terms for what lies beneath them are C. P. Snow's two cultures. The humanistic culture emphasises subjective experience, interpretation, judgement and the qualia of human experience; the scientific culture emphasises empirical observation, experimentation, quantification and the accumulation of objectively verifiable knowledge.

## The barbell effect

- When a scaling technology appears, an industry separates into two extremes: a differentiated extreme based on intangible value, and a scale extreme based on applying the technology to its full extent. Businesses in the middle range decline, like department stores in an era of boutique brands and e-commerce.
- AI has deeply unsettled the balance between the two cultures, because it encroaches on what was the sole preserve of humanism: it can research, create, write, interpret, contextualise and make assessments, and its output can be measured against that of humans.

## Humanistic journalism

- Most journalism today. It is defined by the centrality of the opinions of specific humans called journalists, editors and publishers: an artisanal craft, a handmade product shaped by the intuitive choices of individuals, whose practitioners define themselves through socialisation, identity and values.
- Opinion is everywhere in it, from commissioning and newsworthiness to editing and word choice. The best have a voice; the very best are adept at storytelling. It is intensely social: a person speaking to other people, with trust, reputation, status and norms attached, and it is adept at triggering emotion, empathy, outrage and, for the most skilled, curiosity.
- As a social activity, automating it may be pointless or meaningless. Its human origins may become more valuable in an AI-mediated ecosystem, not because of vaguely defined quality but precisely because it is human, as chess did after Deep Blue and Go after AlphaGo.

## Scientific journalism

- Today it exists only on the margins: data journalism, the numerical parts of sports and financial reporting, election results, investigations built on databases and document repositories, fringe innovation projects. It is not prestigious, and some journalists barely consider it journalism.
- It is defined by abstraction and independence from human opinion. It values precision and objectivity, seeks to be systematic rather than selective and to build systems rather than handcraft artefacts, treats every unit of information the same, and is assessed by completeness and accuracy. The practitioner's opinion in its output is an error, not an attribute. It is not seeking to be socially influential; it is seeking to be useful.
- It is eminently automatable, and its automation began before general-purpose language models, in template-based natural language generation. The earlier limit to structured or numerical information was a technical constraint, now removed.
- A scientific perspective also applies to journalism's understanding of its audience, which is remarkably thin: at worst paternalistic folk theories, at best simplistic analytics and coarse declared preferences. Science offers cognitive research, controlled testing and theory built on neuroscience and evolutionary biology rather than on identity and social conditions.

## Why society needs scientific journalism

- A technical interpretation of societal information flows is inevitable, because humanistic interpretations cannot adjust to the scale, scope and velocity of AI-mediated information. The seeds are sprouting in start-ups, platforms and academic fields with no overlap with journalism; the ambition to replace journalism with an entirely new model of information flows, backed by billions, is one harbinger.
- The problem with that inevitable alternative is not its existence or value but its values. Journalism's declared values of truthfulness and independence, and its watchdog incentives, have served society well. A scientific journalism should not merely operate in a scientific way but pursue values similar to those of science itself, and ideally the enlightenment values of humanistic journalism should become its values too.
- Science is trusted because it works, and because it is not perceived to be filtered through the gate of human opinion. Humanistic journalism excels at inter-subjective truth, what a community agrees is true; scientific journalism may offer society a way to coalesce around a shared perception of objective reality that opinion-centred journalism cannot.

## What follows

- Explicitly recognise and separate humanistic from scientific journalism, in leadership, skills, activities, products and even organisations, and transfer the values and mission of the former into the latter. The differences between the cultures are too great to bridge; separation relieves both of their uncertainty, refocusing humanistic journalism on what it does best and unblocking scientific journalism.
- Build a research and development ecosystem for scientific journalism: first-principles applied research on information representation, automated verification, network coordination and incentives; audience research with the full range of cognitive science; AI and data science oriented towards societal understanding rather than support for storytelling.
- Humanistic journalism cannot become an end in itself, privileged over the goal of open, democratic societies of empowered citizens with access to trustworthy information. Journalism must expand or it will shrink.

<!-- /canon/concepts/liquid-content.md -->

---
type: Concept
title: Liquid content
description: Content that adapts in real time across formats, platforms, contexts and users rather than existing as one fixed version.
status: stable
use_when: "the person is weighing content that adapts to each user and context against fixed formats, and what that shift does to where value lies"
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, section From static to liquid"
---

# Liquid content

Liquid content is content that dynamically adapts in real time across formats, platforms, contexts and users rather than existing as one fixed version.

- The shift is from information to context, from static to liquid. Competitive advantage depends less on simply making information available and more on understanding what matters in a given moment, for a given person, in a given situation.
- The quality of liquid content depends on context, data richness, inference and interpretation, which raises questions around privacy, misreading, manipulation and fairness.
- As organisations lose some control over static content in a more liquid digital ecosystem, the static 'artifact' of content is no longer where the value lies.

<!-- /canon/concepts/liquid-foresight.md -->

---
type: Concept
title: Liquid foresight
description: Foresight redesigned for an AI-mediated world becomes a continuous, adaptive layer inside the organisation's systems rather than a static deliverable, while keeping its core principles.
status: stable
use_when: "someone asks how foresight itself could become a continuous, AI-supported capability inside the organisation rather than a one-off deliverable"
depends_on:
  - /canon/concepts/liquid-content.md
  - /canon/concepts/reperception.md
  - /canon/concepts/three-horizons-of-ai-mediated-transformation.md
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, section Liquid foresight: When foresight becomes AI-mediated"
---

# Liquid foresight

Foresight is fundamentally not about predicting the 'one' future. It is about talking about futures in plural, creating directional awareness, improving the quality of strategic questions, and in doing so providing organisations with the confidence to move between plausible futures, scenarios and horizons with more clarity and less false certainty. But what if foresight were designed for a world mediated by AI?

## What it is

- Liquid foresight, a term coined at the CIFS H3 AI Lab, is an AI-mediated foresight approach that rethinks how foresight itself can evolve towards the third horizon. The aim is a more adaptive practice, one that connects long-term perspectives and core foresight principles with dynamic, real-time signals and contextual shifts personalised to the individual end users.
- Rather than seeing foresight primarily as a static product or a time-limited exercise, it becomes a more continuous and adaptive layer inside the organisation's AI systems. A constantly evolving and adapting process. An ongoing interface between possible futures and present decisions.

## A more dynamic flow of information

- Liquid foresight draws inspiration from liquid content and the possibility of making futures knowledge more interactive, more multimodal, and more responsive to a context, a role and a situation.
- Different parts of an organisation need different things from foresight. A board may need strategic direction. An innovation team may need inspiration for ideas to test. A product team may need an understanding of changing user expectations translated into something they can act on right away.
- The ambition is not necessarily one foresight output for everyone, but a more fluid system that stays anchored in shared direction while adapting to context.

## The Horizon 3 perspective

- Horizon 3 is not only about imagining distant futures. It is about connecting it to the assumptions built into today's ways of working.
- If foresight were invented today, in a world already shaped by AI, simulations, agents, constant flow of insights and machine-readable knowledge, it might not take the form inherited from earlier strategic practice. It might look more like a living knowledge infrastructure, built around iterative loops between the assumptions we test and the contextual data through which we explore multiple futures. A system that connects signals, assumptions, methods, scenarios and decisions across time. Something closer to a self-iterating context graph than a static playbook. Something that can support re-perception not once, but continuously.

## The core principles remain

- Liquid foresight is not about replacing the core principles of foresight. It is about asking how those principles might evolve in an AI-mediated world.
- The need for humans to challenge their own assumptions, broaden their outlook, and work with uncertainty in genuinely participatory processes remains essential. However, the form foresight takes may change. Instead of ending when a scenario is delivered, it might continue through feedback loops, simulations, updated signals, and role-specific interfaces that keep futures thinking alive inside the organisation. Foresight can become more hyper-personalised, multimodal and responsive, while still anchored in a shared strategic direction.
- The core of liquid foresight is adaptive sensemaking, where signals are clustered, challenged, connected, and translated into patterns, tensions and possible implications. AI can extend the capacity of foresight by helping scan information flows, surface inconsistencies, work with context, generate alternative framings, and support simulation.
- The point is not to move away from the process of re-perception and adapting futures thinking. It is to make it more alive, more usable, and more connected to action in the organisational environment for which it was designed. Fundamentally, liquid foresight stresses a shift from sprinkling a little 'AI-salt' on existing foresight processes to building AI-native ways for people and organisations to imagine, work with, and shape futures and scenarios.

## Key principles of liquid foresight

1. From a deliverable to a dynamic capability: foresight that functions as a living capability within the organisation rather than a static output.
2. From a fixed view to live sensemaking: it should connect long-term thinking with signals, tensions, simulations and contextual shifts as they emerge and are relevant.
3. From one-size-fits-all to adaptive intelligence: different roles need different foresight interfaces, but all should remain aligned to a shared strategic direction.

## How to experiment now with AI-integrated, liquid foresight

1. Explore Horizon 3 futures with AI. Use AI to explore radically different futures in which intelligent systems reshape organisations, markets, and the foundations of value creation and competitiveness in the third horizon.
2. Prototype AI-native foresight tools. Test simulations, agent-based models and structured knowledge systems that help explore the futures.
3. Use AI to challenge assumptions. Let it act as a provocation partner, not just an assistant. Under human oversight, use its unexpected outputs to open up new questions and alternative ways of seeing.
4. Work with liquid content rather than static outputs. Build foresight as a dynamic knowledge layer that can evolve continuously and adapt to different users, contexts and decisions.

<!-- /canon/concepts/liquid-or-human-first.md -->

---
type: Concept
title: Use the liquid wisely or choose human first
description: Liquid content and content with a clear human voice are both viable positions, and the half-hearted middle between them collapses, so a medium must choose one or be deliberate about when it does which.
status: stable
use_when: "a medium must choose between personalised, AI-adapted content and content carried by clear human voices, or risks drifting into the half-hearted middle"
depends_on:
  - /canon/concepts/existential-innovation.md
  - /canon/concepts/liquid-content.md
sources:
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, section 3. princip: Brug det flydende klogt eller vælg 'mennesket først'"
---

# Use the liquid wisely or choose human first

## The potential and the danger in the liquid

A central part of the AI content revolution concerns liquid content. It can be defined as content that is not fixed, like an article, a book or a podcast, but always adapts to a specific need of the individual person.

An AI chat is one form, where the content is always shaped to exactly your question, but it can take many other forms: audio, infographics, video, websites, apps, even a whole internet, if that is still the right word, that can be created and adapted from the user's concrete wishes, and where the same content can flow multimodally between the forms. It is a decisively different way of telling stories and conveying information from the one journalism has been used to, a kind of return to the oral ideal from before the Gutenberg revolution took hold, and it is changing the whole internet and the way knowledge and information are created and consumed. Browsing gives way to asking, content turns fluid, creation scales while stability erodes, and attention fragments even as platforms consolidate. It challenges the linear in creative forms in favour of the user helping to create stories, or even worlds of information, adapted in real time: everything is generating, the web generates itself.

The liquid opens both a potential and a threat to journalism.

### Early experience

- Media-developed AI chats, where the user can talk with the medium's journalism, often limited to the medium's own content as quality assurance, show a potential for increased relevance. Users get a new way to search the archive and receive answers to exactly their question, adapted to their level of knowledge and need, with some potential in education. But the chats have met technical limits: answering only the questions they actually have an answer to, and not remembering the earlier dialogue. The form challenges ideals of letting people write every story and constitutes a loss of control that raises concern for publishing quality, which has led to hidden placement and unremarkable traffic. Even with prominent placement on the front page, traffic has been limited.
- Where users have asked millions of questions and traffic exceeded expectation, relatively few users asked their own open questions; they preferred buttons with pre-formulated questions. Perhaps people do not want to talk with journalism at all but rather to be served the news. Users have hardly complained about the new form, which could suggest a greater reluctance inside journalistic environments than outside among users.
- Chats have shown relatively large potential within narrower areas, such as concrete elections or big breaking stories, where usage rose considerably.
- One experiment led to a "what has happened since you last read" function, where users get the latest developments personalised since they last followed along. It has been a great success because it solves a need journalism's forms have struggled with: people arrive with different histories when they read the latest news. The success could not be calculated in advance but revealed itself only in the experiment, so the chat was turned down and the new function turned up.
- A pure AI podcast adapted to your interests and made only for you gained relatively many users and a usable quality, but closed in 2026: the commercial side proved more challenging than the technical, indicating that the business model behind conversational content is not yet easy to carry.
- Another approach treats the medium's research and data as a kind of atoms that AI can assemble in very different ways, making possible formats that put together and open up the whole research and archive in radically new ways. Here the quality of the underlying data, the medium's archive, becomes more important than the single news item, and a competitive parameter against not only other news media but also other liquid formats. Because of technical limitations the article as a form has always been a closed container, suited to people arriving at the same time with the same degree of knowledge; in reality people have very different knowledge, needs and history, which can now be met as the technical limitations disappear.

The potential for relevance, intimacy and understanding of intention is enormous, and it is risky to leave that field to the tech giants. Here is the potential for an extremely democratic form of communication, if it is structured right. People already use AI to understand complex news, make summaries, compare sources and answer follow-up questions, all user needs with journalistic potential.

### Questions the liquid raises

- In journalism the single story unit, such as the article, has always been the paper of record, where the first draft of history lies in fixed form: the archive. What is the system of record in the era of liquid content? What is the underlying data?
- How does one avoid echo chambers, or colonisation of our inner life?
- If the information we receive has already been processed by an agent, how should it choose, and by what parameters? How should the publisher influence how their work is interpreted, if the publisher has any control at all over the interface it is interpreted through?
- Understanding the user's context and intention may become the new demand signal, rather than the user's clicks or time spent as before. The more knowledge of context a news medium has, the better service it can give and the harder it becomes for the user to switch. Power lies to a high degree with whoever has the interface, the place where the user interacts with the information, rather than with the medium that delivers some of the information. Right now that interface for liquid content lies very largely with the tech platforms, which gain extremely great control and direct contact with users, leaving journalistic media trailing on relevance, intimacy and intention, even though AI is partly dependent on the media's content.
- It becomes decisive that the producers of content also gain access to the demand signal, and society needs a kind of common ground. The shared front page showed what other people were also following and so made the shared public conversation more shared. Here could lie an essential task for journalistic media, possibly in larger communities. Right now there are no shared frameworks and structures that reward quality in liquid content. A new market is forming and will be shaped by those who build now, and the disciplines that journalism and the scientific method developed over centuries, truth-seeking, accountability and self-correction, are the operating principles that market will require.

Here lies a great potential, and an equally great threat, which will require experiments, adaptation and large resources if media are to learn to speak the liquid language fluently.

## The other way: human first

There is also an alternative path to successful existential innovation: very personal content with a clear voice. Call it human-first content. Such formats have already triumphed on social media among creators, influencers and many others, and already mark news media, in some forms of expression more than others. In an AI era this type of content has even greater potential, because the thirst for real people and real voices who know what they are talking about, or at least do it authentically, only grows.

While half of the largest news sites in the United States lost a fifth of their traffic in the year to April 2026, newsletter platforms grew, perhaps because they do not sell artefacts, such as articles, but clear, trustworthy voices. News creators and influencers have seen marked growth in recent years. A key to their success is understanding the forms and formats of communication on social media: taking formats that already work there and translating them to news and politics. Young audiences have chosen video platforms, not the established media, so one has to come to them and use forms that reach them. Authenticity is a new currency, and trust arises not from striven-for objectivity but from competence, integrity and goodwill, meaning close contact with one's community.

Established media too have great potential to step far more offensively into human-first content: building trusted voices, and turning journalists into voices and stars. It is not easy, because journalistic norms and organisational history can be in tension with more personal, human forms of storytelling. Some media choose instead to make the medium the star rather than the individual journalists, even while using a fairly personal form in audio.

Some media let creators and influencers make content with them, systematically selecting already-established young creators and then training them, for example in ethics and research tools. It is far easier to go that way, beginning with creators who already have reach and who then learn journalistic standards, than to start with journalists who must learn to tell like creators. Creators are audience infrastructure: they bring new users to the medium's other offerings. When trust has no reach, it has failed, and if established media do not engage, the public service of the future will be built outside them. Such a programme is built from small, low-friction experiments that are continuously evaluated.

Classic media are taking smaller steps in the same direction: dropping the idea of writing without a byline, or building the medium around people with very clear expertise and voice. The transformation is not without difficult trade-offs. One dilemma is how to unite the pace of a daily digital publishing rhythm with clear personalities of high expertise and with fundamental culture and workflows. Another is how clear voices are united with a shared brand: is one a loose working community of original voices or a more unifying club, and in that case, a club for whom? Many media approach the same dilemma from the opposite direction, because they must learn to unite a clear media brand with the development of freer, personal voices.

At a deeper level there are parallels to the dominant storytelling forms from before the Gutenberg parenthesis. Before books, the troubadour, the always personal narrator, was at the centre, as in today's human-first content. When everything flows, we seek the clear voice. This places demands on those narrators' standards for facts and ethics, and precisely there lies a potential for news media and narrators with journalistic ballast to make something that fulfils a fundamental need in the information landscape.

## The danger in the middle position

Both paths, the liquid and the human, hold important potential. But media and journalists must choose. Bet on one or the other, or at least be very conscious of which path you choose if you work with both. The barbell strategy describes how everything that falls between the two outer poles can be squeezed so that the middle collapses. Within investment the barbell strategy is a bet on both the very safe, for most of the investment, and the very risky, for a smaller part, and here too the middle position is to be avoided.

The danger lies in half-hearted attempts at the liquid, or content that is a bit personal but at the same time fairly classical, so that one, as journalist or medium, is not really anything or anyone. Better to speed up and throw oneself into liquid experiments, or slow the pace and let human stories and voices unfold. In many other forms of communication the barbell tendency is coming through in these years: music, games, film, video and television often succeed at two extremes, very superficial and fast, or very deep and long.

Existential innovation is about choosing and taking responsibility upon oneself. That holds here too, where the middle position seems easy but carries a marked risk of irrelevance.

Used wisely and consciously, the two positions are not each other's opposites. There can be great potential in using AI tools to support human-first content. Where AI tools are widely used, the plan is that they free time to make what is judged the core of the journalism: people making so-called super content, the stories AI cannot make, which often require close human contact and often convert new subscribers. Many of the competences prized in the classic digital age, speed, fast writing, the journalist as runner, are no longer so much in demand because AI makes the first draft of much content; instead the ability to make super content is sought. So AI takes over many small tasks so that the big, important things, such as telling as a human being, can be left to humans.

The greatest potential probably lies in using AI far more directly to support human-first content, where a voice has a host of artificial agents, producers and other world-builders to lift it. The voices that manage this can gain an extreme competitive advantage in future. But it requires big experiments and courage.

<!-- /canon/concepts/megatrends.md -->

---
type: Concept
title: Megatrends
description: Long-term, large-scale forces that hold their course even in turbulent times, global in scope but local in impact.
status: stable
use_when: "someone asks what counts as a megatrend, how it differs from trends and weak signals, or which long-term forces can be treated as relatively certain"
depends_on:
  - /canon/concepts/trends.md
  - /canon/concepts/drivers-of-change.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Vocabulary of the Future"
  - id: ref-megatrends
    resource: "CIFS (2026), Megatrends: The foundations of long-term change, chapter Part 2 — Constructing megatrends"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 52 to 57"
  - id: root-naisbitt-1982
    resource: "Naisbitt, J. (1982), Megatrends: Ten New Directions Transforming Our Lives"
---

# Megatrends

Long-term and large-scale transformative forces that profoundly shape both the present and the future.

- For the most part, megatrends stay their course even in turbulent times.
- They shape the future landscape of societies, economies, industries and cultures over extended periods.
- While they are global in scope, their impact varies locally.
- In a principally uncertain and complex world, megatrends help us recognise that there are also relatively stable, yet powerful, forces at work in shaping future outcomes.

## CIFS definition

Megatrends are durable, directional structural forces that reshape the conditions under which societies, individuals and organisations across the world operate. They are historically specific rather than permanent features of human societies, resilient to individual action and short-term disruption, and grounded in dynamics strong enough to persist for decades.

## Historical, durable and non-linear forces

- Megatrends are historically situated rather than transhistorical forces. Transhistorical forces are permanent features of human societies, such as demographic change or technological development, which are sometimes considered megatrends. Some megatrends can be understood as historically specific configurations of such processes, the Inversion of the Population Pyramid as a configuration of demographic change, or the Rise of Embedded AI as a configuration of technological development, but megatrends do not persist indefinitely. They emerge from a specific configuration of conditions (that could in principle be different), unfold through distinct mechanisms, and have systemic and directional effects that run their course over decades.
- Technological development and demographic change do not exhibit these properties. They are features of every human society, take different forms across time and place, and do not depend on any specific configuration of conditions. Treating them as megatrends would be like treating 'social change' or 'conflict' as megatrends: too broad to be analytically useful and too permanent to tell us much about what makes the conditions of change in the present and immediate future distinct.
- Megatrends do not necessarily unfold in a linear fashion. Even though they persist over the long term, they can suffer temporary interruptions, and a disruption may last several years without spelling the end of the megatrend. The Green Transition has faced several interruptions, including energy crises pushing some countries back toward fossil fuels in the short run, or powerful political leaders working against green energy. These disruptions may have temporarily slowed the trajectory but have not ended it. The structural conditions and imperatives that necessitate a green energy transition in the long term are too powerful to be counteracted by such short-term disruptions.

## Typology of representation

- Megatrends, and all trends, can be represented in various ways, owing in part to differences in the kind of evidence that can substantiate them. Some are primarily supported by measurable developments and data that can be tracked over time, while others are primarily explained through observation and interpretation that cannot easily be measured in quantitative terms, often the case with megatrends relating to systems, values and social practices. Every megatrend always carries elements of both.
- The simplest form of representation is growth or decline trends, tracking a continuous increase or decrease in a set of measurable variables, such as the growth in urban populations as a share of the global total. Growth or decline can also be represented qualitatively, where a phenomenon is recognised to be increasing or decreasing in strength or significance even though the evidence is too qualitative to be measured precisely.
- Other trends are represented as transitions or shifts from one state to another, in which the elements of a system are rearranged into a new pattern, such as the shift from a unipolar to a multipolar world order. Shifts like this can rest on both quantitative and qualitative evidence.

## Megatrend diagnostics

CIFS has developed a diagnostics tool that tests a megatrend candidate against the definition's criteria, so that the process of megatrend selection rests on a shared, transparent and repeatable standard. The tool helps conceptually distinguish megatrends as higher-order, structurally significant transformations from shorter-term developments, transhistorical processes, or overly diffuse descriptions of change. This is consistent with CIFS' treatment of megatrends as analytically bounded aggregate patterns that help frame the long-term contextual environment rather than explain specific outcomes on their own.

Each criterion functions as a diagnostic gate. A 'No' at any stage indicates that the phenomenon does not qualify as a megatrend candidate under the CIFS definition. Although the tool may seem to encourage binary yes/no assessments, each gate calls for interpretation and judgement. The definition does not point to one definitive set of megatrends, and the eleven trends defined by CIFS are not necessarily an exhaustive list. One organisation applying the same criteria might draw boundaries or weigh evidence differently, group developments in another way, or be motivated by different domain expertise. This is not a weakness of the approach but a product of the nature of megatrends as abstractions that we try to represent analytically.

### Figure: CIFS megatrend diagnostics

A vertical flowchart of seven numbered gates. Each gate is a box containing a question and its explanation. A 'yes' below each box passes the candidate down to the next gate; a box to the right gives the 'no' outcome that disqualifies it. Passing all seven gates qualifies the candidate as a megatrend under the CIFS definition.

| Gate | Test | If no |
|---|---|---|
| 1. Can we define what is changing? | A megatrend candidate must have clearly defined boundaries: what it includes, what it excludes, and what evidence would count as support. 'Acceleration' and 'systemic complexity' are sometimes named as megatrends, but neither passes this gate. Both describe properties of change itself rather than a domain within which change occurs. | Not analytically clear |
| 2. Is there a clear directional pattern? | The direction of a megatrend must be clearer than mere 'change', though it may follow different patterns: growth or decline, transition or shift, and others. | No clear direction |
| 3. Will it have transformative societal impact? | A megatrend must reshape the conditions under which societies, people and organisations operate, not merely be something big, persistent or widespread. | Not transformative |
| 4. Is it grounded in dynamics likely to persist for decades? | Many things feel important and durable in the moment, to the extent that they are mistaken for deeper structural change. A megatrend must be grounded in dynamics that have built up over years and are robust enough to be sustained over decades. | Not structurally durable |
| 5. Is it historically situated, not transhistorical? | A megatrend must be rooted in a specific configuration of society rather than being a permanent feature of it. Demographic change is transhistorical, since it has always happened. Population ageing, by contrast, is historically situated: a distinct demographic trajectory produced by present conditions. | Too permanent |
| 6. Is its momentum resilient to individual action and short-term disruption? | All megatrends are contingent on human action. While they can suffer temporary interruptions, they cannot be easily reversed by single actions or events, unless those events are as rare as they are transformative in scope and impact. | Too contingent |
| 7. Is the evidence base defensible? | A megatrend must be supported by evidence from a diverse range of sources. The underlying body of evidence must be coherent and not selectively chosen to fit a conclusion. | Not sufficiently supported |

## Origin and other definitions

- The term was coined by John Naisbitt in 1982. Trends, like horses, are easier to ride in the direction they are going: if we know where the horse is heading, we can position ourselves to ride with the change rather than be overtaken or run over by it. Megatrends are less about prediction and more about awareness of the direction of travel.
- The European Commission defines a megatrend as a long-term driving force that is observable now and will continue to have a global impact in years to come.
- In a principally unpredictable world, megatrends stand out as the only relative certainty we have and give points of orientation for the longer term. Their trajectory and velocity are not set in stone, and which megatrends jump out depends on the country and sector in focus. You cannot hide from a megatrend; the only real choice is how to respond.

## A checklist and a hierarchy

- Is this a megatrend? Multidisciplinary rather than narrow; a driver of change with transformative power; breadth, meaning a far-reaching, global effect; a long timespan of ten to fifteen years; forward focused, defining the future world.
- Megatrends sit on top of a complex weave of trends. Sub-trends are observable or measurable directional shifts with narrower scope or impact, possibly shorter lived, which may even run counter to a megatrend. Weak signals are subtle, often early indicators of emerging shifts that are not yet widely recognised, with the potential to significantly impact the future but which may also fade away. There is no single correct way to group trends; different organisations and futurists cluster them differently.
- Megatrends are not independent of one another. They interact, overlap and reinforce: demographic developments affect technology, economic models and regulation, and technological breakthroughs reshape economic models and societies. The ripple effect is strong.

<!-- /canon/concepts/organisational-preparedness.md -->

---
type: Concept
title: Organisational preparedness
description: Preparedness is the capacity to challenge assumptions, experiment and turn signals into action, treating uncertainty as a feature and knowing when innovation is incremental and when it is radical.
status: stable
use_when: "the person asks whether their organisation is ready for change beyond the technology, or needs to tell incremental from radical innovation"
depends_on:
  - /canon/concepts/futures-driven-innovation.md
  - /canon/concepts/uncertainty.md
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, section The need for organisational preparedness"
---

# Organisational preparedness

How often do you pause to consider what your organisation could look like 10 years from now? Do you assume your role and your sector will still exist in broadly the same form? What assumptions about consumer behaviour are quietly shaping the decisions you make today?

## What preparedness is

- Organisational preparedness goes well beyond technical readiness. It is about building the capacity to challenge internal assumptions, experiment, learn across functions, and recognise how, and when, signals should be turned into strategic action.
- It demands the discipline to distinguish between immediate gains and longer-term relevance.

## Cultural as much as operational

- Many organisations already have teams or individuals testing new approaches, experimenting with AI-mediated workflows, identifying new ways of doing things or sensing that old processes no longer fit. Yet these experiments often remain disconnected from strategic decision-making.
- Preparedness means noticing them, legitimising them, and connecting them into broader learning loops rather than treating them as isolated developments.

## Uncertainty as a feature

- Organisational preparedness means accepting that uncertainty about the future is not a temporary inconvenience. The future does not arrive only when technology matures. It begins when present assumptions no longer hold.
- Organisations that treat uncertainty as a feature, and an opportunity for innovation, rather than a bug, are better placed to position themselves in the future before change becomes unavoidable.

## A more explicit language for innovation

- Too often, innovation is used to describe everything from minor optimisation to transformative reinvention. The distinction matters.
- Incremental innovation primarily improves what already exists. Radical innovation asks whether the underlying logic should change.
- In an AI-mediated world, organisations need both, but they must know when they are engaging which, and why. This is what CIFS calls futures-driven innovation.

<!-- /canon/concepts/reperception.md -->

---
type: Concept
title: Reperception
description: Shifting perspective to see that the future can differ from the past and from current expectation, the goal most foresight tools serve.
status: stable
use_when: "someone asks what foresight is ultimately for, or how scenarios shift people's sense of what the future could be"
depends_on:
  - /canon/concepts/scenarios.md
  - /canon/concepts/worldview.md
  - /canon/principles/process-matters-as-much-as-outcomes.md
  - /canon/principles/explore-the-future-before-the-present.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Vocabulary of the Future"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 30 to 114"
  - id: root-wack-reperception
    resource: "Wack, P., on reperception, as cited in CIFS teaching material"
---

# Reperception

The process of shifting perspective to think of the world and of the future in a new way, recognising that the future can be different from the past or from what one currently expects.

- One of the main goals of futurists and foresight practitioners is to facilitate reperception, for example by utilising scenarios or other foresight tools.
- Reperception is a key element in developing systems and strategies that can respond to emergent futures in the face of uncertainty.

## Origin

- The term comes from Pierre Wack, one of the pioneers of strategic foresight and the first to develop the use of scenario planning in the private sector, as head of strategy at a major oil company. He defined reperception as awakening to the possibility of the future being different from the past, or from how one expects it to be.
- He also held that the most important and most difficult task for people working with strategic foresight is to facilitate this transition: helping people think of the future in new ways. This is why the foresight process is at least as important as its final outcomes. The future is not a destination but a tool, and the process should develop learning, broaden participants' horizons and build a shared understanding of potential outcomes.

## Reframing to create reperception

- What scenarios essentially do is reframe in order to create reperception, in contrast to 'predict and control' approaches. We learn about the present through the lens of the future, rather than understanding the future from the perspective of the present.
- Reframing makes people mindful of the frame they have been using to make sense of the world and the future, the 'official future', and equally of what is left out of that frame. It occurs when alternative, plausible future outcomes are contrasted to reveal, test and redefine the given frame, after which actions can be rehearsed within the alternative frames to generate new shared knowledge and insights.
- The purpose of developing scenarios is not to make predictions but to challenge assumptions, bias and ignorance about what could be true in the future, and to counteract the tendency to believe that the future will merely reflect the past or adhere to a specific vision. Rather than accounting for every possible event leading to a scenario, the aim is reperception: an alternative plausible view that lets the organisation navigate and explore the implications.

## Memories of the future

- A neuroscientist has proposed that it is possible to proactively engage with the future and 'memorise' it by rehearsing it through futures thinking, so that when one is confronted with change not previously encountered, it nonetheless exists in some form in one's memories of the future: building a repertoire for future use. Scenario planning can be understood as such a rehearsal for leaders.

<!-- /canon/concepts/rewiring-starts-in-our-heads.md -->

---
type: Concept
title: Rewiring starts in our heads
description: Innovation in media fails less for lack of ideas than for lack of time, authority and the safety to ask a stupid question, so leaders must protect the effort of thinking differently and share the power to change what gets pursued.
status: stable
sources:
  - id: root-naij-fojo-2026-vardar
    resource: "Vardar, S. I. (2026), Rewiring organisations starts in our heads, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
use_when: a plan assumes people can question assumptions on top of daily work, or an idea was dismissed before anyone asked what the user needed
---

# Rewiring starts in our heads

Asked to imagine a newsroom in 2036, most people picture today's newsroom with some future sprinkled on top. We are conditioned to think in certain ways, so a reimagined thing can look new on the outside while the core stays unchanged. Sara Inkeri Vardar's conclusion, after five drafts of trying to come up with a solution, is that what journalism needs most may not be another brilliant idea but the curiosity to question the assumptions that shape the ideas in the first place.

## Are we solving the right problems?

- The crisis facing journalism is not necessarily experienced as a crisis by the public. People get on with their lives, find information elsewhere and do not feel anything is missing.
- When young people do not read the articles, the discussion turns to shorter articles, video or a new feed: new ways to deliver traditional journalism, without understanding what people are looking for. What if the problem is not the format, but information needs not met, barriers not noticed, questions not asked?
- Journalism's democratic responsibility goes beyond giving people what they ask for, but that should not make it less curious about the people it serves. How many product ideas begin with a genuine understanding of needs, and how many with an assumption about what will make people consume more of what is already produced?

## The value of a stupid question

- A proposal to let readers adjust the complexity level of an article with AI met immediate and legitimate objections: nuance, meaning, editorial responsibility. The proposer left feeling she had suggested something against the principles of journalism, when she was trying to make it accessible.
- Accuracy, nuance and responsibility are not details to ignore, but making journalism accessible to people who struggle to understand it is a journalistic ambition too. Journalists can protect editorial integrity so hard that they dismiss possibilities too quickly; developers can focus so hard on what is possible that they underestimate the consequences. Neither should end the conversation, and somewhere among the reasonable concerns and the hesitation to sound stupid, the user is forgotten.

## The burden of innovation

- Thinking differently is exhausting. Questioning the assumptions behind the work means giving up the certainty of knowing how it works and what the outcome will be, and doing so on top of deadlines.
- Research into innovation in established Nordic media organisations found the problem was rarely a lack of ideas or ambition but the difficulty of creating the time, resources and authority to act on them. When new initiatives compete with everyday operations, operations win: existing products have customers, deadlines and measurable results; new ideas come with assumptions, not KPIs. People are asked to create something unpredictable while being judged by how predictably they deliver.
- To do more than improve what exists, protect time and resources to question assumptions and to experiment with ideas whose outcomes cannot be predicted. Even if they never lead to a product, they might change how journalism is understood.

## Soft skills, really?

- Ideas never shared, questions never asked for fear of sounding stupid or because everyone else seems to know better. Creating the safety to share an idea before it is fully formed is among a leader's most important responsibilities.
- These are dismissed as soft skills, yet the ability to ask a question without knowing the answer, disagree with someone more experienced or share an unfinished idea decides which possibilities an organisation ever explores.
- It is also about giving up power: who decides what is worth pursuing, who controls the resources, and who is willing to give up some of that control. The paradox is that the more pressure the industry faces, the more it needs to innovate, and the more protective it becomes of resources, roles and influence.

## The newsroom of 2036

- Teams of journalists, developers, designers and people from backgrounds not traditionally associated with journalism, with the time, resources and authority to investigate problems together: not handed a product brief with a predefined solution, but encouraged to explore questions the organisation has not yet answered, with the people it is trying to reach involved in the exploration rather than invited in at the end to test what was already decided.
- Different pathways into journalism for people who do not look, think or work like those already inside, rather than diverse talent hired into the same structures. If you want the status quo questioned, it is counterproductive to recruit only people trained to see the world the same way.
- Organisations honest about what makes this difficult: the fear of being wrong, the tendency to protect what we have, and the power we might have to give up.

<!-- /canon/concepts/scenarios.md -->

---
type: Concept
title: Scenarios
description: Plausible, coherent narratives of alternative futures, built in sets to be contrasted, and never right or wrong.
status: stable
use_when: "someone asks what a scenario is and what it is for, or treats scenarios as forecasts to be judged right or wrong"
depends_on:
  - /canon/concepts/drivers-of-change.md
  - /canon/concepts/uncertainty.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Vocabulary of the Future"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 92"
---

# Scenarios

Plausible and coherent narratives describing alternative futures, based on key drivers and uncertainties, and expanded through storytelling to create credible and compelling images of how the future may unfold.

## Scenarios exist in sets

- In foresight, scenarios often exist in sets, allowing different futures to be contrasted with one another and with the present, helping to break away from a deterministic view of the future.

## Scenarios are not predictions

- They are not meant to be 'right' or 'wrong', 'good' or 'bad'.
- Their function is to challenge current assumptions and provoke us to think about the future in new ways, including outcomes 'beyond the numbers' that might otherwise be overlooked.

## Scenario planning

- The discipline of scenario planning offers a structured approach to exploring a set of plausible future conditions that are different from the present.
- This allows organisations to widen their strategic perspective and consider alternative future outcomes that may be difficult to grasp in the present.

## What scenarios are

- Compelling, plausible narratives about plausible futures, to facilitate a futures-oriented conversation and understanding.
- Focused on potential changes in the external environment, which in turn influence the strategic environment and strategic decisions.
- Guides that inform organisations and people about future threats and opportunities, to better plan for the future.
- A way to foresee potential outcomes 'beyond the numbers', in an era where forecasts and projections are not enough.

## What scenarios are not

- Not predictions of the future, and not futures to which probabilities should be assigned.
- Not focused on operational options created from an inside-out perspective.
- Not strategies in and of themselves, though they provide insight for planning.
- Not the same as trend analysis, empirical forecasting or other foresight methods.

<!-- /canon/concepts/scoping-a-foresight-project.md -->

---
type: Concept
title: Scoping a foresight project
description: Scoping settles why the project exists, which decisions it should influence and who must be engaged, not only the focal issue and time horizon.
status: stable
use_when: "a foresight project is being set up and its purpose, the decisions it should influence, realistic expectations or who to involve are not yet settled"
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Scoping a Foresight Project"
---

# Scoping a foresight project

Scoping a foresight project properly is key to ensuring impactful outcomes, and a lot of consideration must go into scoping a foresight project well. Foresight is applied in many different contexts, and takes on many different forms. Your approach may look very different depending on the purpose of your foresight intervention and where the request and mandate come from. Foresight in organisational settings often carries a particular requirement, in that foresight efforts should always be aligned with the specific organisational context and strategic objectives.

## More than foresight properties

- Scoping involves more than just deciding on 'foresight properties' like the focal issue, scope boundaries (making sure that the scope does not become too broad or too narrow) or time horizon.
- It is equally important to understand why you are undertaking the foresight project, within what system or context the project exists, and which decisions you are hoping to influence.
- This is critical in avoiding a mismatch between what the people/team who asked for the project want vs. what they need.

## Managing expectations

- It is also a crucial part of managing expectations of what can feasibly be accomplished with the foresight intervention.
- Oftentimes, foresight interventions are expected to achieve things they cannot or should not do, setting them up to underwhelm, or outright fail.
- Being realistic about these answers is key, especially when the project sponsor may not have the experience needed to properly set expectations.

## Engaging the right people

- Part of the scoping process is also to make sure that you are engaging the right people as a critical factor for the success of any project.
- This helps ensure that there is a mandate and buy-in from the right people and decision makers, and hence, that you have their permission to challenge the status quo.
- Who you speak to and who you choose to bring with you on the journey will affect the insights and impact of your project.

<!-- /canon/concepts/second-brains.md -->

---
type: Concept
title: Second brains
description: A second brain organises knowledge outside our heads at individual, team and organisational levels so the context behind a decision can be returned to and reused, with its sources, dates and the line between evidence and interpretation.
status: stable
sources:
  - id: ref-hvitved-2026
    resource: "Hvitved, S. (2026), Futures friction: a new approach to how media organisations remember, learn and reimagine, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
  - id: root-forte-2023
    resource: "Forte, T. (2023), Building a Second Brain: The Definitive Introductory Guide"
  - id: root-bush-1945
    resource: "Bush, V. (1945), As We May Think, The Atlantic Monthly"
  - id: root-karpathy-llm-wiki
    resource: "Karpathy, A. (undated), LLM Wiki, a published note on GitHub"
use_when: an organisation wants to learn from what others have tried and why, or is deciding who controls shared knowledge, what can be reused and which AI systems may access it
---

# Second brains

Working with media organisations shows how difficult it is to connect innovation across teams and build on what others have learned. Ideas struggle to survive daily operations or find support beyond the team that developed them; those that challenge the current business are measured by metrics that overlook their future value; others may never learn what a team tried or which assumptions shaped its decisions. An unsuccessful experiment can still produce valuable learning if the context needed to understand it is preserved, and a good idea that does not fit one project may be gold in another.

## The weight of history in news organisations

- Protecting sources, keeping a scoop from competitors and guarding rights are important parts of the work and culture, and those instincts shape how knowledge moves inside the organisation. Competition between desks can make sharing harder, and the reasoning behind a project may stay with the people who made it.
- There is also exhaustion from the ongoing waves of change, from print to web, mobile and platforms. Any practice that asks media organisations to share and question what they know must be built within the boundaries source protection and rights require, and with as little extra effort as possible.
- Where to start when people are exhausted and used to protecting knowledge: by making it easier to learn from what others have tried and why, bringing that learning into existing workflows.

## The concept

- A second brain is a way of organising knowledge outside our heads so we can return to it, connect it and use it in new situations. The term was popularised by Tiago Forte for personal knowledge management; the ambition is older. Vannevar Bush's memex of 1945 was a desk-like device for storing books, records and communications, connected through trails of association that could be revisited and shared.
- It starts with collecting contextual data: the purpose of an experiment, the audience insights it drew on, what was tried, why a decision was made and where people disagreed. A report saying "user demand was low" tells us little about why; the context gives another team something to work with.
- Second brains operate at connected levels: individual second brains holding employees' own knowledge; team second brains capturing shared experiments and learning; and an organisational second brain preserving strategic reasoning across projects and connecting innovation to the organisation's purpose and values.
- Andrej Karpathy's LLM Wiki is a related approach: a collection of linked text files that an AI model writes, organises and updates from source material, while people select the sources and guide the work and the original material stays separate from the generated knowledge.

## Context as infrastructure

- Making context machine-readable lets people and AI agents work with it across projects. Sources, dates and the conditions behind a conclusion need to travel with it, as does the distinction between evidence and interpretation; otherwise a confident interpretation could become accepted as evidence simply through repeated retrieval.
- Formats and protocols are emerging to support parts of this, for structuring knowledge, connecting AI applications to data and tools, and communication between agents. They address technical layers; they do not settle organisational choices about access, ownership or interpretation.

## How it could work

In Hvitved's imagined media organisation of 2030: a journalist and a colleague record a conversation about a new local information service and process it on a local device, where it stays private. An agent suggests an outline for her individual second brain, capturing the idea, the reasoning and the open questions; she decides which parts to share, and the approved outline enters the team second brain while her notes and the recording stay hers. Contributing an idea does not give the organisation access to everything behind it. The team draws on the organisational second brain, and within minutes an agent finds an experiment from four years earlier whose summary says demand was low, while the original evaluation shows people found the service useful but disliked installing yet another proprietary app. The team can see what was tried, why it was judged unsuccessful and whether that conclusion is relevant now, along with the strategic reasoning behind the earlier project. Decisions, reasoning and unanswered questions enter the team second brain; learning that could help other projects reaches the organisational one, and residents can follow the reasoning the team chooses to share and contribute their own experience.

## Where to start

- Start with one current innovation project. Bring together the relevant context: earlier experiments, audience insights, signals of change and the reasoning behind the proposal. Make it machine-readable and preserve its sources.
- Agree who controls the knowledge, what can be shared and reused, which AI systems can access it and how you retain control if you change providers. Source protection, privacy, copyright and cybersecurity shape these choices from the start: what stays local and what goes through cloud services, what can be exported to other systems to avoid lock-in, who owns what.
- Begin in a controlled environment with limited access and carefully selected material, then assess what can be connected more widely.

## Key things to consider

- The efficiency AI brings to collecting, connecting and retrieving knowledge can go to cuts or to thinking, meeting colleagues and spending time with the public; in the imagined organisation, leadership has protected that time and recognised contributions to collective learning.
- Many conditions would need to hold for this to take shape, and it is unlikely to unfold exactly as imagined. The value of the scenario is to explore what could change and what to prepare for, including the choices about ownership, time and resources that make this way of working possible.

<!-- /canon/concepts/service-not-publication.md -->

---
type: Concept
title: Service, not publication
description: The article is a form and journalism a function, so a newsroom can organise around the public questions it commits to keep watching, promising we will keep watching this and treating correction and maintenance as product design.
status: stable
sources:
  - id: root-naij-fojo-2026-roy
    resource: "Roy, N. (2026), The next era of journalism will be defined by service, not publication, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
use_when: a plan's responsibility ends at publication, measures stories produced, or begins and ends with a box where someone types a question
---

# Service, not publication

Journalism has been made easier to publish, faster to distribute and simpler to consume, yet it still asks an extraordinary amount of the people it serves: notice the story, recognise why it matters, remember what happened last time, find the update, work out what has actually changed. The newsroom does the difficult work of reporting and leaves much of the work of staying informed to the reader. Nikita Roy's point is that this is not an engagement problem but a limitation in how journalism has been designed. A finished article is not always a finished public service.

## Form and function

- Verification, scrutiny, explanation and helping people navigate uncertainty are journalism's functions. Articles, broadcasts, newsletters and podcasts are forms used to deliver them.
- The forms matter. A narrative investigation can reveal a pattern no collection of personalised answers could capture; a shared story can create public attention and political pressure. The point is not to replace the article but to stop treating it as the boundary of responsibility.

## A newsroom organised around questions

- Imagine a newsroom organised not only around stories to publish but around public questions it commits to follow: will the promised housing be built, what is happening to local water quality, how is a new policy affecting families. Each question has a history, sources, unresolved claims, competing accounts and developments worth watching.
- Reporting still creates the knowledge, but it becomes a living, accountable record that can be revisited, interrogated and updated as the world changes.
- The invitation changes from "read this" to "we will keep watching this". That is a more demanding promise than an alert when a new article appears: it means noticing consequential change when no article was planned, sometimes saying that nothing has been resolved, and acknowledging when the newsroom can no longer reliably keep watch.

## Making continuity sustainable

- None of this began with AI. Community-centred newsrooms have long answered individual questions and followed public promises; one has run a text-message service since 2016 that delivers housing and utilities information on demand and lets residents reach a reporter, now using AI for property lookups and to surface what residents ask about, while journalists write every message.
- What changes with AI is the range of connecting work that becomes feasible: sifting sprawling agendas, comparing revisions to public documents, connecting a development to years of reporting, translating, adapting verified explanations for different levels of familiarity.
- AI may lower the cost of connecting information, but it does not remove the cost of being responsible for it. The better the service, the more the responsibility matters: if an error travels into a text message, a translation or an audio briefing, the correction cannot live only on the original article. Editorial responsibility becomes product design.

## Bigger than a chatbot

- A service built only around answering users' questions leaves a gap: people may not know what they need to ask. Journalism matters precisely because people often do not know what is happening or which question to ask. An interface that answers perfectly formulated questions can leave the biggest blind spots untouched.
- The systems worth building combine responsiveness with editorial initiative. Personal relevance should be a doorway into public understanding, not an escape from it; people may receive different formats, languages or levels of explanation, but not different underlying facts, and no algorithm should decide that an inconvenient truth is irrelevant because nobody asked.
- The service need not look like AI at all. It might arrive as a text message, a short audio explanation or a timed update; its form is irrelevant as long as it makes journalism more useful.

## What becomes of the newsroom

- If more people encounter reporting through assistants and platforms they do not associate with the publisher, newsrooms risk becoming invisible suppliers of raw material for somebody else's product. Publishing more articles will not solve that. A newsroom's enduring value may lie in the knowledge it can stand behind: what it has verified, what remains disputed, what has changed, which questions it continues to investigate.
- The reporter remains indispensable as the person who understands context, challenges official accounts, notices what is missing and earns trust. Editors become stewards of commitments that extend across time. Product and engineering teams turn judgement into systems that can be tested, corrected and sustained. The newsroom becomes an institution that remembers, checks and returns.
- Success changes with it: not how many stories were produced or how much attention they drew, but whether people were better able to understand the forces shaping their lives, recognise what had changed and exercise their own judgement.

<!-- /canon/concepts/strategic-foresight-fallacies.md -->

---
type: Concept
title: Strategic foresight fallacies
description: Organisations misuse foresight by seeking certainty, force-fitting it into planning, collapsing it into operations, expecting it to deliver strategy, or mistaking the activity for action.
status: stable
use_when: "an organisation seeks certainty from foresight, squeezes it into planning routines, or expects it to hand over a strategy by itself"
depends_on:
  - /canon/concepts/strategic-foresight.md
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 46"
---

# Strategic foresight fallacies

Flawed ways of reasoning about, or applying, strategic foresight, drawn from CIFS' own experience.

- Engaging with foresight to look for certainty in uncertain times, rather than using it to challenge misguided assumptions that may underpin a false sense of certainty. Authentic strategic foresight serves the opposite purpose.
- Trying to 'force fit' foresight into current strategic practices and the familiarity of existing routines, rather than using it to balance strategic thinking and broaden the strategic perspective.
- Collapsing foresight into operational planning, reducing it to a planning tool for short-term business intelligence or tactical purposes. This narrows its scope and keeps it stuck in the present, when it should transcend immediate priorities and explore longer-term shifts.
- Misunderstanding foresight's epistemic role in decision-making: expecting it to deliver clear, actionable strategy in and of itself, instead of approaching it as one source of insights that widens the strategic perspective. This leads to foresight being dismissed as 'interesting but not useful'.
- Equating the activity of doing foresight with action, while foresight only has strategic value when it informs and shapes concrete decisions and actions. This often happens because the strategic or decision-making purpose of the exercise was unclear from the outset.

<!-- /canon/concepts/strategic-foresight.md -->

---
type: Concept
title: Strategic foresight
description: Systematically anticipates medium- to long-term change through multiple alternative futures, never to predict but to sharpen strategic anticipation.
status: stable
use_when: "someone asks what strategic foresight is and is not, or how it should feed strategy rather than predict"
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Vocabulary of the Future"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 39 to 42"
  - id: root-van-der-laan-2021
    resource: "Van der Laan, L. (2021), Disentangling strategic foresight? A critical analysis of the term building on the pioneering work of Richard Slaughter"
---

# Strategic foresight

A discipline that involves systematically anticipating and preparing for future challenges and opportunities in ways that expand conventional strategic thinking in the face of change. It typically deals with the medium- to long-term future (beyond the current strategic planning horizon) with the overarching goal of enhancing awareness of change and considering multiple alternative futures in ways that generate valuable insights for better strategic anticipation.

## What foresight aims for

- The aim of foresight is never to predict the future.
- In a time where forecasts, projections and linear decision-making methods are not enough, strategic foresight aims to achieve a high-quality view of how the future might show up in the form of new assumptions, behaviours and realities.
- In this sense, the outset for practising foresight should always be to challenge the tendency to favour the 'business as usual' future and to adequately explore viable alternatives.

## Foresight and strategy

- Without foresight, strategy risks becoming blind to contextual change and a recipe for failure when change occurs.
- Conversely, without connection to strategic or decision-making purpose, foresight easily becomes conjecture and disconnected from organisational reality.

## Foresight is not a search for certainty

- Organisations should not engage in foresight to look for certainty. Rather the opposite: they should engage in it to challenge the bias and assumptions that could underpin a false sense of certainty and understanding.
- The main problem arises when organisations 'force fit' foresight into their current strategic practices rather than using it to balance their strategic thinking. Approached that way, foresight ends up reinforcing the original view of the future and fortifying a false sense of certainty.

## How foresight feeds strategy

- Foresight provides insights and input for strategic planning; foresight outcomes are not strategies in themselves. Strategic foresight focuses on potential changes in the external environment and allows alternative futures to be considered, which in turn influence the strategic environment and strategic decisions.
- The foresight process runs from framing and inputs, through scanning and analysis, interpreting and prospecting, to foresight outputs. Those outputs feed into strategy and policy inputs alongside other strategic considerations, and from there into strategy and policy thinking, formulation and planning.
- Foresight and strategy are two halves that come together in order to use the future in a systematic and meaningful way. Exploring the future can be insightful in itself, but its value for strategic planning or policy anticipation lies in its application.

Figure: a flow diagram. On the left, a vertical stack enclosed by a dashed circle and labelled strategic foresight: framing and inputs, then a highlighted foresight box containing scanning and analysis, interpreting and prospecting, then foresight outputs. On the right, several other strategy or policy considerations and inputs. Both streams point down into strategy and policy inputs, which point into a wide bar labelled strategy and policy: thinking, formulation, planning.

<!-- /canon/concepts/the-agentic-information-economy.md -->

---
type: Concept
title: The agentic information economy
description: When machines consume information on people's behalf, information becomes an input to decisions, errors become actions that compound, being right starts to pay, and journalism holds the DNA for the infrastructure it needs.
status: stable
sources:
  - id: root-naij-fojo-2026-fang
    resource: "Fang, S. (2026), The information revolution will not be televised, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
use_when: a plan assumes articles read by people remain the unit of value, or asks what journalism is for when answers reach people through agents
depends_on:
  - /canon/concepts/first-principles.md
---

# The agentic information economy

There are no altars to the gods of showers, card payments or traffic lights. They are among the great achievements of modern life and almost entirely invisible, noticed only when they break. Shuwei Fang's argument is that the information environment of the near future should work the same way: within ten years AI could leave society far better informed, and almost nobody would notice. A new mother six months in, too tired to be informed, has an agent that knows the childcare rules have changed, works out what she is entitled to, drafts the application, tells her the morning a local investigation exposes failings at her maternity unit, and can show her where each claim came from and who checked it. The decisions remain hers.

## What changes

- Machines become the primary audience for information, and information changes category: from a final good read by a person who may or may not act, to an intermediate input into a decision, a transaction or an automated process, often never rendered for a human at all.
- Together these give rise to an agentic information economy, the epistemic bedrock of the wider agentic economy. It could be far bigger than today's information economy, because machines consume without the limits of human attention, and far more complex.

## The price of being right

- When a person misreads something, the error becomes an impression. When an agent acts on it, the error becomes an action: a wrong purchase, a missed entitlement, a recalled product back on the shelf. Outcomes loop back as inputs, so errors compound at machine speed and scale, and because many systems draw on the same few models, they can fail together. Correlated, automated error is a different class of risk from misinformation.
- It is also a different class of opportunity. For as long as there has been a digital information market, being right and sounding right have fetched roughly the same price, except in finance and a few high-stakes niches. Once the cost of being wrong becomes measurable, provenance, accuracy and the capacity to self-correct could become things that are priced. Being right could start to pay.
- The best version needs conditions that will not emerge by default: ownership and control spread out rather than concentrated, no moral hazard in how information is gathered and verified, and a myriad of native protocols, institutions and rules.

## Finance as the comparison

- Most people have only a folk understanding of finance, yet hand it their salaries and pensions, because protocols, institutions and regulation let them delegate trust, legibility and risk.
- The agentic information economy will need analogous systems. Finance has SWIFT and shared identifiers; information needs a shared protocol and a standard unit so a claim can be identified and traced. Finance has custodians; information needs trusted holders of dispersed, niche knowledge. Finance has rating agencies; information needs calibrated confidence in its sources. Finance has clearing houses; information needs corrections that reach every system that used the original.
- These systems also decide where value flows. Value is likely to pool at the interface, with whoever knows the most about the user. With the right rails, some share of it, and of the demand signal, could flow back along the chain to those who originate, verify and maintain information, as card interchange fees send a slice of every payment back to the issuing bank.
- Finance also shows how such institutions fail: the rating agencies that blessed mortgage-backed securities before 2008 were paid by the issuers they rated. Journalism and science encode the opposite instincts, independence from those you cover, disclosure of sources and methods, scrutiny by peers, public correction. Those are the right blueprints; whether they are used is being decided while the standards are still soft.

## Roles for journalism

- Journalism's institutions already hold much of the DNA: verification, editorial standards, archives, corrections policies and a working ethic of accountability. Within ten years they could be originating machine-ready, verified events with provenance attached; acting as custodians of a community's local and niche knowledge; rating sources and attaching calibrated confidence to claims; underwriting the information agents act on, with liability attached; and running the clearing systems that carry a correction to every system that used the original.
- A system this consequential and opaque needs watchdogs of its own. Covering the agentic information economy becomes a beat, as finance and technology are today. Someone will still need to hold information power to account; the power will simply be harder to see.
- None of this displaces storytelling. Stories are how people come to care, and they will flourish alongside. There is room for a new discipline of information and knowledge that no existing field fully addresses.

## What leaders do now

- Start from first principles: ask what an agentic information economy will actually need, looking well beyond the news industry, rather than searching for a best-in-class version of something that already exists.
- Rethink what the unit of information, and therefore of value, actually is; build the economics around that; develop the skills to work with information in ways the newsroom was never designed for.
- Coordinate, and get into the rooms where the standards for this economy are being written, while they are still soft.

## Key things to consider

- Invisibility cuts both ways. A system in the background that can quietly leave you better informed can just as quietly manipulate you, and you would never know; all the more reason to build it to serve citizens rather than steer them.
- It sits uneasily with journalism's cultural identity as a visible fourth estate wearing its trust on its masthead. The role for journalism in that future may be unrecognisable.

<!-- /canon/concepts/the-cifs-foresight-process.md -->

---
type: Concept
title: The CIFS foresight process
description: Foresight runs from scope through awareness, uncertainty, alternative futures and implications to action, diverging twice and converging twice, and then works future-back to shape decisions.
status: stable
use_when: "the person needs to see where a piece of foresight work sits in the arc from scoping through uncertainties and scenarios to strategic action"
depends_on:
  - /canon/concepts/scoping-a-foresight-project.md
  - /canon/concepts/uncertainty.md
  - /canon/concepts/scenarios.md
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 11 to 135"
---

# The CIFS foresight process

CIFS' approach to applied strategic foresight is a rigorous process around understanding what drives change, making sense of the uncertainties that matter most, and transitioning into strategic decision-making. Much work in the futures field is strong on visioning, scanning, mapping, forecasting and planning but weak on execution, action and operation; the later phases deserve the attention.

## Six phases

1. Scope: setting the parameters.
2. Awareness of change and 
3. Dynamics of change and uncertainty: explore dynamics of change and understand high-impact uncertainties.
4. Alternative futures and 
5. Strategic insights and implications: build scenarios, engage with alternative futures and understand implications.
6. Action: transition from foresight to strategic insights; tuning and rethinking strategy.

The process runs as a double diamond. It diverges across awareness of change, converges to a point at the boundary with dynamics of change and uncertainty, diverges again across alternative futures, and converges through strategic insights and action. Assessing critical uncertainties is a deductive phase that follows the exploratory one; the scenario axes are the scaffolding for the second divergence.

## The exploratory, future-back process

The same arc seen from the strategy side:

- A. Gathering insights about the future and understanding dynamics of change.
- B. Understanding strategic uncertainties and certainties.
- C. Developing alternative futures.
- D. Assessing future strategic implications, and/or
- E. Stress-testing the viability of current strategic elements.
- F. Future-back to widen strategic perspective and shape strategic decisions.

## Key things to consider

- Every futures project is different. Some are large scale, with extensive scenario development, detailed research and stakeholder workshops to identify and advise on future strategic challenges. Others are small scale, perhaps a single workshop with an internal strategy team to explore what is driving change. The tools are adaptable and can be customised to most futures projects.
- Scoping matters. Sometimes a scoping workshop precedes the process, when the client is not sharp on the scope.
- In a real project, the explore phase is a mix of trend research and curation of second- and third-tier things, interviews with experts, and workshops with the client. It is probably the most cumbersome component, and the understanding and sense-making a good futures thinker brings remain key.

## Figure: the CIFS method

Six phases run left to right, separated by dashed vertical lines: scope, awareness of change, dynamics of change and uncertainty, alternative futures, strategic insights and implications, action. A horizontal double-diamond shape widens across awareness of change, narrows to a point at the boundary with dynamics of change, widens again across alternative futures and narrows to a point through strategic insights and action.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="ffmth" viewBox="0 0 560 320" style="display:block;width:100%;max-width:480px" role="img" aria-label="The Copenhagen Method: scope sets the parameters; the shape opens across awareness of change, narrows through the dynamics of change and uncertainty, opens again across alternative futures and closes through strategic insights and implications into action">
<style>
.ffmth text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.ffmth .b{font-weight:500;fill-opacity:.95}
.ffmth .s{font-size:10.5px}
.ffmth .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.ffmth .m{stroke-opacity:.5}
.ffmth .f{stroke-opacity:.2}
.ffmth .d{stroke-dasharray:2 5}
.ffmth .x{font-size:9px}
.ffmth .e{fill:#FFC7A5}
.ffmth .y{font-size:8px;font-weight:500;letter-spacing:.7px;fill-opacity:.9}
.ffmth .i{font-style:italic}
.ffmth text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="320" rx="14" fill="#fff"/>
<path class="l f" d="M24,22 L536,22"/><path class="l f" d="M531.6,24.4 L536,22 L531.6,19.6"/>
<path class="l f" d="M24,286 H536"/>
<path class="l m d" d="M110,32 V204 M195,32 V204 M280,32 V204 M365,32 V204 M450,32 V204"/>
<path class="e" d="M110,146 L195,100 L280,131 L365,115 L536,146 L365,177 L280,161 L195,192 Z"/>
<text x="67" y="48" class="y" text-anchor="middle">SCOPE</text>
<text x="152.5" y="42.5" class="y" text-anchor="middle">AWARENESS OF</text>
<text x="152.5" y="53.5" class="y" text-anchor="middle">CHANGE</text>
<text x="237.5" y="37" class="y" text-anchor="middle">DYNAMICS OF</text>
<text x="237.5" y="48" class="y" text-anchor="middle">CHANGE /</text>
<text x="237.5" y="59" class="y" text-anchor="middle">UNCERTAINTY</text>
<text x="322.5" y="42.5" class="y" text-anchor="middle">ALTERNATIVE</text>
<text x="322.5" y="53.5" class="y" text-anchor="middle">FUTURES</text>
<text x="407.5" y="37" class="y" text-anchor="middle">STRATEGIC</text>
<text x="407.5" y="48" class="y" text-anchor="middle">INSIGHTS &amp;</text>
<text x="407.5" y="59" class="y" text-anchor="middle">IMPLICATIONS</text>
<text x="493" y="48" class="y" text-anchor="middle">ACTION</text>
<text x="67" y="144" class="b s i" text-anchor="middle">Setting the</text>
<text x="67" y="157" class="b s i" text-anchor="middle">parameters</text>
<text x="195" y="222" class="x" text-anchor="middle">Explore dynamics of</text>
<text x="195" y="233" class="x" text-anchor="middle">change and understand</text>
<text x="195" y="244" class="x" text-anchor="middle">critical uncertainty</text>
<text x="365" y="222" class="x" text-anchor="middle">Engage with alternative futures,</text>
<text x="365" y="233" class="x" text-anchor="middle">challenge current assumptions,</text>
<text x="365" y="244" class="x" text-anchor="middle">and understand implications</text>
<text x="493" y="222" class="x" text-anchor="middle">Transition from</text>
<text x="493" y="233" class="x" text-anchor="middle">foresight to</text>
<text x="493" y="244" class="x" text-anchor="middle">strategic insights</text>
<text x="493" y="262" class="x" text-anchor="middle">Stress-testing and</text>
<text x="493" y="273" class="x" text-anchor="middle">rethinking strategy</text>
<text class="ref" x="536" y="304" text-anchor="end">Source: Copenhagen Institute for Futures Studies, The Copenhagen Method.</text>
</svg>
```

## Figure: the exploratory, future-back process

A timeline runs from the present on the left to a year 20XX on the right. A thin cone opens from the present to a large ellipse at 20XX. A thick arrow inside the cone points right, labelled gathering insights about the future and understanding dynamics of change. The ellipse holds four squares in a 2 x 2 arrangement, the scenarios, each carrying a star for strategic implications and a box for stress-tested strategic elements. A second thick arrow points left from the ellipse back to the present, labelled future-back to widen strategic perspective and shape strategic decisions.

<!-- /canon/concepts/the-friction-field.md -->

---
type: Concept
title: The friction field
description: The future unfolds where drivers and enablers meet turners and blockers, so a trend's course is decided by that struggle and very often by timing.
status: stable
use_when: "a trend looks set to continue and the person needs to weigh the forces pushing it against those that slow, stop or divert it, including timing"
depends_on:
  - /canon/concepts/drivers-of-change.md
  - /canon/concepts/trends.md
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 23"
  - id: root-gordon-deft
    resource: "Gordon, A. (2010), A DEFT Approach to Trend-based Foresight"
---

# The friction field

The way future change occurs depends on the outcome of the 'power struggle' between favouring and limiting forces. New trends and developments create friction in the existing environment, and the future unfolds in the friction field.

## The forces

- Change drivers and enablers are the forces that cause a trend to move, and the factors that promote or catalyse a driver. A change driver may itself be a trend.
- Change turners and blockers are the forces that oppose a trend by delaying, stopping or diverting it, and the factors that cause resistance to change.
- Change enters the field on one side; implications for societies, industries and the business environment emerge on the other.

## Reading the field

- Do not take a trend at face value. A trend can relatively easily be identified and analysed, but understanding the forces and factors that either promote or limit it gives the more detailed picture.
- Does the development challenge prevailing social, cultural or ethical norms? Then change is likely to proceed slowly, if at all.
- Whose side is the law on? The law is almost always, by design, a drag on the future, for good and for bad.
- Very often it is about timing.

## Figure: the friction field

A hatched, wavy band labelled friction field runs horizontally across the figure. Change enters from the left; implications, for societies, industries and the business environment, exit on the right. Above the band, downward chevrons are labelled turners and blockers; below it, upward chevrons are labelled drivers and enablers. Inside the band, a small cluster of connected dots represents the interacting forces.

<!-- /canon/concepts/the-futures-cone.md -->

---
type: Concept
title: The futures cone
description: Beyond the present the space of futures widens into possible, plausible, probable and preferable, and foresight works the plausible while forecasting works the probable.
status: stable
use_when: "someone confuses probable with plausible futures, or asks where foresight, forecasting, scenarios and wild cards sit in the space of futures"
depends_on:
  - /canon/concepts/forecasting.md
  - /canon/concepts/scenarios.md
  - /canon/concepts/wild-cards.md
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 22"
  - id: root-voros-2003
    resource: "Voros, J. (2003), A generic foresight process framework"
---

# The futures cone

Everything beyond the present moment is the future. The cone is a conceptual tool that depicts the idea that there are multiple futures, that the future is not pre-defined, and that the further we move away from the present, the bigger the 'opportunity space' becomes.

## The zones

- Possible: future knowledge, what "may happen".
- Plausible: current knowledge, what "could happen".
- Probable: current trends, what is "likely to happen".
- Preferable: the desired future, a value judgement.

## Where foresight works

- Strategic foresight mainly turns its focus towards the plausible future. The probable is the territory of forecasting; what lies around it is foresight.
- Scenarios sit inside the cone as alternative futures. Wild cards sit outside it. Prediction is a single point.

## Figure: the futures cone

A horizontal arrow runs from the present on the left to the future on the right. From the present, lines fan out into a cone that ends in a large oval. Nested regions inside the oval show the successively narrower futures, possible, then plausible, then probable, with a small central dot labelled prediction and small circles inside the oval labelled scenarios; small dots outside the oval are labelled wild cards. Brackets on the right annotate the four zones, possible, plausible, probable and preferable.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="ffcon" viewBox="0 0 560 324" style="display:block;width:100%;max-width:480px" role="img" aria-label="Futures cone: from the present, futures widen into possible, plausible and probable zones, with a preferable zone, scenarios inside the plausible and wild cards inside the possible">
<style>
.ffcon text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.ffcon .b{font-weight:500;fill-opacity:.95}
.ffcon .s{font-size:10.5px}
.ffcon .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.ffcon .m{stroke-opacity:.5}
.ffcon .f{stroke-opacity:.2}
.ffcon .d{stroke-dasharray:2 5}
.ffcon .k{fill:#413C38}
.ffcon .o{fill:#FFC7A5;stroke:#413C38;stroke-opacity:.5;stroke-width:.75}
.ffcon .x{font-size:9px}
.ffcon .u{stroke-dasharray:1 2.6}
.ffcon text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="324" rx="14" fill="#fff"/>
<pattern id="ffcon-w" width="2.6" height="2.6" patternUnits="userSpaceOnUse"><circle class="k" cx="1.3" cy="1.3" r=".5"/></pattern>
<text x="40" y="22" class="x">Everything beyond the present moment</text>
<text x="40" y="48" class="b">Present</text>
<path class="l m" d="M96,44 L262,44"/><path class="l m" d="M257.6,46.4 L262,44 L257.6,41.6"/>
<text x="272" y="48" class="b">Future</text>
<path class="l f" d="M42,84 V290"/>
<path class="l m" d="M50,186 L290,82 M50,186 L290,290"/>
<ellipse class="l" cx="290" cy="186" rx="56" ry="104"/>
<path class="l f d" d="M50,186 L290,114 M50,186 L290,258"/>
<ellipse class="l m d" cx="290" cy="186" rx="38" ry="72"/>
<path class="l m" d="M50,186 L290,172 M50,186 L290,200"/>
<ellipse class="l" cx="290" cy="186" rx="8" ry="14"/>
<circle class="k" cx="290" cy="186" r="2"/>
<path class="l f" d="M50,186 L289,223 M50,186 L289,267"/>
<ellipse class="l m" cx="289" cy="245" rx="13" ry="22"/>
<circle class="l m u" cx="284" cy="101" r="6.5" style="fill:url(#ffcon-w)"/>
<circle class="l m u" cx="323" cy="130" r="4.5" style="fill:url(#ffcon-w)"/>
<circle class="o" cx="276" cy="142" r="4.5"/>
<circle class="o" cx="304" cy="162" r="4.5"/>
<circle class="o" cx="303" cy="216" r="4.5"/>
<path class="l f" d="M291,98 L346,86"/>
<text x="350" y="89" class="s">Wild cards</text>
<path class="l f" d="M300,186 H346"/>
<text x="350" y="190" class="s">Prediction</text>
<path class="l f" d="M307,219 L346,236"/>
<text x="350" y="242" class="s">Scenarios</text>
<path class="l f" d="M433,82 H438 V290 H433 M438,92 H446"/>
<path class="l f" d="M422,114 H427 V258 H422 M427,142 H446"/>
<path class="l f" d="M411,172 H416 V200 H411 M416,192 H446"/>
<path class="l f" d="M411,223 H416 V267 H411 M416,250 H446"/>
<text x="451" y="89" class="b s">Possible</text>
<text x="451" y="101" class="x">Future knowledge</text>
<text x="451" y="112" class="x">“may happen”</text>
<text x="451" y="139" class="b s">Plausible</text>
<text x="451" y="151" class="x">Current knowledge</text>
<text x="451" y="162" class="x">“could happen”</text>
<text x="451" y="189" class="b s">Probable</text>
<text x="451" y="201" class="x">Current trends</text>
<text x="451" y="212" class="x">“likely to happen”</text>
<text x="451" y="247" class="b s">Preferable</text>
<text x="451" y="259" class="x">Desired future,</text>
<text x="451" y="270" class="x">value judgement</text>
<text class="ref" x="536" y="308" text-anchor="end">Futures cone · Source: Voros, J. (2003), A generic foresight process framework.</text>
</svg>
```

<!-- /canon/concepts/the-human-centred-newsroom.md -->

---
type: Concept
title: The human-centred newsroom
description: When baseline AI becomes a commodity, judgement, voice and relational trust become the core craft, so the newsroom reorganises around audience needs, measures trust instead of volume, and stops slotting voice-driven talent into shift work.
status: stable
sources:
  - id: root-naij-fojo-2026-schori
    resource: "Schori, M. (2026), Look beyond the AI tools, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
use_when: a plan competes on speed and volume, measures output, or recruits for shifts rather than for voice and relationships
---

# The human-centred newsroom

A young reporter with an original voice, a clear sense of what journalism should do and ideas about community relationships and audience value cannot get a job, because every hiring editor is impressed and has no place for her: the editor needs someone to cover the six o'clock breaking shift, and the holes in the schedule always win. Meanwhile every conference repeats that newsrooms must double down on what makes them uniquely human. Martin Schori's argument is that this paradox has reached a tipping point.

## Why the soft qualities become the core craft

- The technology question is largely settled: within a year or two virtually every newsroom in mature markets has the same baseline AI capabilities, and the gap between fast and slow adopters is closing.
- When capability is a commodity, AI-driven product innovation stops being a competitive moat. As AI absorbs the mechanics of standard production, speed and aggregation, editorial judgement, personal voice and relational trust stop being nice to have and become the craft itself.
- The next generation of news products will come from newsrooms that have reconstructed their organisation, culture and incentives around what AI cannot replicate.

## The newsroom in 2032

- The landscape draws a sharp line and newsrooms abandon the dangerous middle ground. On one side, the automated information layer: fast, hyper-personalised, algorithmically synthesised ambient news delivering commodity facts instantly. Publishers that competed manually on speed and volume within it did not succeed. On the other side, human-centred editorial media.
- No morning meeting organised around filling sections of a homepage, and probably no isolated desks. The newsroom could be organised around audience need clusters: Help Me Understand, Give Me Perspective, Connect Me to My Community.
- Automated systems monitor public records, transcribe council meetings, flag data anomalies and maintain routine tracking feeds; journalists touch that layer only when human verification or an ethical question is needed.
- The lead curator and perspective editor reviews overnight signals and asks: what is noise we can ignore so the audience need not be bothered, and where is human presence, moral clarity or live investigation irreplaceable today? The morning goes to an in-person investigation and a closed audio forum with community members affected by a policy shift; later, a voice-driven analysis of why it matters and who should be held accountable. The forums, meetups and Q&As where readers talk back and journalists answer are the product, not an engagement tactic bolted onto an article.
- What a reader pays for is not the decision, the budget figures or the summary, all available in the ambient layer in seconds, but someone who sat in the room, asked the follow-up question she would have asked, and comes back two weeks later to say what has happened since. The feeling that someone is paying attention on her behalf. The metrics are trust density and relational depth: retention, active participation, perceived value. AI handles the information supply; humans hold the relational trust people pay for.

## Three shifts to get there

1. Stop measuring old values. If incentives, KPIs and praise still flow to publishing speed and click volume, journalists will use AI to produce the same disposable content at double the velocity. Measure direct audience contribution, retention per interaction and perceived trust.
2. From gathering information to editorial triage. In synthetic overload the journalist's primary value is knowing what to ignore: slicing through noise, evaluating algorithmic output, exercising moral and factual judgement.
3. Cultivate voice and relational competence. Generative text is polished, balanced and bland; human value lies in distinct perspective, lived experience and intellectual honesty, plus facilitation, listening and community leadership that turn consumers into participants. AI will not take your job, but someone more fun to be around might.

## The talent mismatch

- Recruit the most original, voice-driven talent and slot it into a templated legacy role built for production output, and you lose it within a year or two, to newsletters, podcast networks or platforms where it can build something of its own. Every unconventional talent passed over because it does not fit a shift risks funding future competition.

## What to do now

- Set KPIs for trust and relationships, and make the editor-in-chief personally responsible for protecting them the day the six o'clock shift needs covering, because that day will come.
- Account for every hour AI hands back. Decide in advance how much goes to relationships, presence and investigation, and write it down; otherwise it is eaten by more briefs and more social posts.
- Remove one volume metric from the management dashboard and put a relational one in its place. Just one. Then watch the morning meeting change.
- Next time someone like the reporter from the café walks in, stop asking whether she can cover the morning shift and ask what she would build if you let her.

<!-- /canon/concepts/the-scoping-circle.md -->

---
type: Concept
title: The Scoping Circle
description: Six iterative questions, from focal question to research design, that get stakeholders to agree a project's scope and boundaries.
status: stable
use_when: "stakeholders need to agree a foresight project's focal question, context, decisions to influence, approach and research before the work starts"
depends_on:
  - /canon/concepts/scoping-a-foresight-project.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Scoping a Foresight Project, The Scoping Circle"
  - id: root-california-100-soif
    resource: "California 100 & School of International Futures (2023), Beyond Strategic Planning: A Foresight Toolkit for Decision Makers"
---

# The Scoping Circle

California 100 and School of International Futures have developed a powerful yet simple approach to scoping a foresight project which they call the Scoping Circle. It is a set of six steps that can be used to get a clear understanding of your question, purpose, context and approach.

## How it works

- You start with the question that you have the clearest answer to and work your way around the circle as many times as is useful.
- Using it iteratively helps you refine your thinking.
- You should always consider including different perspectives in the scoping exercise, such as the people/team who asked for the project, project beneficiaries, and other relevant individuals or groups. This helps to ensure that the project stakeholders agree on the scope and boundaries of the project.

## Figure: the Scoping Circle

A hand-drawn circular arrow at the centre, with six labelled steps arranged around it, three on the left and three on the right, indicating an iterative loop through the following questions.

- Define the focal question (top left): What question do you want the project to answer? What is the core issue of interest? Where will you draw the project boundaries? What is the challenge that needs a response?
- Understand the context (top right): What system does this project exist in? What is the project seeking to achieve? What needs to be considered to ensure impact?
- Engage stakeholders (middle left): Who is the project for? What needs will it satisfy? Which decision should the foresight work influence? Who might be upset or resistant to change? How are they included?
- Design the approach (middle right): What approach/tools best support the purpose and needs of the project? What could go wrong? What should be avoided? What does the foresight work help you do?
- Make the case (bottom left): How will evidence come together to make the case for change? What is important to see for different audiences/users? How can you make the most of the foresight work produced?
- Design the research (bottom right): What kind of future insights will work in this context? Where will you look for future insights and signals of change? Who will you talk to? Who will you collaborate with?

<!-- /canon/concepts/the-story-that-acts.md -->

---
type: Concept
title: The story that acts
description: A story that acts offers a service grounded in its own reporting while holding open room to think, refuse, be surprised and be done, so journalism serves intention without fitting people so closely that nothing new can get in.
status: stable
sources:
  - id: root-naij-fojo-2026-eeman
    resource: "Eeman, E. (2026), Journalism with room to move, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
use_when: a plan optimises for attention or for intention so completely that it closes the space for judgement, surprise and stopping
---

# The story that acts

Ma is a Japanese word for an interval: the pause, the space between things that gives them their shape, the rest between notes that turns sound into music, space held open on purpose. Ezra Eeman's question is whether AI could do that for journalism, giving back the space to think rather than crowding it out.

## From attention to intention

- Digital media organised itself around attention: measured, predicted, sold. Agents move the conversation towards intention: what is someone trying to achieve, what can we help them do. Answer engines give the answer, not the page; personal agents brief you in your preferred tone, length and topics.
- A system that serves intentions can still enclose. Especially when it starts anticipating them, deciding what you probably want before you have had the chance to think. Media that fits like a second skin: exciting, and slightly suffocating.
- Carried through, this gives a media environment that fits so closely there is little room left to move, every interest recognised, every hesitation interpreted, every gap filled. In machine learning that is overfitting: a model so tuned to its training data that it fails on new examples. Erik Hoel's hypothesis is that dreaming keeps the brain from overfitting by injecting noise. An overfitted media environment is one that knows you so well it can no longer surprise you.

## Making room for judgement

- Sometimes we have a poorly formed question, change our mind while answering it, or need something precisely because we had no idea it existed. You cannot ask for what you do not know you are missing. Journalism has always brought those things into view.
- This is not a plea to make information difficult. A person who needs a clear explanation should get one; a person struggling with language, time or access should not have to do extra work to qualify for journalism. There is plenty of friction worth removing. The question is where removing it helps someone and where it starts to take over the work of forming a judgement.
- A story might help compare two proposals without selecting the one it thinks you should prefer, explain what is known while leaving a disputed question visibly unresolved, or give a place to begin without arranging the rest of the journey. There is a difference between leaving someone lost and giving them room to find their own way.

## The story that acts

- A story that both has and gives agency. It tells you what happened and can also offer a service grounded in the reporting: help with a calculation, a comparison or a practical next step. Rather than a generic chat box under every article, it begins with what this piece of journalism has established and what someone might do with it.
- It should never make the reader less involved in deciding where to go. There must be room to refuse its suggestion, follow a different thread, or arrive at a conclusion the newsroom did not expect; otherwise it is a more capable product and a less capable relationship.
- Eeman's imagined example, a local newsroom in 2030 reporting on the redevelopment of an industrial site: alongside the article, an offer to explore the changes around a chosen street, compare the current plan with the previous version, or ask what evidence supports a traffic claim, with the answers showing where the newsroom's work runs out. While exploring the road to a school, the reader encounters reporting about residents who may be displaced, which the story makes visible because it matters to the public decision, not because it was asked for. The story can help prepare a consultation response, pointing out an unsupported assumption, without deciding the position. For weeks afterwards there is silence, because nothing has met the agreed threshold; when a revised proposal appears, an explanation of the difference arrives, and when the consultation closes, the offer closes too. Acting and leaving space belong together.
- Not every story needs to turn into a service. There should still be reporting read because it is beautiful, disturbing, funny or difficult to place. If attention is replaced by task completion as the universal measure, journalism's purpose has been made too small in another way.

## What this asks of newsrooms

- Tools that help reporters start with a question before producing an answer: surfacing conflicting evidence, a missing perspective, the chance to try an idea without turning it into an article.
- Describing the usefulness and limits of reporting more precisely: what has this story established, whom might it affect, what can we responsibly help someone understand, compare or do, what would change our assessment. These are editorial questions that cannot be passed to a model after publication.
- Working with designers and developers on how reporting could behave like a service, and knowing when a helpful suggestion becomes a nudge towards an outcome, and when journalism turns into activism.
- Responsibility continues after publication. A calculation goes out of date; a correction may affect an answer already received. Someone must maintain these capabilities and withdraw them when their basis no longer holds.

## A new sense of value

What people might value enough to support, beyond access to more content: being done, a product that respects their time enough to end; being able to act, with a newsroom accountable for the reporting and the tools; being surprised, by a trusted source that regularly makes their world larger; and being able to trust the silence, knowing a story is still being followed without being disturbed until something that matters has changed.

<!-- /canon/concepts/three-horizons-of-ai-mediated-transformation.md -->

---
type: Concept
title: The three horizons of AI-mediated transformation
description: AI optimises what exists in the first horizon, reorganises how work flows in the second and reshapes business models and ecosystems in the third, so organisations must work across all three at once.
status: stable
use_when: "an organisation's AI work is mostly efficiency gains and the person needs to see what reorganising workflows and reshaping business models would demand"
depends_on:
  - /canon/methods/three-horizons.md
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, section The three horizons of AI-mediated transformation"
  - id: root-sharpe-three-horizons
    resource: "Sharpe, B. et al., The Three Horizons framework"
  - id: root-choudary-reshuffle
    resource: "Choudary, S.P. (2025), Reshuffle: Who Wins when AI Restacks the Knowledge Economy"
---

# The three horizons of AI-mediated transformation

At first, many organisations approach AI as a means of improving what already exists, making tasks quicker, reducing friction and reinforcing current operations, looking for a quick return on investment and proof of concept of what AI can do. This is justified. Yet the deeper transformation is not only about augmentation at the level of the individual. It unfolds across workflows, organisational systems, and the wider competitive ecosystems in which organisations compete. This perspective echoes the reshuffling of the knowledge economy described by Sangeet Paul Choudary, which explores how AI does not simply automate tasks but reorganises how work, decision-making and value creation are structured across organisations and ecosystems.

## The three horizons

- In strategic foresight, the three horizons framing helps distinguish between the system that currently dominates (H1), the transitional developments that respond to its decline (H2), and the longer-term configuration beginning to appear at the edges of the present (H3).
- In the first horizon, AI helps optimise what already exists. In the second, it begins to reorganise how work flows. In the third, it reshapes business models, competitive boundaries, and the broader systems of value creation.
- Organisations need to work across all three horizons at the same time, else they risk being obsolete when the third horizon occurs.

## The strategic risk

- A company can become highly effective in Horizon 1 while underinvesting in Horizon 2 and remaining blind to Horizon 3. It may automate current processes brilliantly while missing the fact that the ecosystem around it is being redrawn.
- An auditor may become highly skilled at using advanced AI assistants in their analyses, but if the auditing firm fails to prepare for a world of agentic auditors, the firm may lose its competitive edge.
- AI transformation must be understood as more than marginal efficiency improvements at the level of the employee. It is a question of organisational design, strategic timing and long-term relevance.

## Figure: the three horizons of AI-mediated transformation

A three-horizons line chart plotted against time. H1 starts high and declines steadily. H2 starts low, rises to a peak in the middle, then declines. H3 starts lowest, rises steadily and ends highest. The model is inspired in part by the reshuffle model, which shows how AI restacks workflows, organisational boundaries and ecosystems, and by the Three Horizons framework, which distinguishes immediate optimisation from deeper organisational transition and from broader ecosystem shifts. The three phases are set out below.

| | Now (H1) | Transformation phase (H2) | Long-term (H3) |
|---|---|---|---|
| Aim | Improve what exists | Build transitional capabilities | Re-imagine |
| Basis | Based on data and control | Based on experimentation and adaptation | Challenge core assumptions |
| Core question | How can AI improve what we already do? | How should workflows be reorganised when capabilities change? | How does AI reshape the system our organisation exists within? |
| Typical dynamics | Automation of repetitive work, productivity gains, faster research, analysis and service, better support for existing functions | AI agents in workflows, human and AI collaboration, decision support, continuous intelligence environments, new operating models | AI native organisations, new value chains, competitive advantage as ability to orchestrate and govern data |

<!-- /canon/concepts/three-information-ecologies.md -->

---
type: Concept
title: Three information ecologies
description: Analogue, digital and AI-driven information ecologies differ in the unit of information, the intermediaries and what is scarce, and in the AI-driven one original trustworthy knowledge and user intention are the new scarcities.
status: stable
sources:
  - id: root-naij-fojo-2026-lindskow
    resource: "Lindskow, K. (2026), Towards sustainable publisher models for the AI-driven information ecology, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
use_when: a plan needs placing in the information value chain, or treats AI as another distribution shift rather than a reorganisation of how information is produced, maintained, discovered and used
depends_on:
  - /canon/concepts/the-agentic-information-economy.md
---

# Three information ecologies

The change AI brings to news publishing is usually perceived as destruction: declining direct traffic, misinformation, job losses, eroding trust. Kasper Lindskow's question, after Schumpeter, is what AI is creating. His answer is a reorganisation of how information is produced, maintained, discovered, interpreted and used, which will gradually displace the ecology of articles, websites and apps with an ecology of agents and flows. The central strategic challenge is then not how to produce news more efficiently but how to redefine the publisher's editorial and economic role when static articles cease to be the main unit of exchange and AI systems mediate between information and its users. The vision is an ambition, not a prediction.

## The three ecologies

- Analogue, before 2000: print, radio and television; industrialised production and distribution; people read, watch and listen; publishers, broadcasters and distributors are the intermediaries; content, distribution capacity and reach are the resources; the publisher is gatekeeper and distributor to mass audiences.
- Digital, 2000 to 2020: internet, search engines, social platforms and smartphones; networked access and algorithmic discovery; people search, browse, navigate and share; search engines, social platforms and app ecosystems are the intermediaries; attention, behavioural data, network effects and audience relationships are the resources; the publisher produces and curates news in a platform-mediated environment and competes for attention.
- AI-driven, from the 2020s: foundation models, AI assistants and agents; machine-mediated interpretation, synthesis, reasoning and action; people question, converse, collaborate and delegate; model providers, AI assistants and agent platforms are the intermediaries; trustworthy knowledge, proprietary data, cognitive capabilities and task completion are the resources; the publisher produces, verifies, maintains and supplies trusted journalistic knowledge to human audiences and AI-mediated systems.

## The shift in the unit of information

- The basic unit may shift from finished media products and static digital objects towards more fundamental units of knowledge that can be recombined to serve different purposes on demand. This separates the production of information from its uses: the same information can flow into numerous services, creating value adapted to the intentions and contexts of individual users.
- The AI-driven ecology now exists in parallel to the digital one and partly builds on it; in the coming years it grows relative to it and eventually becomes the primary mode for information to flow.

## The two-way value chain

Four steps, with knowledge flowing downstream and demand flowing upstream:

1. Origination and validation: new relevant information is produced as real-world events unfold, by machines through sensors and by humans empowered by AI, since some production still requires physical presence and access to sources and situations.
2. Knowledge infrastructure: the original information is organised in an infrastructure holding the accumulated information produced over time. In a news context this can be a database of the facts about the world in the publisher's news flow, relationships between entities and events tied to their source and validity, continuously maintained as facts change, highly automated with human supervision for factuality.
3. Orchestration: information from the infrastructure is orchestrated to address specific needs, by AI systems operating within the guidelines and guardrails of whoever controls them.
4. Relationship: the orchestrated information is presented in AI services that provide answers, understanding, advice, decisions, completed tasks or actions. Upstream, signals about users' information needs inform the orchestration and provide data on what knowledge is in demand.

## The economics

- AI expands information markets by reducing the cost of producing and transforming information and increasing the purposes it can serve.
- AI creates new scarcities. Information that anyone can produce with AI becomes abundant and commoditised; two things stay scarce: original, trustworthy knowledge that AI systems cannot independently produce, and access to the intentions and context of users.
- AI shifts bargaining power towards the organisations that control those scarcities, which are likely to capture a large portion of the value created.
- It is not given that publishers will appropriate more value than today. Creative destruction can create temporary or permanent imbalances between those who create value and those who capture it; monopolies of the leaders of a transformation can become permanent through scale economies, network effects and switching costs, which may call for intervention in the market.

<!-- /canon/concepts/three-publisher-positions.md -->

---
type: Concept
title: Three publisher positions
description: A publisher can originate scarce information for agents, maintain a knowledge base for businesses, or own the AI-powered news experience for consumers, and a large one may combine all three on one journalistic knowledge infrastructure.
status: stable
sources:
  - id: root-naij-fojo-2026-lindskow
    resource: "Lindskow, K. (2026), Towards sustainable publisher models for the AI-driven information ecology, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
use_when: a publisher is deciding where it creates and captures value as AI systems mediate between its journalism and the people and organisations that use it
depends_on:
  - /canon/concepts/three-information-ecologies.md
---

# Three publisher positions

The transition to the AI-driven information ecology erodes the publisher's historical control of news production and versioning and moves the locus of use from articles read on websites to multiple uses in AI services. Kasper Lindskow's three positions are the ways a publisher can convert its existing capabilities into control of the new scarcities in the value chain: original trustworthy knowledge, and knowledge of users' intentions and contexts. The journalistic point of departure, trustworthiness to individuals, companies and communities, is the strength shared by all three.

## Originator of scarce information, for agents

- The publisher continues to provide journalism as events unfold, focusing on the news that does not already exist in the ecology and requires human journalistic action and supervision: physical or emotional access to sources and situations, increasingly AI-assisted.
- Value proposition: unique news needed to know the world as it evolves. Strength: unique and trustworthy information.
- Challenge: can scarcity be controlled against other AI-powered originators and the commodification of news content? It calls for defending scarcity through control over access, rights enforcement and uniqueness of reporting, and possibly alliances or consolidation at this step of the chain.

## Knowledge provider, for businesses and institutions

- The publisher departs from producing and publishing news to providing access to its accumulated journalistic knowledge, so that companies and institutions can get the answers they need to do their work. This requires a knowledge base on top of news production, structured to be maintainable, verifiable and retrievable; customers are those who need factual knowledge about the domains the publisher continuously covers.
- Value proposition: all information relevant to a professional intention and context. Strength: accumulated proprietary knowledge.
- Challenge: competition from specialised information services, met by protecting the exclusivity of significant parts of the knowledge base through uniqueness, continuity and trustworthiness, and possibly by extending collection beyond reporting to complementary information.

## News experience provider, for consumers

- The publisher keeps its direct relationship with the broad audience and provides an intelligent interface through which users experience and explore news and apply journalistic knowledge to their interests and needs, making the content more personally valuable through interaction, contextualisation and assistance.
- Value proposition: discover and explore news aligned with your intention and context, as an individual or a member of a community. Strength: the existing relationship with users, still strong, especially in the Nordic countries.
- Challenge: competition from general AI services, met by a differentiated experience focused on news: editorial judgement, exclusive trustworthy knowledge, specialised AI-mediated experiences that prioritise what is editorially important, and a shared experience that shows what the community cares about and enables deliberation.

## The vertically integrated knowledge publisher

- The positions are distinct but not mutually exclusive. Larger publishers could combine all three, addressing agents, businesses and consumers from the same journalistic production and knowledge infrastructure: the ABC model.
- Journalistic knowledge production, reporting, investigation, verification, interpretation and editorial judgement, all highly assisted by AI, feeds a shared journalistic knowledge infrastructure of structured knowledge, evidence, source data, versioning, semantic search and governance. From there it flows to three markets: licensed to external AI services for grounding and verification; served as domain-specific knowledge to companies; experienced in publisher-owned AI products.
- The synergies from economies of scope might be essential for recovering the still high costs of original reporting, enabling investments that distributing to one channel could not sustain. Entering three markets means managing channel conflicts by differentiating the products, resources and rights offered through each.

## Key things to consider

- The model does not change the core mission; it resituates it. When information is continuously updated and reused, publishers must develop methods that ensure accuracy and provenance both at publication and over time.
- When knowledge is transformed to address individual intentions, AI-powered experiences must balance what the user wants and what is journalistically important.
- As AI at scale becomes part of news origination itself, new ways are needed to ensure editorial judgement and emotional connection when humans steer at higher levels of abstraction. These inventions could be essential sources of differentiation.

<!-- /canon/concepts/trends.md -->

---
type: Concept
title: Trends
description: Observable or measurable directional shifts that interlock, blend and can reverse, with no guarantee of continuing.
status: stable
use_when: "someone asks what a trend is, how firmly it is grounded, or whether an observed shift will simply carry on"
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Vocabulary of the Future"
---

# Trends

Observable and/or measurable directional shifts in a situation or in the way people behave. They can vary in strength, direction (increasing, decreasing or stable) and impact.

## How a trend is represented

- Numerically, through indicators that can be measured and supported by data.
- Non-numerically, as a perceived development that may only partially be supported by data, often understood through examples or observations.
- In practice, most trends carry elements of both.

## How trends behave

- Trends shaping the future are interconnected and interdependent, with different time horizons, reach and levels of impact.
- They often blend into each other, making them difficult to separate.
- There is no guarantee that a trend observed in the past will continue unchanged in the future.
- Countertrends often emerge in response or opposition to the dominant one.

<!-- /canon/concepts/truth-as-gold.md -->

---
type: Concept
title: True truth as gold
description: When information floods and becomes personal, verified truth grows in value, so journalism's task is to build the self-correcting mechanisms of the new information era and make people want them.
status: stable
use_when: "the person is deciding how a news medium can make verified truth valuable, and worth paying for, as AI-made content floods and personalises information"
depends_on:
  - /canon/concepts/existential-innovation.md
sources:
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, section 4. princip: Ægte sandhed som guld. Byg selvkorrigerende mekanismer"
  - id: root-harari-2024
    resource: "Harari, Y. N. (2024) Nexus"
  - id: root-marconi-2026
    resource: "Marconi, F. (2026) Who Will Monetize Truth? A Thesis for the Future of the Information Business"
---

# True truth as gold

When information flows and becomes personal, the need for real facts and the best attainable truth rises. That holds just as much when the world develops fast and unpredictably. If war or crisis comes, people want correct journalism about what is happening to their money or where the drones are flying. So the situation is that wrong information has probably never been greater or more used, and can explode with AI, while quality information becomes more and more valuable.

How do news media benefit from that, and how do they ensure that people get that type of information, and want to get it, even to the point of willingness to pay?

## Self-correcting mechanisms

At the largest information revolution so far, the printing press, the new mass-produced books did not at first simply create more knowledge; to a high degree they created more misinformation. Some of history's first bestsellers were books about witches that went viral and set the witch hunts in motion. Only when self-correcting mechanisms were established and gained ground did the new information technology, the book and later the newspaper, become to a higher degree a carrier of knowledge and form a decisive foundation for the development of the modern enlightened society. Self-correcting mechanisms were developed within science, journalism, the courts and other institutions, where through self-correction one systematically tries to find the best attainable version of the truth. In recent centuries these mechanisms have been decisive for supporting the quality of knowledge and information, and thus for maintaining society's conversation with itself and a reasonably healthy democracy.

Now we face a new information revolution, with an explosion in AI-created content in a wholly new, liquid form, gathered at a few tech giants, while the number of journalists has fallen. Our institutions are not necessarily built to handle that development. It creates an asymmetry: the need for truth rises, but who builds what can monetise truth and at the same time benefit society? The tech giants are at work, but what can news media do? For a hundred years journalism built an infrastructure for truth, but no one has worked out how to do it now, at high speed. And can we risk leaving the infrastructure for truth and knowledge to American AI companies?

All of this argues that journalists and news media should build the new self-correcting mechanisms of the era. It is an enormous task, and several specific challenges are decisive to handle.

### Noise as a new censorship

AI slop already floods the internet, with outright slop shops in growth. The problem concerns both quality and quantity.

- Quality: this is ultra-processed content, dopamine-dense, with at best negligible informational value and at worst corrosively negative. Where fast news was once criticised as fast food, with easy calories that quickly disappeared, this is a wholly different scale: ultra-processed, AI-boosted snacks that can be even harder to say no to and even lower in quality.
- Quantity: more information does not give more wisdom; on the contrary it risks drowning true information in cheap, false information. Here noise functions as a new kind of censorship. Human-made content can also grow markedly in volume with the assistance of AI tools. We are moving from scarcity to abundance: production of content is no longer a moat.

This opens potential for the media, both on quality and on helping to navigate the flood of content. Curation, for example, can become even more valuable. Could news media earn money on a new type of high-quality aggregation? AI can also be part of the solution, for example by creating a more diverse news diet if used right.

### What if people are indifferent?

Several studies have suggested that some news users are perfectly satisfied with the AI products even though they make frequent errors, as long as they are convenient to use. That possibly constitutes an existential challenge, because the whole structure of news media is set up to deliver precise information. Will people pay at all for the information being of slightly higher quality? Are free and convenience actually more important?

If it is to succeed, it probably requires pronounced innovation of forms and formats that give users the desire for more truthful information, and show very clearly why it is important. Here lies a great task for news media, which again concerns clarity about who they are, but also for politicians and others who support a viable press. Many very different disciplines and forces are needed if self-correcting mechanisms are to be developed that people will actually use or pay for: not just tech experts, politicians, financiers and communicators, but everyone from philosophers and anthropologists to artists and psychologists.

This does not mean that news media should throw away everything that works now. The need for change can at times be exaggerated: some of the successful formats of the moment resemble echoes of old television or radio programmes. In the hunt for shiny new AI tools one can also risk forgetting one's soul.

### Attention splinters

The shared front page is already more myth than reality for many, but it will disappear even more in the liquid and personal era. The media reality is already being atomised, and such a fragmented information landscape makes the shared public conversation harder. Where engagement has been a carrying metric for social media, intimacy may become it for AI.

That can lead to information oracles that understand exactly you extremely well, but which you do not really understand: where does the information actually come from? It is hard to fact-check or trust something we do not understand. At the same time such oracles risk isolating each person, removing the friction that is necessary to understand others' viewpoints, since it is precisely through shared language and meetings that meaning and ethics arise. It is the ultimate possible tool of manipulation. Social media that create unreal narratives help destabilise democracy itself, creating mistrust and eroding the perception of a shared reality, and generative AI fits perfectly into that dynamic.

These challenges also constitute a potential for news media. Can they create the shared front pages of the future, or communities where people gather around stories and news? Bundling of content has already proved relatively successful in several places, including shared subscriptions across media. Could that develop into a home for shared stories? One can also imagine journalistically oriented organisations developing a healthier type of information oracle, giving relevance and intimacy but set up to challenge and bring opposing viewpoints. Newer studies show how people who use AI heavily risk losing learning, because learning requires a certain friction. Can media build products that do not just give easy answers and weaken human development, but do the opposite: built to make us better in the broadest sense of the word?

## Usefulness or public good?

Much suggests that clear usefulness is essential when it comes to monetising truth in these years. Profit margins are markedly larger on selling intelligence and solutions that companies and people can use very directly than on classic journalism.

Figure: a scatter plot titled "The great information repricing", subtitled "Value is migrating from the content layer to the intelligence layer". The vertical axis shows revenue per employee; the horizontal axis shows the share of revenue from intelligence and data products, from zero to one hundred per cent. Classic news media sit bottom left, and data and intelligence companies rise up and to the right along a dashed diagonal marked "The repricing curve". A text box on the left describes content economics: near-zero margin, with a news subscription as peak product. A text box on the right describes intelligence economics: margins above thirty-five per cent, with an institutional terminal as peak product. At the foot: a pricing ratio of 275 to 1 for the exact same raw material.

Put simply, there is money in the solution economy. But what about ordinary journalism, which one cannot necessarily use very directly in one's life? Should that, perhaps, rather be understood as a public good? The development poses new challenges to financing, and perhaps to the need for support, and possibly calls for news media to focus parts of their offering into a solution economy. Otherwise it will, as now, largely not be media but domain experts and others who build that type of information business.

Truth can be gold, also financially, for media-like companies. They can draw on strong norms and processes for producing the best attainable version of the truth. But in the changed digital infrastructure that type of content risks drowning or being hard to assess for quality, some users are becoming indifferent, and everything may become so personalised that we lose a reasonably shared perception of the state of things. That requires existential innovation. But it also holds important opportunities for journalism, if it can develop solutions to those truth problems, also for very specific target groups.

Developing the self-correcting mechanisms of the new era is an existentially important task, not only for journalists but for all of us, which is why it requires deeper community and broader collaboration.

<!-- /canon/concepts/uncertainty.md -->

---
type: Concept
title: Uncertainty
description: Differs from risk in that probabilities are unknown, compounds with distance into the future, and becomes critical where impact is high.
status: stable
use_when: "the person needs to tell risk from uncertainty, or find which high-impact, unresolved forces a plan must be prepared for"
depends_on:
  - /canon/concepts/drivers-of-change.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Vocabulary of the Future"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 24 and 64"
---

# Uncertainty / uncertainties

Uncertainty is a feature of complex systems and is fundamentally inherent when working with the future. Recognising it highlights the potential for novelty, emergence and discontinuity. It can arise from having limited knowledge about the future, or from future developments being genuinely undetermined, with multiple ways they could plausibly play out.

## Uncertainty compounds over time

- Many future outcomes are contingent on other developments that have not yet played out, and those, in turn, on others still.
- Uncertainty accumulates the further into the future we look, which is part of why the long term cannot simply be extrapolated from the present.

## Uncertainty is different from risk

- Risk refers to situations where the probabilities of different outcomes are known, or can be estimated with some degree of confidence.
- Uncertainty involves situations where those probabilities are unknown, unknowable or cannot be reliably estimated, reflecting a lack of information or predictability about future events or developments, and implying a higher level of ambiguity and complexity.

## Critical uncertainties

- Uncertainty is at the heart of all foresight work, and a fundamental aspect of strategic foresight involves identifying and engaging with critical uncertainties.
- These are defined as high-impact drivers with uncertain outcomes.

## Uncertainty is a feature

- Working strategically with the future is less about identifying trends and development trajectories and much more about grasping and understanding uncertainty. Acknowledging uncertainty is a fundamental premise for making strategic decisions.
- Uncertainty is the very reason we need strategy: without it, a plan to go from A to B would suffice. Uncertainty is not a bug but a feature, and sometimes the future seems to punish certainty. The future turns many 'givens' into uncertainties, and our brains are not really wired for it.

<!-- /canon/concepts/weak-signals.md -->

---
type: Concept
title: Weak signals
description: Faint early indicators from the fringes that may grow into drivers or fade entirely, pockets of the future already in the present.
status: stable
use_when: "someone has spotted a faint early development at the fringes and needs to judge whether it could grow into a trend or fade away"
depends_on:
  - /canon/concepts/trends.md
  - /canon/concepts/drivers-of-change.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Vocabulary of the Future"
---

# Weak signals

Subtle and often early indicators of emerging trends or disruptions that are not yet widely recognised or understood.

- Weak signals have the potential to significantly impact the future, but may also completely fade away before manifesting into a trend or a driving force.
- These signals typically originate from the fringes of society, technology, economy, culture, or from other parts of the world, and may initially appear insignificant or disconnected from mainstream developments.
- In this sense, weak signals can be thought of as 'pockets of the future' already embedded in the present.

<!-- /canon/concepts/what-tools-to-use-when.md -->

---
type: Concept
title: What tools to use when?
description: Choose and combine tools by objective, intended users and the edge of their comfort zone, since work that is too extreme or too tame both breed distrust.
status: stable
use_when: "the person must choose or combine foresight tools for a given purpose and audience, pitched to challenge without seeming implausible"
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section What Tools to Use When?"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 29 and 58"
---

# What tools to use when?

Given the extensive number of tools available, how does one pick the right ones? The same tool can serve different purposes, and different tools can help achieve similar ends, so knowing how to choose and combine them is much a matter of practice and situational awareness. There is no single right or wrong answer, but here are some criteria that may help with selection.

## Objective

- Be absolutely clear and intentional about what you want your futures work to deliver. Every futures project is different, and should be based on its own specific context, premises and objectives.
- Some tools are useful for opening minds to novelty and different perspectives, while others are more about creating a shared sense of the future or understanding what drives change in the present.
- Some provide insights relatively quickly and with little effort, while others are more demanding and require substantial effort.
- Some work very well in explorative workshop settings, while others are more geared towards developing or testing strategy in a decision-making context.

## Mix and match

- Combining and adapting foresight tools and methods is often necessary as part of a foresight process, as no single tool does everything.
- Different questions call for different tools, and some of these tools work better in unison than others.
- Some tools may yield an output that naturally flows as input into the next phase of the process.

## Intended users

- Know the recipients of your work as well as the people involved in the process.
- Some are more open to divergent futures thinking, while others can be more constrained in their thinking and views at the initial stage.
- Knowing both your 'intended users' and the people involved in the process or project allows you to, for example, start with 'lighter' tools that are easier to grasp, and then progress onto more challenging ones.

## Striking the balance

- This is connected to the point of knowing your intended users. At a high level, part of your role as a foresight practitioner is finding the edge of your users' comfort zone and helping push them just past that. This implies that what is considered provocative for one group may not be for another, and vice versa.
- Experience suggests that when people engage with foresight work they consider too extreme or implausible, they tend to become even more confident in their original view of the future. This can contribute to their distrust in foresight, as they might think it is too speculative to be useful.
- Conversely, if the foresight work is not challenging enough, it is easily dismissed as pointless, which again can contribute to distrust in foresight.
- For foresight work to be used efficiently, your users must be convinced of the soundness, relevance and value of the process, whatever its objective. Only then is there a chance it will influence decisions and actions.

## A fool with a tool

- A fool with a tool is still a fool. Doing foresight well sits in the sweet spot where tools, frameworks, evidence-based insights, data, knowledge and trajectories overlap with futures thinking, divergent thinking, creativity, imagination and speculation. Explorative foresight that challenges the business-as-usual future and anticipates novelty needs both.
- Foresight tools and techniques are used to guide and advance collective thinking about how the future might show up in the form of new assumptions, behaviours and realities, not to arrive at answers or outcomes that can be underlined as 'correct'. It is not about getting it right, but about doing it right.

<!-- /canon/concepts/wild-cards.md -->

---
type: Concept
title: Wild cards
description: Low-probability, high-impact events that cannot be planned for but can be anticipated well enough to adapt to surprise.
status: stable
use_when: "the conversation turns to low-probability, high-impact surprises that a plan cannot forecast but should be able to absorb"
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Vocabulary of the Future"
---

# Wild cards

Events or developments with low (perceived) probability but high impact when they occur.

- Wild cards have the potential to significantly alter the future landscape in unpredictable ways, by disrupting existing realities and developments, making them critical considerations for strategic foresight.
- Although wild cards cannot fully be anticipated or planned for, wild card analysis helps organisations better adapt to disruptive surprises by considering possible wild cards and assessing their potential implications.
- The term was co-introduced by CIFS in 1992.

<!-- /canon/concepts/worldview.md -->

---
type: Concept
title: Worldview
description: The unexamined assumptions that frame how people see the world and the future, and what that frame leaves out.
status: stable
use_when: "a view of the future seems bound by an unexamined frame from the present, or one official future is crowding out others"
depends_on:
  - /canon/concepts/assumptions.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Vocabulary of the Future"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 16 to 37"
---

# Worldview

How people see the world, with an emphasis on the unconscious assumptions and biases they do not call into question.

- Worldviews are shaped by the culture, experiences, norms and mindsets we carry with us, and influence our habitual ways of thinking and perceiving our situations and reality.
- Becoming aware of our own worldview, and holding space for those of others, who may make sense of the world, and of the future, quite differently from ourselves, is an important part of foresight.
- It helps people become mindful of the 'frame' they are using, including what is left out of that frame.

## The official future

- Views of the future very often tell more about the era, or zeitgeist, in which they were formulated than about the future. Attempts to foresee the future tend to be good on technological aspects while remaining stuck in their own time on behaviour, perceptions and social attitudes.
- Dominant images of the future risk becoming the 'official future', and can discredit and delegitimise other futures.
- A critical futures thinker is attentive to assumptions about the future that are rooted in the present and path-dependent, because they are sometimes incorrect or misguided: frozen in time as the world has shifted around them.

## Diversifying the future

- Diversifying the future means questioning the futures methods we use, since many traditional futures studies methodologies and frameworks are rooted in western-centric views; being comfortable challenging our own worldviews, since they set the boundaries of what we believe is possible; and ultimately widening the lens of what the future might hold.

<!-- /canon/methods/backcasting.md -->

---
type: Method
title: Backcasting
description: Runs a timeline in reverse from a future to the present to find the steps that connect them and which lie within the organisation's control.
status: stable
use_when: "the person has a scenario, vision or target future and needs to work out the steps back to today, and which of them lie within the organisation's control"
depends_on:
  - /canon/methods/scenario-development.md
  - /canon/methods/visioning.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Backcasting"
  - id: root-california-100-soif
    resource: "California 100 & School of International Futures (2023), Beyond Strategic Planning: A Foresight Toolkit for Decision Makers"
---

# Backcasting

Backcasting is an effective method for linking the future back to the present, helping to assess the conditions, changes and events that logically connect a given future to the present. Unlike traditional planning, backcasting starts in the future and works backwards. If you have already identified alternative futures, or a preferred future, for instance through a scenario development process, backcasting can be used to pinpoint the factors and events that will make these scenarios come true, as well as which strategies will influence them.

## How it works

- Backcasting involves creating a timeline in reverse, starting from a future scenario and working backwards to identify the key steps, events and actions that will make it happen.
- This helps connect future change to the present, overcoming the 'present bias' that often limits our planning.
- One particular focus of backcasting is to identify what lies within the control of the organisation, and can therefore be managed, and what lies outside its control and therefore needs to be monitored.
- Alternatively, backcasting can be used to determine what series of events could lead to a given undesirable scenario, and what steps could be taken to avoid such a scenario or mitigate its consequences.

## Use backcasting to

- Connect a given future to the present, identify what needs to be done to deliver it, and test the feasibility of the actions and approaches needed to get there.
- Identify which future factors and events lie within the organisation's control and which lie outside its control.
- Establish pathways of change to help identify new initiatives and interventions to enhance desirable changes or mitigate undesirable events.

## Key things to consider

- You can backcast from a scenario, vision or any other description of future change. A good way to set up your backcast is to outline four or five key features of the future scenario, vision or change. You can either work on one feature at a time, or you can work across these as you step back towards the present. This helps identify patterns and determine whether any specific factors or events are particularly critical.
- Different 'entries' on your backcasting timeline can help you explore various types of factors or events. Try to look for both external factors and events from outside your control and concrete actions you have taken that will have either direct or indirect implications. Consider including relevant (fictional) future data points or even adding descriptive 'news headlines from the future' along your backcasting timeline.
- After completing your backcast, take time to review your thinking by playing your backcast forward. Check that it makes sense and that it is feasible and coherent. Questioning the cause and effect of each step can help identify missing factors that are critical.
- Try to explore the actual consequences of your backcasting outcome. What events and changes can you or your organisation influence and what do you need to do to deliver these aspects? Also consider if and how you can influence aspects outside your control. Who or what has control, and what can you do to influence that?

## Figure: backcasting

Two stacked elements on a horizontal axis running from present on the left to future on the right. The upper element is a circle at the far right labelled scenario, vision or change, with a series of backward-curving arrows hopping leftward from it towards the present, illustrating the reverse direction of travel. The lower element is a timeline grid bounded by vertical lines at the present and the future, divided into three horizontal bands labelled key feature 1, 2 and 3. Within each band, dots are placed along branching horizontal lines at different points in time, representing the factors, events and actions identified as you step back from the future towards the present.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="ffbck" viewBox="0 0 560 362" style="display:block;width:100%;max-width:480px" role="img" aria-label="Backcasting: arrows step back from a future vision to the present, above a timeline of three key features">
<style>
.ffbck text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.ffbck .s{font-size:10.5px}
.ffbck .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.ffbck .m{stroke-opacity:.5}
.ffbck .f{stroke-opacity:.2}
.ffbck .k{fill:#413C38}
.ffbck .o{fill:#FFC7A5;stroke:#413C38;stroke-opacity:.5;stroke-width:.75}
.ffbck text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="362" rx="14" fill="#fff"/>
<text x="525" y="34" text-anchor="end">Scenario, vision or change</text>
<circle class="o" cx="470" cy="72" r="11"/>
<path class="l m" d="M457,72 Q416,30 375,72"/>
<path class="l m" d="M376.3,67.2 L375,72 L379.8,70.5"/>
<path class="l m" d="M375,72 Q327.5,30 280,72"/>
<path class="l m" d="M281.7,67.3 L280,72 L284.9,70.9"/>
<path class="l m" d="M280,72 Q232.5,30 185,72"/>
<path class="l m" d="M186.7,67.3 L185,72 L189.9,70.9"/>
<path class="l m" d="M185,72 Q137.5,30 90,72"/>
<path class="l m" d="M91.7,67.3 L90,72 L94.9,70.9"/>
<path class="l m" d="M90,100 V296 M470,100 V296"/>
<path class="l f" d="M90,165 H470 M90,230 H470"/>
<text x="100" y="118" class="s">Key feature 1</text>
<path class="l m" d="M130,142 H456 M330,142 L306,124 H200"/>
<circle class="k" cx="440" cy="142" r="3"/>
<circle class="k" cx="372" cy="142" r="3"/>
<circle class="k" cx="300" cy="142" r="3"/>
<circle class="k" cx="150" cy="142" r="3"/>
<circle class="k" cx="290" cy="124" r="3"/>
<circle class="k" cx="215" cy="124" r="3"/>
<text x="100" y="183" class="s">Key feature 2</text>
<path class="l m" d="M160,207 H456 M270,207 L246,189 H190"/>
<circle class="k" cx="425" cy="207" r="3"/>
<circle class="k" cx="340" cy="207" r="3"/>
<circle class="k" cx="215" cy="207" r="3"/>
<circle class="k" cx="232" cy="189" r="3"/>
<text x="100" y="248" class="s">Key feature 3</text>
<path class="l m" d="M120,272 H456 M380,272 L356,254 H230"/>
<circle class="k" cx="450" cy="272" r="3"/>
<circle class="k" cx="395" cy="272" r="3"/>
<circle class="k" cx="310" cy="272" r="3"/>
<circle class="k" cx="240" cy="272" r="3"/>
<circle class="k" cx="140" cy="272" r="3"/>
<circle class="k" cx="340" cy="254" r="3"/>
<circle class="k" cx="262" cy="254" r="3"/>
<text x="90" y="316" text-anchor="middle">Present</text>
<text x="470" y="316" text-anchor="middle">Future</text>
<text class="ref" x="536" y="334" text-anchor="end">Backcasting · Source: California 100 &amp; School of International Futures (2023), Beyond Strategic Planning: A</text>
<text class="ref" x="536" y="346" text-anchor="end">Foresight Toolkit for Decision Makers.</text>
</svg>
```

<!-- /canon/methods/causal-layered-analysis.md -->

---
type: Method
title: Causal layered analysis
description: Works down from observable issues through structures and systems to mental models and worldviews, then back up to build new narratives.
status: stable
use_when: "an issue is being read only at the surface and the person needs to uncover the systemic causes, assumptions and worldviews beneath it, or build a new narrative from them"
depends_on:
  - /canon/concepts/worldview.md
  - /canon/concepts/assumptions.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Causal Layered Analysis"
  - id: root-inayatullah-cla
    resource: "Inayatullah, S. (2019), Causal Layered Analysis: A Four-Level Approach to Alternative Futures"
---

# Causal layered analysis

Causal Layered Analysis (CLA), developed by Sohail Inayatullah, is a comprehensive foresight method designed to uncover and analyse the deeper dimensions of complex issues. This tiered approach works down from immediate surface-level trends through deeper layers of systemic causes, cultural values and worldview dimensions that influence change.

The main utility of CLA lies in supporting individuals and organisations in revealing the internalised assumptions they use to make sense of and assign meaning to specific changes. Ultimately, it can help create narratives that facilitate change. It also addresses the risk of foresight work being too superficial and overly focused on surface trends by providing a more profound understanding of the underlying factors influencing change.

## The three layers

The original CLA framework consists of four levels, but CIFS often uses a simplified version with three layers.

- Observable issues: the immediate, observable trends and day-to-day realities.
- Structures and systems: the structures, systemic factors and historical (social, economic, cultural) facts that support the observed realities.
- Mental models and worldviews: the deepest layer of mindsets, values and cultural and ideological aspects that shape our worldviews and perceptions, and influence how issues are framed and understood.

## Use Causal Layered Analysis to

- Get a deeper understanding of a particular issue or challenge by uncovering the systemic causes beneath it.
- Generate new narratives that challenge current realities.
- Map competing views of the future by recognising the different worldviews and perspectives of various stakeholders, ultimately supporting more transformative strategies.

## Key things to consider

- When working with Causal Layered Analysis, be aware that it is a relatively complex method that requires confidence in divergent thinking and exploring beyond the obvious and observable. It is also difficult to do well without a diversity of perspectives present.
- The Causal Layered Analysis exercise essentially has two phases. First, exploring the focal issue from the top down, starting with immediate trends and moving down through the deeper layers. Second, working your way back up from the deepest worldview layer to create new, alternative narratives that challenge current realities. Hence, the ultimate goal of CLA is not just to analyse, but to create new narratives that facilitate change.
- Causal Layered Analysis is a versatile tool that can be staged in various ways. These include mapping the present to prevent worldview blindness, enhancing a visioning process by outlining how things can be moved towards a desired future, and unpacking an issue across different stakeholder views or worldviews.

## Figure: Causal Layered Analysis

An iceberg cross-section, with a wavy waterline crossing it near the top. The top is labelled visible and tangible, the bottom hidden and intangible. Three numbered layers run down the iceberg, each with a prompting question and examples of content. Layer 1, observable issues, above the waterline, asks what is happening and contains things, trends and headlines. Layer 2, structures and systems, below the waterline, asks who and what are causing and influencing this and contains patterns, actors and PESTEL factors. Layer 3, mental models and worldviews, the deepest, asks what the underlying beliefs and assumptions are and contains symbolism, sayings and proverbs, myths and metaphors, values and culture.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="ffcla" viewBox="0 0 560 362" style="display:block;width:100%;max-width:480px" role="img" aria-label="Causal layered analysis as an iceberg: observable issues above the waterline, structures and systems below, mental models and worldviews deepest">
<style>
.ffcla text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.ffcla .b{font-weight:500;fill-opacity:.95}
.ffcla .s{font-size:10.5px}
.ffcla .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.ffcla .m{stroke-opacity:.5}
.ffcla .w{fill:#FFC7A5;fill-opacity:.45}
.ffcla text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="362" rx="14" fill="#fff"/>
<path class="w" d="M121,205 L312,205 L296,262 L250,296 L190,300 L140,280 L118,225 Z"/>
<path class="l" d="M215,38 L243,66 L258,92 L300,150 L312,205 L296,262 L250,296 L190,300 L140,280 L118,225 L128,160 L170,92 L190,62 Z"/>
<path class="l m" d="M121,205 H312"/>
<path class="l m" d="M30,92 q10,-5 20,0 t20,0 t20,0 t20,0 t20,0 t20,0 t20,0 t20,0 t20,0 t20,0 t20,0 t20,0 t20,0 t20,0 t20,0"/>
<text x="215" y="76" class="b" text-anchor="middle">1</text>
<text x="215" y="154" class="b" text-anchor="middle">2</text>
<text x="215" y="256" class="b" text-anchor="middle">3</text>
<text x="30" y="52" class="s">Visible and</text>
<text x="30" y="65" class="s">tangible</text>
<text x="30" y="272" class="s">Hidden and</text>
<text x="30" y="285" class="s">intangible</text>
<text x="345" y="68" class="b">Observable issues</text>
<text x="345" y="83" class="s">What is happening?</text>
<text x="345" y="146" class="b">Structures and systems</text>
<text x="345" y="161" class="s">Who and what is causing this?</text>
<text x="345" y="248" class="b">Mental models and worldviews</text>
<text x="345" y="263" class="s">Which beliefs and assumptions?</text>
<text class="ref" x="536" y="334" text-anchor="end">Causal layered analysis · Source: Inayatullah, S. (2019), Causal Layered Analysis: A Four-Level Approach to</text>
<text class="ref" x="536" y="346" text-anchor="end">Alternative Futures. Modified by CIFS.</text>
</svg>
```

<!-- /canon/methods/cross-impact-analysis.md -->

---
type: Method
title: Cross-impact analysis
description: Scores how drivers act on one another in a matrix so the drivers that shape the whole system stand out.
status: stable
use_when: "the person has a list of drivers and needs to see how they act on one another, which shape the whole system, or whether a scenario's logic holds together"
depends_on:
  - /canon/methods/driver-mapping.md
  - /canon/concepts/drivers-of-change.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Cross-Impact Analysis"
  - id: root-gordon-cross-impact
    resource: "Gordon, T.J. (2009), Cross-Impact Analysis, Futures Research Methodology V3.0, The Millennium Project"
---

# Cross-impact analysis

Cross-impact analysis is used to explore the interactions between different drivers or events and assess their systemic impact on one another. By mapping the interdependencies, this method helps to understand how elements influence each other, rather than just examining them in isolation. This highlights the importance of considering how various drivers or events can affect each other, providing a more comprehensive understanding of potential futures.

## How it works

- The process involves identifying key drivers (often from a driver mapping exercise) and evaluating their interactions using a cross-impact matrix, where you assign qualitative or quantitative scores to gauge the strength and nature of these interactions.
- Once the drivers are plotted in the matrix with their impact scores on each other, the cumulative scores reveal which drivers exert influence across many others. These are the drivers with the most significant potential to shape the system as a whole.
- This process helps to prioritise drivers that have the most significant potential to shape future outcomes and develop scenarios that reflect various possible futures.

## Use cross-impact analysis to

- Identify the most significant drivers of a system (the ones that seem to have the most impact across the grid).
- Explore interdependencies and strengthen the understanding that the future is shaped by interacting factors.
- Paint a fuller and more consistent picture of potential futures, as valuable input into a scenario analysis.

## Key things to consider

- Cross-impact analysis is often used in combination with other foresight tools. It can be especially useful when crafting future scenarios to make sure that scenario structure and reasoning do not have built-in inconsistencies that will undermine the credibility of the scenario.
- The first step of defining drivers or events to be included in the analysis is crucial to the success of the exercise. Any influences not included will, of course, be completely excluded from the analysis. However, the inclusion of events that are not pertinent can complicate the analysis unnecessarily.
- Rather than assigning quantitative impact scores to drivers in the matrix, it is sometimes useful to take a more qualitative approach to how the elements could interact and the outcomes they may bring. This can give you fresh perspectives on how many factors may come together in complex ways to create surprising futures.

## Figure: cross-impact matrix

A grid with the same list of drivers on both axes, rows down the left and columns across the top, followed by a final column, active impact sum, asking how strongly a driver impacts all others. The bottom row is labelled passive impact sum, asking how strongly a driver is impacted by all others. The diagonal cells, a driver against itself, are shaded and left blank. The worked example in the top row shows Driver #1 scored against the others as 2, 0, 1 and 3, summing to an active impact sum of 6. The scoring scale is 3 for strong and direct impact, 2 for medium impact, 1 for limited impact and 0 for no impact.

<!-- /canon/methods/delphi-method.md -->

---
type: Method
title: Delphi method
description: Iterates anonymised expert judgement over several rounds so that consensus, and the reasons for disagreement, become clear.
status: stable
use_when: "a question about the future needs structured expert judgement, showing where experts converge, where they diverge and where genuine uncertainty remains"
depends_on:
  - /canon/principles/foresight-as-collective-intelligence.md
  - /canon/concepts/cognitive-biases-in-futures-thinking.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Delphi Method"
  - id: root-gordon-delphi
    resource: "Gordon, T.J. (2009), The Delphi Method, Futures Research Methodology V3.0, The Millennium Project"
---

# Delphi method

A Delphi study is a collaborative foresight method designed to elicit consensus building among a panel of experts on a series of future hypotheses and propositions. The method is based on the principle that the collective foresight from a carefully selected group of experts, the Delphi panellists, provides superior insights and orientation on potential future developments compared to individual judgements and forecasts. This is especially true when dealing with complex areas with a high degree of uncertainty and incomplete knowledge.

## How it works

- While Delphi study applications are diverse, at its core the Delphi method is a controlled debate carried out over two or more iterative learning rounds.
- The first Delphi round establishes the group's initial views.
- In the second and subsequent rounds, feedback from the previous round, including current overall panel consensus measures and anonymised answers, is provided to all participants. This allows them to learn from the views of others and further develop their own opinions and reasoning based on their co-participants' input.
- A Delphi panel will usually move towards some level of consensus over several rounds. But even when this does not occur, the reasons for disparate positions and any high level of uncertainty become clear.
- The anonymity of a Delphi study is a key characteristic. Participants can know who else is involved, but not what they have said. This helps avoid groupthink and ensures that the process is not influenced by biased group dynamics.

## Real-time Delphi

- A less resource-intensive variant is the real-time Delphi method, which does not require multiple rounds.
- It leverages a digital platform to facilitate continuous, asynchronous interaction in the panel.
- This approach allows participants to monitor the panel's overall opinion and shifting consensus, and view comments and arguments made by other participants in real time.

## Use the Delphi method to

- Leverage the collective intelligence from a diverse group of experts.
- Provide orientation on complex future issues by understanding where expert judgement converges, where it diverges, and where genuine uncertainty remains.
- Support informed decision-making by providing structured expert judgement and a deeper understanding of key future issues.

## Key things to consider

- Delphi studies are difficult to do well, and a poorly designed Delphi can provoke antagonism and leave you with poor-quality insights. Therefore, a great deal of attention must be given to the choice of panellists. The experts involved need to be selected based on their knowledge and experience so that they can contribute with valuable insights, while also representing diversity of perspectives. It is crucial to bring in different areas of expertise related to the same focal issue to enrich the discussion and enhance the quality of the findings.
- The future hypotheses/propositions and their answer scales included in the Delphi must be meticulously prepared and tested to avoid ambiguity. The quality of the results depends on all panellists interpreting each hypothesis in the same way. If a hypothesis is ambiguous, panellists will respond based on their own differing interpretations, making the results difficult to trust.
- Delphi studies always tackle issues formulated in hypotheses/propositions about which uncertain and incomplete knowledge exists, and unlike traditional questionnaires, they do not rely on direct questions. The panellists should be prompted with the importance of providing elaborate argumentation for their choices and assessments, for the other panellists to consider in subsequent rounds.
- Normally, the number of participants in a Delphi is relatively small. Consequently, a Delphi study does not (and is not intended to) produce statistically significant results across a representative sample. It represents the synthesis of opinion of the group of panellists, no more, no less.
- The Delphi method is relatively complex to execute. It is a time-consuming and resource-intensive process and may therefore not be appropriate for projects with a short timeline or limited resources.

## Figure: Delphi method overview

A flow chart with two parallel tracks, round-based and real-time, which both start from and end in a shared box. At the top, Delphi preparation spans both tracks: recruiting the Delphi panel based on identified selection criteria, and developing futures hypotheses/propositions. The round-based track runs through four boxes in sequence: distribution round 1 (collecting responses from the initial survey), response analysis round 1 (analysing responses from round 1 and preparing feedback for round 2), distribution round 2 (collecting responses from the refined survey with open results from round 1), and response analysis round 2 (analysing responses to potentially feed into further rounds). The real-time track is a single box, Delphi distribution, collecting responses through continuous interaction and asynchronous participation, with a circular arrow looping between response and revisit. At the bottom, summary and results spans both tracks: dissemination of consensus results, key insights and areas of dissensus.

<!-- /canon/methods/driver-mapping.md -->

---
type: Method
title: Driver mapping
description: Clusters gathered signals into neutral drivers of change, by PESTEL, Verge or your own themes, so the forces beneath them can be prioritised.
status: stable
use_when: "the person has gathered signals or trends and needs to sort them into the underlying drivers of change and judge which matter most"
depends_on:
  - /canon/concepts/drivers-of-change.md
  - /canon/methods/horizon-and-environmental-scanning.md
  - /canon/concepts/trends.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Driver Mapping"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 60"
  - id: root-uk-futures-toolkit
    resource: "UK Government Office for Science (2024), The Futures Toolkit"
  - id: root-lum-verge
    resource: "Lum, R. (2014), Verge: a General Practice Framework for Futures Work"
---

# Driver mapping

Driver mapping helps to identify the most influential drivers of change in a system or in relation to a specific domain or focal topic. A driver of change is an underlying force that generates or shapes a trend or development. Drivers include things like shifts in attitudes and behaviour, as well as economic and technological forces that influence how something spreads and grows.

## How it works

- Driver mapping is essentially about making sense of gathered insights, such as from a scanning exercise, and identifying leading drivers based on their nature or typology. There are different ways to do this.
- One of the most common techniques is the PESTEL framework (or other acronym variants), where drivers are mapped across six different macro dimensions.
- Alternatively, the Verge framework, developed by Richard Lum and Michele Bowman, takes an ethnographic view, mapping change by its points of impact on people.

## Use driver mapping to

- Organise and understand key drivers of change and provide a more detailed picture of future developments facing an organisation.
- Produce a set of critical or important drivers as key input into further futures work and for the creation of futures scenarios.
- Look for affinity between signals to reveal the larger drivers beneath them. Where several signals (e.g. from a scanning exercise) move in the same direction, they often point to a single underlying driver.

## Key things to consider

- Driver mapping does not have to follow a predefined framework like PESTEL or Verge. Sometimes it may be desirable to cluster drivers by your own alternative themes that emerge from your brainstorm or research that are more suitable for your specific purpose.
- A driver should be 'neutral' and allow for different outcomes. In that sense, a driver should not be framed in a positive or negative form. For example, 'job loss from automation' is not neutral, but 'impact of automation on jobs' is a suitable driver.
- Look for possibilities to eliminate duplicates and merge drivers that are too similar. Too many drivers risk a longer analysis and treating less influential drivers as influential. Conversely, too few may limit the important dimensions of the analysis and lead to a simplistic one that omits critical drivers.
- At this stage, it can sometimes be desirable to identify the most important drivers by mapping them according to their impact on the domain or topic of interest and the uncertainty of the future direction or outcome of the driver. This approach is described in more detail as part of the Uncertainties Assessment tool.

## Figure: PESTEL framework

| Dimension | Description |
|---|---|
| Political | Political factors, such as interventions in societies and economies, (geo)political tensions, development goals, etc. |
| Economic | Economic factors, such as overall economic growth, markets, inflation, etc. |
| Social | Social factors, such as demographic change, changes in people's behaviour, values and lifestyles, etc. |
| Technological | Technological advancements and their influence on society, businesses, new innovations, etc. |
| Environmental | Environmental/ecological aspects, such as the effects of climate change, loss of biodiversity, new energy sources, etc. |
| Legal | Legal/regulatory factors, such as data protection, anti-discrimination laws, global regulatory issues, etc. |

## Figure: Verge framework

| Domain | Description |
|---|---|
| Define | Concepts, ideas and paradigms we use to define ourselves and the world around us (worldviews, social values, attitudes, etc.) |
| Relate | Structures, relationships and ways of interaction which organise people and organisations (social structures, governance structures, business models, etc.) |
| Connect | Technologies and practices used to connect people, places and things (digital technologies, media, music, language, etc.) |
| Create | Processes and technologies through which we innovate, design and produce (manufacturing, engineering, life sciences, rule-making, etc.) |
| Consume | Ways in which we acquire and consume the goods and services we create (modes of exchange, consumer preferences, marketing, etc.) |
| Destroy | Ways in which we destroy value and the reasons for doing so (waste, attempts to undermine rules and norms, repression, harmful reproduction of old systems, etc.) |

## PESTEL as a checklist

The PESTEL framework can be restrictive and prescriptive in the exploratory scanning phase. Use it as a checklist instead: once the trends are gathered, check whether all six dimensions are covered and whether anything from a dimension is missing.

<!-- /canon/methods/enablers-and-blockers.md -->

---
type: Method
title: Enablers and blockers
description: Explains a trend's trajectory as the power struggle between forces that sustain it and forces that slow or divert it.
status: stable
use_when: "someone is taking a trend at face value and needs to understand the forces that speed it up or hold it back, and where it might shift or break"
depends_on:
  - /canon/concepts/trends.md
  - /canon/concepts/the-friction-field.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Enablers & Blockers"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 23"
  - id: root-gordon-deft
    resource: "Gordon, A. (2010), A DEFT Approach to Trend-based Foresight"
---

# Enablers and blockers

The way future change occurs depends on the outcome of the power struggle between enabling and limiting forces. Forecasting methods typically derive trends from past data and extrapolate these trends forward without much consideration of the forces that nurture the trend and may eventually alter it. By using the Enablers and Blockers framework, we can get a better understanding of the dynamics of change of a given trend development.

## How it works

- This understanding is gained by identifying underlying dynamics in favouring forces (enablers) that create, sustain and catalyse a trend, and limiting forces (blockers) that stand in the way of a trend and slow it down, possibly even diverting it.
- In essence, this provides a framework for analysing factors that will influence and define how a specific development plays out.
- Understanding a trend or development as a reflection of underlying enabling and blocking forces reveals why trend trajectories are capable of sudden surprises and reversals.
- When thinking about future change, we always have to keep in mind that while a lot of things might change significantly, many things might also stay the same.

## Use enablers and blockers to

- Understand a trend as a reflection of underlying enabling and blocking forces.
- Acknowledge the complexity inherent in how change occurs.
- Better anticipate the inflection points where a trend's trajectory might shift.

## Key things to consider

- Start by assessing how a given trend is currently impacting your area of interest (industry, sector, etc.). This is followed by brainstorming factors that promote or catalyse the trend (enablers) and the factors that stop, limit or divert the trend (blockers).
- Try to construct your own trend development trajectory that reflects the power struggle between the identified enablers and blockers. Where/when enablers are strong and blockers are weak, we can expect the pace of change to be rapid. Where blockers are strong, we should expect them to deflect or slow the trend. Finally, discuss the future impact and implications that derive from the development.
- Be aware that sociocultural factors are often a key source of trend blocking. If the trend or development challenges prevailing social, cultural or ethical norms, it is likely that change will only proceed slowly, if at all.
- Equally important to identifying enablers and blockers is to identify potential trend breaks (a moment that can signal the end of an existing trend and the start of a new one) and inflection points (a moment where the rate of change shifts significantly, often marking a transition in the growth or decline phase of a trend). This can have wide-ranging implications for current strategic plans and priorities. Very often it is about timing.

## Figure: Enablers and Blockers canvas

A canvas with a horizontal axis running from present on the left to future on the right. An S-shaped curve labelled development trajectory rises from the bottom left, steepens in the middle and levels off at the top right. Blockers are labelled in the upper left area, with dots of varying sizes scattered above and around the early part of the curve. Enablers are labelled in the lower right area, with dots of varying sizes scattered below and around the later part of the curve. Dot size indicates the relative strength of each force. At the far right, where the curve levels off, a label reads implications/impact, for societies, industries, business environment, etc.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="ffenb" viewBox="0 0 560 350" style="display:block;width:100%;max-width:480px" role="img" aria-label="Enablers and blockers: an S-shaped development trajectory from present to future, blockers above its early part and enablers below its later part">
<style>
.ffenb text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.ffenb .b{font-weight:500;fill-opacity:.95}
.ffenb .s{font-size:10.5px}
.ffenb .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.ffenb .m{stroke-opacity:.5}
.ffenb .f{stroke-opacity:.2}
.ffenb .k{fill:#413C38}
.ffenb .o{fill:#FFC7A5;stroke:#413C38;stroke-opacity:.5;stroke-width:.75}
.ffenb text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="350" rx="14" fill="#fff"/>
<path class="l" d="M60,262 C210,262 250,64 430,64"/>
<circle class="o" cx="430" cy="64" r="5"/>
<text x="420" y="46" text-anchor="end">Development trajectory</text>
<text x="444" y="62" class="b">Implications</text>
<text x="444" y="76" class="s">and impact</text>
<text x="70" y="58" class="b">Blockers</text>
<text x="520" y="250" class="b" text-anchor="end">Enablers</text>
<circle class="l m" cx="112" cy="108" r="6"/>
<circle class="l m" cx="160" cy="150" r="4"/>
<circle class="l m" cx="96" cy="172" r="9"/>
<circle class="l m" cx="196" cy="112" r="5"/>
<circle class="l m" cx="146" cy="206" r="3"/>
<circle class="k" cx="300" cy="204" r="7"/>
<circle class="k" cx="352" cy="164" r="4"/>
<circle class="k" cx="392" cy="208" r="9"/>
<circle class="k" cx="424" cy="146" r="5"/>
<circle class="k" cx="342" cy="240" r="3"/>
<path class="l f" d="M60,290 H500"/>
<text x="60" y="312">Present</text>
<text x="500" y="312" text-anchor="end">Future</text>
<text x="280" y="312" class="s" text-anchor="middle">dot size shows strength</text>
<text class="ref" x="536" y="334" text-anchor="end">Source: Gordon, A. (2010), A DEFT Approach to Trend-based Foresight. Modified by CIFS.</text>
</svg>
```

## The friction field

- New trends and developments create friction in the existing environment, and the future unfolds in that friction field. Change enters on one side; implications for societies, industries and the business environment emerge on the other. Above the field act the turners and blockers, below it the drivers and enablers.
- A change driver may itself be a trend. Change blockers are the forces that oppose a trend by delaying, stopping or diverting it, and the factors that cause resistance to change.
- Whose side is the law on? The law is almost always, by design, a drag on the future, for good and for bad.
- Do not take a trend at face value. A trend can relatively easily be identified and analysed, but understanding the forces that promote or limit it gives the more detailed picture, and very often it is about timing.

<!-- /canon/methods/five-whys.md -->

---
type: Method
title: Five Whys
description: Gets beneath a product's inherited form by following its stated purpose and assumptions towards the need it is meant to serve.
status: draft
sources:
  - id: root-lean-enterprise-institute-5-whys
    resource: "Lean Enterprise Institute (undated), 5 Whys, citing Ohno, T. (1988), Toyota Production System, p. 17"
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, printed p. 17"
use_when: an explanation of a product stops at because this is how the product works, or a problem's causes need following back with evidence
depends_on:
  - /canon/concepts/first-principles.md
---

# Five Whys

Get beneath a product's inherited form by following its stated purpose and assumptions towards the need it is meant to serve.

## When it helps

- Within first-principles work, when an explanation stops at "because this is how the product works".
- To investigate a problem, provided causal claims are supported by evidence.

## Start with

- One specific statement that someone can explain.
- For product inquiry, a form or design choice.
- For an actual failure, observations of what happened.

## Working with the method

- Ask about the reason in the previous answer. Vary the wording so the inquiry remains purposeful: "What does that enable?", "Why is that necessary?" or "What need would remain if that disappeared?"
- Mark each answer as an observation, interpretation, assumption or value commitment. Branch when there are several explanations. Do not force a complex situation into one causal chain.
- When an underlying need becomes clearer, separate what should be preserved from how it is currently delivered. Return to first principles or Reimagine if the user wants to explore another form.
- Stop when an answer needs external evidence, reaches an explicit value choice or no longer changes the understanding. The number five is a prompt to go deeper, not a completion requirement.

## Useful questions

- "Why must someone visit the archive to access this knowledge?"
- "Is that necessary for the need itself, or a consequence of the way we built the product?"

## Capture

- Starting statement.
- Questions and answers.
- Evidence status at each link.
- Alternative explanations.
- Underlying need hypothesis.
- Preserve and reconsider choices.
- Unresolved question.

## Worked example

A constructed illustration, not a universal history of news archives.

- Why visit an archive? Because knowledge is stored as finished articles.
- Why only finished articles? Because publication was the organising unit.
- Why should that unit also determine access? The team recognises an inherited design assumption.
- Emerging need: reliable access to established knowledge in the user's context.
- Preserve provenance and accountability; investigate whether retrieval needs to remain article-led.

## Quality boundaries

- The method does not prove a root cause or a "true" user need.
- Do not supply invented answers to reach five, lead the user towards AI as a predetermined solution, or turn inquiry into blame.
- First principles is the broader approach; Five Whys is one technique that can support it.

<!-- /canon/methods/futures-swot-tows.md -->

---
type: Method
title: Futures SWOT-TOWS
description: Matches present strengths and weaknesses to the opportunities and threats of one future, so strategic initiatives come out of the crossing rather than from either side alone.
status: stable
use_when: "the person has a scenario in hand and needs to turn its opportunities and threats, set against today's strengths and weaknesses, into concrete strategic initiatives"
depends_on:
  - /canon/methods/scenario-development.md
  - /canon/methods/scenario-immersion.md
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 123 to 125"
  - id: root-porter-1985
    resource: "Porter, M. (1985), Competitive Advantage"
---

# Futures SWOT-TOWS

TOWS is derived from the SWOT analysis and is a practical tool to develop strategic options from an external and internal analysis, by matching current internal factors to future external factors. In strategic foresight it is used to identify relationships between an organisation's current strengths and weaknesses and the opportunities and threats in alternative futures, so as to identify the strategic options the organisation could pursue.

## How it works

The matrix crosses the internal present with the external future.

| Internal, present / External, future | Opportunities (O) | Threats (T) |
|---|---|---|
| Strengths (S) | S-O strategies: how can you leverage your strengths to capitalise on future opportunities? | S-T strategies: how can you leverage your strengths to avoid or minimise the impact of future threats? |
| Weaknesses (W) | W-O strategies: how can you address your weaknesses to capitalise on future opportunities? | W-T strategies: how can you address your weaknesses to reduce the impact of future threats? |

- For one scenario at a time, reflect on the opportunities and threats that emerge in it and on the organisation's current strengths and weaknesses that might influence how it can respond.
- Identify two to four strategic initiatives the organisation could implement in response to the strategic implications and the TOWS analysis, and capture each on its own initiative template.
- Be as clear as possible in the strategic reasoning and keep initiatives as actionable as possible. Avoid all-encompassing initiatives that try to capture everything believed to be important. Several options can apply to the same future opportunity or threat.

## Key things to consider

- S-O strategies are often the easiest and most intuitive to work with, because future opportunities are often maximised through innovation of new products and services that fit future needs, or business model innovation to fit a future competitive landscape. Those more versed in risk management may find the threats side easier.
- Initiatives tend to land at the customer end of the value chain. Organisations deploy strategic options at every point of the value chain, not only in customer-facing product and service development: optimising logistics networks, partnerships, joint ventures and acquisitions, procurement and sourcing, divesting or leaving markets, new revenue streams.
- The initiatives are the input to wind-tunnelling, where they are tested across the whole scenario set.

## Figure: the value chain

Five chevron arrows in a row for the primary activities, inbound logistics, operations, outbound logistics, marketing and sales, services; four horizontal bars beneath for the support activities, firm infrastructure, human resource management, technology development, procurement; a starburst on the right labelled value creation and profit.

<!-- /canon/methods/futures-triangle.md -->

---
type: Method
title: Futures triangle
description: Maps change as the friction between the push of the present, the pull from the future and the weight of history.
status: stable
use_when: "the person needs a quick, shared map of what is pushing change, what is pulling towards particular futures and what history holds back, before naming the issues that matter"
depends_on:
  - /canon/concepts/the-friction-field.md
  - /canon/concepts/trends.md
  - /canon/concepts/weak-signals.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Futures Triangle"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 59 to 67"
  - id: root-inayatullah-six-pillars
    resource: "Inayatullah, S. (2008), Six Pillars: Futures Thinking for Transformation"
---

# Futures triangle

The Futures Triangle, developed by Sohail Inayatullah, serves as an intuitive tool to guide our thinking and help us map the dynamics at play when change occurs across the three dimensions that shape future outcomes: the push of the present, the pull from the future and the weight of history. The tension and interaction between these three forces highlights that the way future change occurs depends on the outcome of the 'friction field' created between different forces. This helps us recognise that change is often not straightforward, and always multifaceted, as it is shaped by interacting forces.

## The three dimensions

### Push of the present

- Represents what is currently and evidently influencing future change in the external environment.
- Which trends and developments are creating change and carving out the trajectories ahead?

### Pull from the future

- Represents the novel developments and images of the future that may show up in the form of new assumptions and realities.
- Which matters at the margin of current thinking do not seem to fit into existing patterns? What visions and images are pulling us towards particular futures?

### Weight of history

- Represents the constraints and legacies of the past that shape the current situation and influence future possibilities, both in negative and positive terms.
- What are the deeply rooted structures that resist change? What are the dominant narratives that hinder progress? What are the sources of stability and values that are desirable to preserve and sustain?

## Use the Futures Triangle to

- Understand dynamics of change as a reflection of the tension and interaction of different forces and visualise the complexity inherent in how change occurs.
- Inquire into how the past has shaped the current system, and how deeply rooted structures and assumptions continue to influence future possibilities.
- Facilitate a process of thinking beyond the now and exploring novel developments and signals of change that are not always obvious in the present.

## Key things to consider

- The Futures Triangle is a simple tool that can be deployed anywhere, with minimal resources required. It is particularly useful in a collaborative setting where people can bring diverse perspectives to the table and build on each other's thinking.
- Be mindful that this is an explorative tool to help guide thinking and reveal how different dynamics work together to shape how the future may unfold.
- The primary focus of the exercise should not be to categorise and place things correctly along the three dimensions. It is the process of exploring the different dimensions of change that is most important.
- After you have explored the three corners of the triangle, have a discussion about the tensions and interactions that you encounter between the three forces. This should give you a deeper understanding of the complex dynamics of change that emerge within the triangle. Consider looking for paradoxes and friction points as well as factors that enable each other. It is a healthy sign if your triangle reveals paradoxes and aspects that are counterintuitive and point in 'opposite' directions.
- One way to surface these tensions is to zoom out and look across the triangle as a whole. This helps reveal where several entries share a common root, an underlying driver, even as they carry opposite charges, pulling in different directions across the corners. Identifying shared drivers beneath these surface signals is often what reveals where the deepest tensions lie. These drivers can then be carried forward and prioritised by their impact and uncertainty, as described in more detail as part of the Uncertainties Assessment tool.
- Exploring dynamics of change by using the Futures Triangle is relatively straightforward. It relies on insight, but also on intuition and divergent thinking, especially when it comes to the pull from the future. This can feel counterintuitive to those who are more practised in evidence-based strategic thinking.

## Figure: the Futures Triangle

A large triangle with plausible futures written in the centre. Each corner is labelled and has a small arrow pointing inward toward the centre: pull from the future at the apex, push of the present at the bottom left, and weight of history at the bottom right.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="fftri" viewBox="0 0 560 340" style="display:block;width:100%;max-width:480px" role="img" aria-label="Futures triangle: pull from the future, push of the present and weight of history around plausible futures">
<style>
.fftri text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.fftri .b{font-weight:500;fill-opacity:.95}
.fftri .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.fftri .m{stroke-opacity:.5}
.fftri text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="340" rx="14" fill="#fff"/>
<path class="l" d="M280,52 L448,268 L112,268 Z"/>
<path class="l m" d="M280,72 L280,106"/><path class="l m" d="M277.1,100.7 L280,106 L282.9,100.7"/>
<path class="l m" d="M138,252 L174,236"/><path class="l m" d="M170.4,240.8 L174,236 L168,235.5"/>
<path class="l m" d="M422,252 L386,236"/><path class="l m" d="M392,235.5 L386,236 L389.6,240.8"/>
<text x="280" y="204" class="b" text-anchor="middle">Plausible futures</text>
<text x="280" y="36" text-anchor="middle">Pull from the future</text>
<text x="112" y="294" text-anchor="middle">Push of the present</text>
<text x="448" y="294" text-anchor="middle">Weight of history</text>
<text class="ref" x="536" y="324" text-anchor="end">Futures triangle · Source: Inayatullah, S. (2008), Six Pillars: Futures Thinking for Transformation.</text>
</svg>
```

## Guiding questions for each corner

Push of the present:

- What notable trends and developments are evidently changing the future, at least somewhere in the world?
- What is pushing or driving change forward? What is happening in the contextual and industry environment?
- What is the nature and pace of change?

Pull from the future:

- What signals of change, discontinuities and novel shifts are pulling us towards particular futures?
- Which matters at the margin of current thinking do not seem to fit into existing patterns?
- Are there competing images or visions of the future?

Weight of history:

- What are the deeply rooted structures that resist change, such as prevailing cultural norms and values?
- What are the dominant narratives that hinder progress?
- What are the sources of stability and values that are desirable to preserve and sustain?

The interplay between the pull, the push and the weight creates the space of possible futures. It shows where momentum lies, where resistance exists and how clear the vision of the future is.

## Running it in a room

- Start with a silent brainstorm of around five minutes, one observation per note, considering both the contextual environment of macro forces and the operational environment of industry-related forces.
- Then discuss and collectively map the observations onto the triangle, adding new notes as perspectives emerge in the discussion.
- Remember that a lot can change, and a lot can stay the same, between now and the year in focus.

## From exploration to future issues of relevance

The triangle can be revisited to move from an explorative mapping to identifying future issues of strategic relevance. This is highly iterative and there is no fixed methodology. It is typically a discussion of the dynamics of change explored, looking for:

- Interactions of trends, visions and legacies that point in opposite directions, or that accelerate developments against the current trajectory.
- Paradoxes, logical opposites or dualities; friction.
- 'Either/or' questions about future developments or states that are surrounded by a lot of uncertainty.
- Key aspects or questions that leaders would most like to ask an 'oracle' about.
- What the people involved find interesting or of relevance to the scope or the sought-after strategic insight. This pragmatic take may feel compromising, but for a process and its scenarios to be used effectively, participants must be convinced and buy in; only then is there a chance they will contribute to decisions and actions.

## Exercise sheet: What is pushing, pulling and holding us back?

One of the kit's optional exercises: a one-page canvas with short instructions and space to work, for use with pen, paper and conversation, or alongside the assistant.

- Start with: one decision or change and any relevant evidence. Name the decision or change, first write all your observations and issues of relevance to it, then map them as trends, novel developments and weights.
- The canvas: a triangle with pull from the future at the top, push of the present at the lower left, weight of history at the lower right and plausible futures in the centre.
- At the end: a map of push, pull and weight, and one relationship that deserves attention.

<!-- /canon/methods/futures-wheel.md -->

---
type: Method
title: Futures wheel
description: Cascades a change outward through first-, second- and higher-order consequences to reveal counterintuitive impacts.
status: stable
use_when: "the person needs to think through the knock-on effects of a change, development, scenario or strategy, including second-order and counterintuitive consequences"
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Futures Wheel"
  - id: root-glenn-futures-wheel
    resource: "Glenn, J.C. (2009), The Futures Wheel, Futures Research Methodology V3.0, The Millennium Project"
  - id: root-california-100-soif
    resource: "California 100 & School of International Futures (2023), Beyond Strategic Planning: A Foresight Toolkit for Decision Makers"
---

# Futures wheel

The Futures Wheel, developed by Jerome Glenn, is a tool used to explore and map out the potential direct and indirect ripple consequences of a significant change, development or future scenario. It provides an intuitive framework for analysing the first-, second- and higher-order impacts of change, offering a visual representation of complex interconnections and dynamics. This makes it easier to understand how a change might influence various aspects of society, business and other domains. Additionally, the Futures Wheel helps reveal potentially counterintuitive consequences, offering deeper insights into how change can unfold and how unexpected impacts can emerge.

## How it works

- To construct a Futures Wheel, you begin by placing the change at the centre of the wheel.
- From there, you systematically work outward through the consequence cascade, creating a web of interconnected outcomes.
- This systematic approach helps you consider a wide range of possible impacts, including unexpected or non-obvious effects.

## Use the Futures Wheel to

- Identify impacts and consequences of important future changes, developments, scenarios or strategies (some possibly unintended).
- Think through first-, second- and higher-order impacts and map connections, causalities and even counterintuitive outcomes.
- Facilitate a participatory process that maps and visualises the cascades of impacts a significant change might generate.

## Key things to consider

- Focus on listing all the most immediate impacts first, before thinking about what cascades of second- and higher-order impacts may be. A good prompt is: "If this is true, what might be the immediate impacts?" The more specifically the impacts can be described, the better.
- Make sure you are not just thinking about positive or negative impact cascades. Ideally, a futures wheel should be a balanced representation and will likely also include counterintuitive outcomes. Also remember that the impact, and the perception of the impact, of a change can differ depending on the stakeholders involved.
- The simplest version of a Futures Wheel explores implications one step at a time as described. This can be expanded on to explore sentiment using colour-coding to represent desirable/less desirable change.
- After completing the wheel, arranging impacts into a timeline can add further insights. This often serves as a prompt to push your thinking further into the long term by running another round of adding higher-order impacts. Also be aware that more complex changes such as new policies, shifts in consumer behaviours or new technologies often necessitate deeper analysis and more rounds of futures wheeling to reach a useful depth of insights.

## Figure: the Futures Wheel

A central circle labelled change, driver or scenario. Arrows radiate outward from it to a first ring of circles each labelled impact, the first-order impacts. Arrows then radiate from each of those to a second, outer ring of circles, also each labelled impact, the second- and higher-order impacts. Dotted concentric guide circles mark the successive rings, producing a web of interconnected consequences cascading outward from the centre.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="ffwhl" viewBox="0 0 560 346" style="display:block;width:100%;max-width:480px" role="img" aria-label="Futures wheel: a change in the centre with first-order impacts around it and second-order impacts beyond">
<style>
.ffwhl text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.ffwhl .b{font-weight:500;fill-opacity:.95}
.ffwhl .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.ffwhl .m{stroke-opacity:.5}
.ffwhl .f{stroke-opacity:.2}
.ffwhl .d{stroke-dasharray:2 5}
.ffwhl .o{fill:#FFC7A5;stroke:#413C38;stroke-opacity:.5;stroke-width:.75}
.ffwhl text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="346" rx="14" fill="#fff"/>
<circle class="l f d" cx="280" cy="150" r="78"/>
<circle class="l f d" cx="280" cy="150" r="124"/>
<path class="l m" d="M280,118 L280,88"/><path class="l m" d="M282.4,92.4 L280,88 L277.6,92.4"/>
<circle class="l" cx="280" cy="72" r="12"/>
<path class="l m" d="M269.6,61.2 L249.3,40"/><path class="l m" d="M253.1,41.2 L249.3,40 L250.3,43.9"/>
<circle class="l m" cx="241.7" cy="32.1" r="7"/>
<path class="l m" d="M290.4,61.2 L310.7,40"/><path class="l m" d="M309.7,43.9 L310.7,40 L306.9,41.2"/>
<circle class="l m" cx="318.3" cy="32.1" r="7"/>
<path class="l m" d="M310.4,140.1 L339,130.8"/><path class="l m" d="M335.5,134.5 L339,130.8 L334.1,129.9"/>
<circle class="l" cx="354.2" cy="125.9" r="12"/>
<path class="l m" d="M361.3,112.7 L375.1,86.8"/><path class="l m" d="M375.2,90.8 L375.1,86.8 L371.8,89"/>
<circle class="l m" cx="380.3" cy="77.1" r="7"/>
<path class="l m" d="M367.7,132.4 L394.1,145.2"/><path class="l m" d="M390.1,145.4 L394.1,145.2 L391.8,142"/>
<circle class="l m" cx="404" cy="150" r="7"/>
<path class="l m" d="M298.8,175.9 L316.4,200.2"/><path class="l m" d="M311.9,198 L316.4,200.2 L315.8,195.2"/>
<circle class="l" cx="325.8" cy="213.1" r="12"/>
<path class="l m" d="M340.6,215.8 L369.5,220.9"/><path class="l m" d="M365.7,222.2 L369.5,220.9 L366.4,218.4"/>
<circle class="l m" cx="380.3" cy="222.9" r="7"/>
<path class="l m" d="M323.8,228 L319.8,257"/><path class="l m" d="M318.4,253.3 L319.8,257 L322.2,253.8"/>
<circle class="l m" cx="318.3" cy="267.9" r="7"/>
<path class="l m" d="M261.2,175.9 L243.6,200.2"/><path class="l m" d="M244.2,195.2 L243.6,200.2 L248.1,198"/>
<circle class="l" cx="234.2" cy="213.1" r="12"/>
<path class="l m" d="M236.2,228 L240.2,257"/><path class="l m" d="M237.8,253.8 L240.2,257 L241.6,253.3"/>
<circle class="l m" cx="241.7" cy="267.9" r="7"/>
<path class="l m" d="M219.4,215.8 L190.5,220.9"/><path class="l m" d="M193.6,218.4 L190.5,220.9 L194.3,222.2"/>
<circle class="l m" cx="179.7" cy="222.9" r="7"/>
<path class="l m" d="M249.6,140.1 L221,130.8"/><path class="l m" d="M225.9,129.9 L221,130.8 L224.5,134.5"/>
<circle class="l" cx="205.8" cy="125.9" r="12"/>
<path class="l m" d="M192.3,132.4 L165.9,145.2"/><path class="l m" d="M168.2,142 L165.9,145.2 L169.9,145.4"/>
<circle class="l m" cx="156" cy="150" r="7"/>
<path class="l m" d="M198.7,112.7 L184.9,86.8"/><path class="l m" d="M188.2,89 L184.9,86.8 L184.8,90.8"/>
<circle class="l m" cx="179.7" cy="77.1" r="7"/>
<circle class="o" cx="280" cy="150" r="28"/>
<text x="280" y="154" class="b" text-anchor="middle">Change</text>
<circle class="l" cx="136" cy="304" r="6"/>
<text x="148" y="308">First-order impacts</text>
<circle class="l m" cx="302" cy="304" r="4"/>
<text x="312" y="308">Second and higher order</text>
<text class="ref" x="536" y="330" text-anchor="end">Futures wheel · Source: Glenn, J.C. (2009), The Futures Wheel.</text>
</svg>
```

<!-- /canon/methods/horizon-and-environmental-scanning.md -->

---
type: Method
title: Horizon and environmental scanning
description: Gathers faint early signals and visible driving forces from the external environment so change is seen outside-in before it reaches the operating environment.
status: stable
use_when: "the person needs to look beyond what is on their radar for early signals and driving forces in the wider environment, or to set up ongoing monitoring of change"
depends_on:
  - /canon/concepts/weak-signals.md
  - /canon/concepts/trends.md
  - /canon/concepts/drivers-of-change.md
  - /canon/concepts/megatrends.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Horizon & Environmental Scanning"
  - id: root-eea-horizon-scanning
    resource: "European Environment Agency (2023), Horizon Scanning – Tips and Tricks: A Practical Guide"
  - id: root-un-global-pulse-horizon-scan
    resource: "UN Global Pulse (2022), Horizon Scan User Manual"
---

# Horizon and environmental scanning

Most foresight work begins with scanning the environment for evident driving forces and emerging patterns of change. There are different scanning practices that are often referred to interchangeably, though they actually serve distinct purposes.

## Two scanning practices

### Horizon scanning

- Focuses on the structured gathering of early signals and emerging developments, as well as discontinuities, that may have significant impact when they develop but are not yet widely recognised or understood.
- These emerging developments typically originate from the margins of current thinking and the fringes of society, technology, economy or culture. They may initially appear insignificant or disconnected from mainstream developments, and by their nature they are often faint, unstructured and unintended.
- One of the main objectives of horizon scanning is to broaden the perspective beyond what is currently on one's radar. Incomplete information and uncertainty about a signal's future development trajectory are inherent to this exercise.
- Certain signals and emerging developments may develop into strong drivers in the future, and may come with a new set of strategic issues not yet understood. Others may not.

### Environmental scanning

- Focuses more specifically on identifying influential driving forces and trends that exist in the external environment and that have the potential to change the future.
- Helps us understand what is already visible and what is (somewhat) evidently driving change, by analysing data and observing trends.

## Change happens outside-in

- One of the underlying principles of foresight work is that change happens 'outside-in', which in turn influences the envisioned strategic setting.
- An organisation's external environment can be considered in two layers. The contextual environment describes factors at the macro level that shape longer-term developments, and that an organisation has little or no influence over. The operating environment includes industry-related developments that are closer to the organisation, including developments in adjacent industries.
- The contextual environment affects the operating environment, and many of the drivers that will shape development in the longer term will emerge from outside an organisation's operating environment.

## Use scanning to

- Broaden your perspective beyond what is currently on your radar and detect potentially impactful 'weak signals' that might otherwise be overlooked, allowing for early recognition of emerging opportunities and threats.
- Monitor developments as part of early warning systems or risk management, helping organisations respond proactively to changes.
- Look beyond the most obvious trends and drivers to explore developments that fall outside current understanding.

## Key things to consider

- In our information-saturated world, there are almost unlimited sources of signals, insights and ideas available, so it is key to be intentional about the specific scanning exercise. Scanning that is too broad risks drowning in noise, so decide on a clear purpose and understand your scanning needs. Different modes of scanning require different tactics and potentially software tools. Scanning processes can vary from small-scale project-specific setups that are more 'handheld' and maybe even manual, to extensive and continuous organisational-level setups that are powered by complex digital platforms.
- The future 'intelligence' you are scanning for can be both qualitative and episodic as well as quantitative and supported by data. In scanning setups with the purpose of continuous monitoring, leading indicators or data sources that provide an early warning of changing conditions are identified. This is not required in many cases.
- You need a clear taxonomy, and clearly defined elements that are used for processing each of the scans, which also helps you make sense of your findings later. Scanning output can take many forms, from one-pagers with overall considerations and key indicators to extensive horizon scanning reports. Often, depending on purpose, endorsing simplicity in your scanning exercise provides the most useful outputs.
- Encourage divergent thinking and look to include signals that might feel uncertain or weird in the beginning. Throughout the process, the less relevant signals can be filtered out. Scanning is not the same as searching, as you are not on a mission to look for what you know or want, but rather to look for novelty. Think outside the box and investigate a broad range of sources.
- Conduct touchpoints or sessions to review, discuss and refine scanning outcomes. The scanning itself can be done alone, but it creates far more value when you collaboratively explore interactions across a wide range of trends and signals and assess their impact.
- Treat scanning as a capability that builds over time. As you keep practising, you develop a richer base of knowledge, which sharpens your ability to tell real signals from noise and to spot what others overlook.

## Figure: external environment and strategy space

A set of concentric rings. An arrow labelled megatrends and contextual environment enters from the left, pointing inward toward the outer rings. An arrow labelled operating environment enters from the right, pointing inward toward the middle rings. A vertical arrow labelled strategy development space descends from the top into the centre. The figure illustrates how the contextual environment encloses and affects the operating environment, which in turn encloses the space where strategy is developed.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="ffrng" viewBox="0 0 560 296" style="display:block;width:100%;max-width:480px" role="img" aria-label="Concentric rings: the contextual environment encloses the operating environment, which encloses the strategy development space">
<style>
.ffrng text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.ffrng .b{font-weight:500;fill-opacity:.95}
.ffrng .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.ffrng .m{stroke-opacity:.5}
.ffrng .f{stroke-opacity:.2}
.ffrng .o{fill:#FFC7A5;stroke:#413C38;stroke-opacity:.5;stroke-width:.75}
</style>
<rect width="560" height="296" rx="14" fill="#fff"/>
<circle class="l f" cx="280" cy="160" r="110"/>
<circle class="l m" cx="280" cy="160" r="72"/>
<circle class="o" cx="280" cy="160" r="34"/>
<text x="40" y="118">Megatrends and</text>
<text x="40" y="132">contextual</text>
<text x="40" y="146">environment</text>
<path class="l m" d="M40,160 L188,160"/><path class="l m" d="M182.7,162.9 L188,160 L182.7,157.1"/>
<text x="520" y="132" text-anchor="end">Operating</text>
<text x="520" y="146" text-anchor="end">environment</text>
<path class="l m" d="M520,160 L336,160"/><path class="l m" d="M341.3,157.1 L336,160 L341.3,162.9"/>
<text x="292" y="34" class="b">Strategy development space</text>
<path class="l m" d="M280,24 L280,142"/><path class="l m" d="M277.1,136.7 L280,142 L282.9,136.7"/>
</svg>
```

## Figure: useful elements in a scan

| Element | Description |
|---|---|
| Title of scan | Give your scan a title that captures the essence of the signal |
| Description | The scan in a nutshell. What is the signal about? What do you see? Why is it important and for whom? How and where is the signal emerging? |
| Awareness | Is the observation already on the radar of the organisation? Does this change something you already know? Is this something new to you? |
| Strength/Imminence | Assess how strong the signal is and how soon it may materialise (e.g. use a 1-5 scale) |
| Impact | Assess the potential impact the development could have (e.g. use a 1-5 scale) |
| Implications | Speculate on the possible implications of the signal |
| Opposing forces | Consider opposing developments that potentially refute the impact |
| Horizons | Consider implication pathways and the way a signal might develop in the near and far future |
| References | Name the source and the publication or interview details |

<!-- /canon/methods/organisational-memory-and-contextual-reuse.md -->

---
type: Method
title: Organisational memory and contextual reuse
description: An earlier attempt settles a new one only if what stopped it was a property of the idea rather than of the year it was tried in, so the attempt is taken through its blockers then and now before it is repeated or refused.
status: stable
sources:
  - id: ref-hvitved-2026
    resource: "Hvitved, S. (2026), Futures friction: a new approach to how media organisations remember, learn and reimagine, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute, sections Second brains and A reimagined media organisation in 2030"
  - id: ref-ffk-pattern-tried-before
    resource: "Futures Friction Kit, pattern Tried before, nobody remembers, AI Medialab Denmark, October 2026"
use_when: someone says we tried that already, nobody knows why an earlier attempt was shelved, or an idea is about to be built that someone has probably built before
depends_on:
  - /canon/methods/enablers-and-blockers.md
---

# Organisational memory and contextual reuse

Bring an earlier attempt into a current decision together with the conditions it was tried under, so that its lesson is tested rather than repeated blindly or refused on memory.

## When it helps

- Someone says "we tried something like that and it didn't work".
- Nobody knows why an earlier attempt was shelved; the person who ran it has left.
- An idea is about to be built that someone in the organisation has probably built before.

## The assumption to test

"We tried that" settles the matter only if what stopped the last attempt was a property of the idea rather than of the year it was tried in. A fresh attempt is safe only if none of those blockers is still standing.

## How it works

1. Find the last attempt's owner, its evaluation or its deck. Write down what it set out to do, what it showed, and what stopped it: the technology was too complicated, no one owned it, there was no time, the moment was wrong.
2. Put two columns on the whiteboard, headed with the year of the earlier attempt and this year, and take the attempt through Enablers and blockers as if it were a trend. In the first column, list what carried the attempt as far as it got and what stopped it. In the second, mark each of those forces stronger, weaker or gone, and add any new blocker that did not exist then.
3. Read the result. If the stopping forces have weakened, the idea has an inflection point and this year may be it. If they stand where they stood, the new attempt is the old one under a new name.
4. Keep the earlier result next to the new reading, with who ran it and when, and log the answer where the next person who has the idea will find it. Where no record exists at all, ask the longest-serving colleagues, and let the note become the first entry in the record.

## Key things to consider

- The person leaves knowing which forces to watch rather than which idea to avoid.
- A remembered conclusion is one person's account of what happened. The original evaluation may show something narrower, for example that the need was real but the way people had to reach it was not.
- The organisation's memory of an attempt often lives in someone who may have left, so every repeat pays the full cost of discovery again.
- An attempt can fail on timing alone: too early or too late, technologically possible but organisationally immature, or right for a future shift but impossible to anchor at the time.

<!-- /canon/methods/pace-layers.md -->

---
type: Method
title: Pace layers
description: Separates a system into six layers that change at different speeds, from fashion to nature, so fast and slow change can be told apart.
status: stable
use_when: "the person needs to tell fast-moving change from slow, foundational change in a system and see how the layers pull on each other"
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Pace Layers"
  - id: root-brand-pace-layering
    resource: "Brand, S. (2018), Pace Layering: How Complex Systems Learn and Keep Learning"
  - id: root-california-100-soif
    resource: "California 100 & School of International Futures (2023), Beyond Strategic Planning: A Foresight Toolkit for Decision Makers"
---

# Pace layers

Pace layers, developed by Stewart Brand, is a framework for thinking about the different factors that drive change in complex systems, and how they evolve over time. It highlights how different 'layers' of a system change at different speeds. There are six layers from fastest to slowest, and these layers interact with each other, with the top layers moving faster, while the slower layers provide a stabilising force and drive longer-term change. The (original) layers are Nature, Culture, Governance, Infrastructure, Commerce and Fashion, but practitioners sometimes choose to change the labelling of the different layers.

## The six layers

- Nature: the slowest and most foundational layer, encompassing the natural environment and ecosystems that change over very long timescales.
- Culture: this layer includes societal values, attitudes, beliefs and practices, evolving slowly over time.
- Governance: encompasses political structures and legal systems, regulations, shifts in policy and new reforms to provide societal order.
- Infrastructure: comprises physical and organisational systems that enable a functioning society.
- Commerce: involves economic activities, markets and competition, changing relatively rapidly to drive innovation and new business models.
- Fashion: represents trends in style, preferences and consumer behaviour, which reflect currents in society. This layer changes rapidly, influenced by popular culture, social media and short-term fads.

## Use pace layers to

- Think imaginatively about change and obtain a better understanding of how different components of a system interact and evolve over time.
- Grasp the dynamics of complex systems, and how change in one layer can bring about systemic change, whether rapid or slow.
- Help design systems, organisations and strategies that are adaptable and resilient by balancing the stability of slower layers with the dynamism of faster layers.

## Key things to consider

- The simplest approach to Pace Layers is to brainstorm ideas about what is shaping your focal topic, working through the pace layers. Start with the top three layers (fashion, commerce, infrastructure) to get an understanding of what is currently influencing future change. Then repeat the exercise for the bottom three layers (governance, culture, nature), keeping the longer timeframes in mind.
- The brainstorming outcome across layers can ideally be reviewed with the following prompts: "Which changes feel particularly relevant?", "What could accelerate the pace of change in the stabilising bottom layers?", "What could slow down the pace of change in the dynamic top layers?"
- You can extend the approach by examining how the different elements in the different layers interact and influence each other, looking for both convergence and potential conflicts that could arise between fast and slow layers.
- It is important not to get too hung up on the specific layers. It is the process of exploring different paces of change that is most important.
- Be mindful of the unique characteristics and needs of the system you are investigating. Some layers may have different significance or pace in different contexts. Also understand that cultural and historical factors can significantly influence the pace and nature of change in different layers, especially in global or diverse environments.

## Figure: pace layers

Six horizontal arrows stacked vertically, each pointing right, with its layer name to the right of it. The arrows vary in line weight and length to indicate relative speed and reach: the topmost, fashion, is thin and drawn as a wavy line, the fastest and most volatile and the longest, and each successive arrow below is thicker and shorter, slower and more foundational, through commerce, infrastructure, governance and culture to nature at the bottom, the thickest and shortest.

<!-- /canon/methods/premortem.md -->

---
type: Method
title: Pre-mortem
description: Declares a plan already failed and asks the team why, so that reservations people would not voice in an ordinary planning review surface while the plan can still change.
status: stable
use_when: "a plan is concrete enough to brief but not yet locked in, and the team needs to surface the reasons it could fail, including doubts no one has voiced"
depends_on:
  - /canon/methods/scenario-development.md
sources:
  - id: root-klein-2007
    resource: "Klein, G. (2007) Performing a Project Premortem, Harvard Business Review, September 2007"
---

# Pre-mortem

## What it is

A pre-mortem is a short group exercise run at the start of a plan, project or strategy. The facilitator tells the group to assume the plan has been carried out and has failed badly, and asks each person to write down what caused the failure. The exercise inverts the post-mortem, which examines a failure after it has happened, and applies the same diagnostic attention before anything has gone wrong.

The technique rests on prospective hindsight. When people are told an outcome has already occurred and asked to explain it, they produce more specific and more accurate reasons than when asked what might go wrong. The certainty of the framing, however fictional, unlocks explanations that a hypothetical framing leaves buried.

## When to use it

- Once a plan is concrete enough to be briefed to the people who will carry it out, and before commitments make it costly to change.
- When a team has converged quickly on a plan and no one has voiced doubts.
- When the people most likely to see a weakness are junior, new, or otherwise reluctant to contradict the plan's owners in a normal review.
- In foresight work, inside each scenario in turn, so the same plan is made to fail under several different futures and the causes can be compared.

## The steps

1. Brief the group on the plan so everyone is working from the same picture.
2. Announce that the plan has been executed and has failed completely. State it as fact, not as a possibility.
3. Give everyone a few minutes to write, on their own and in silence, every reason for the failure they can think of. Encourage the reasons that would feel impolite or disloyal to raise in a normal meeting.
4. Go round the room. Each person reads one reason from their list, starting with the person who owns the plan. Continue until every distinct reason has been recorded. No reason is debated during the round.
5. After the session, the plan's owner works through the list and decides which reasons warrant changes to the plan, which need monitoring, and which can be set aside.

## What it protects against

- Silence in the planning phase. Reservations that would never be raised as objections come out readily as explanations of a failure that has supposedly already happened.
- Overinvestment. People who are committed to a plan tend to dismiss risks. Asking them to explain a failure loosens that grip without asking them to argue against their own work.
- Undervalued knowledge. Team members who name a weakness no one else saw are recognised for their experience, and the rest of the group learns what they knew.
- Late detection. Having rehearsed the ways the plan could fail, the team recognises the early signs of those failures sooner once the plan is under way.

## Exercise sheet: What would make this fail?

One of the kit's optional exercises: a one-page canvas with short instructions and space to work, for use with pen, paper and conversation, or alongside the assistant.

- Start with: one plan and a future review date.
- The canvas: a timeline moves from today's plan to imagined failure at a future date, then returns the learning to today. Three rows connect possible causes with changes or checks and responsibility.
- At the end: possible reasons for failure and practical changes or checks to make now.

On the sheet:

- After the briefing, agree what failure would mean at the future review date, then imagine that it has happened.
- Write alone for five minutes, in the past tense: "It failed because...".
- Go round the room, one reason per person per turn, until all are recorded. Discuss afterwards, and note a level of concern from 1 to 5 for each reason.
- Choose the most consequential concerns. For each, record what you can change or check, connected to its cause, with an owner and a review date.

<!-- /canon/methods/reimagine.md -->

---
type: Method
title: Reimagine
description: Reconsiders how a product, service or process creates value when its present form is no longer taken for granted.
status: draft
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Causal Layered Analysis"
  - id: root-inayatullah-cla-1998
    resource: "Inayatullah, S. (1998), Causal layered analysis: poststructuralism as method, Futures 30(8), pp. 815 to 829"
use_when: incremental improvement keeps returning the team to the same design, or a future condition changes who needs the service, how it is encountered or what creates trust
depends_on:
  - /canon/concepts/first-principles.md
  - /canon/methods/five-whys.md
  - /canon/methods/causal-layered-analysis.md
  - /canon/methods/three-horizons.md
  - /canon/concepts/megatrends.md
---

# Reimagine

Reconsider how a product, service or process creates value when its present form is no longer taken for granted.

## When it helps

- Incremental improvement keeps returning the team to the same design.
- A future condition changes who needs the service, how it is encountered or what creates trust.

## Start with

- An identifiable product, service or process.
- An underlying need or purpose to examine.
- A future condition selected by the user. Choose a year only when it helps the inquiry.

## Working with the method

- Make the future condition tangible through a person's day: who they are, what they need, when they encounter information and in which situations. Use relevant moments rather than a compulsory daily timetable.
- Explore the underlying need, inherited assumptions and commitments through first principles and selective Five Whys. Distinguish what must remain true from what can disappear, including the current format or role.
- Rebuild the configuration: who interacts, including people, agents or both; where interaction happens; how provenance and editorial authority appear; and what role the newsroom plays. Let these dimensions inform one another.
- Use a metaphor to investigate the alternative logic and translate it into operations. In Inayatullah's Causal Layered Analysis, myth and metaphor relate to worldview, social causes and visible accounts of a problem. A metaphor exercise alone is not a full Causal Layered Analysis. An optional, explicitly imagined future headline can describe the surrounding world.
- Examine dependencies and challenges. Three Horizons can clarify whether the configuration changes system logic. Megatrend analysis can test the contextual assumptions; retain promising directions for appropriate testing, including nexus testing once its guidance is available.

## Useful questions

- "What would you build to serve this need under the conditions you have described?"
- "If the service is now a living memory, what must change in its ownership, corrections and everyday use?"

## Capture

- Object.
- Need.
- Future condition.
- Person and situation.
- Commitments.
- Assumptions.
- Who, where, trust and newsroom role.
- Metaphor or imagined headline, if used.
- Operational meaning.
- Dependencies.

## Worked example

A constructed illustration, not an observed case.

- During an imagined evening journey, a resident asks how a council proposal has changed.
- A newsroom reimagines its archive from "warehouse of published articles" to "public memory".
- The concept links claims across time, shows sources and corrections, and lets a journalist review contested answers.
- The metaphor exposes a governance question: whose experiences enter that memory and who can challenge omissions?
- The concept remains conditional, not a forecast.

## Quality boundaries

- A distant year, new interface or AI component does not establish transformation.
- Keep the need open to revision. Test what a metaphor hides as well as reveals.
- Day-in-the-life narratives and imagined headlines are constructions, not user research or forecasts.
- The assistant helps articulate the user's configuration without silently choosing their preferred future.

## Exercise sheet: What else could this become?

One of the kit's optional exercises: a one-page canvas with short instructions and space to work, for use with pen, paper and conversation, or alongside the assistant.

- Start with: one news product to rethink and one or two future conditions to explore, drawn from a megatrend or signal.
- The canvas: a day-in-the-life timeline, the product and the need, five whys, an assumption challenger with what must still be true and what can disappear or be transformed, an imagined news headline, and a rebuild for the future year.
- At the end: a reimagined news product for a future year you choose, grounded in a human need and an imagined day.

<!-- /canon/methods/scenario-development.md -->

---
type: Method
title: Scenario development
description: Builds a set of plausible, contrasting futures, from a 2 x 2 of critical uncertainties or anchored on core drivers, to provoke decision-makers and stress-test strategy.
status: stable
use_when: "the organisation needs a set of contrasting plausible futures to challenge its assumptions and stress-test strategy, or someone asks how to build scenarios"
depends_on:
  - /canon/methods/uncertainties-assessment.md
  - /canon/methods/driver-mapping.md
  - /canon/concepts/scenarios.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Scenario Development"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 80 to 109"
  - id: root-glenn-scenarios
    resource: "Glenn, J.C. & The Futures Group International (2009), Scenarios, Futures Research Methodology V3.0, The Millennium Project"
---

# Scenario development

Scenario development is one of the main concepts and most widely used methods in foresight. Both public and private sector organisations have implemented scenarios for a wide array of functions to support better longer-term strategic anticipation.

## How it works

- Scenario planning offers a structured approach that describes a plausible set of future conditions that are different to the present.
- Scenarios are always developed as a set, together mapping out a broad outcome space that allows different futures to be contrasted with one another and with the present, helping to break away from a deterministic view of the future. This allows organisations to consider alternative outcomes representing novel perspectives and contexts, as well as discontinuities, that may be difficult to grasp in the present.
- It is a process that involves both analysis and storytelling to craft credible and engaging images of the future that provoke decision-makers to think differently.
- Scenarios enable this by always adopting an 'outside-in' approach, focusing on potential changes in an organisation's external environment, including outcomes 'beyond the numbers' that might otherwise be overlooked. This, in turn, influences the organisation's strategic environment and consequently strategic decisions.
- In this way, scenarios provide a common outset and a basis for a well-informed discussion of future possibilities and challenges, enabling organisations to widen their strategic perspective and approach the future with curiosity, readiness and vision.
- There are different scenario development methods, two of which are described below. Both these approaches can vary in their level of detail and the resources required, depending on how extensively the process is scoped.

## 2 x 2 scenarios

- This approach is often used to build scenarios with a 'decision focus' and strategic relevance. It starts from identifying critical uncertainties in relation to the future in focus and then leverages these uncertainties to craft alternative futures.
- It is arguably the most extensive approach to scenario building and generally implies a step-by-step process that takes you through research, driver mapping and uncertainties assessment over a series of participatory workshops.
- To start building the actual scenarios, there is initially a need to identify critical uncertainties (see Uncertainties Assessment) that are combined as two axes of uncertainty in a 2 x 2 matrix. You should decide on an axis combination that will create the most interesting or valuable scenario matrix.
- As a rule, the two axes must be independent of each other, so that they don't collapse.
- Four 'scenario-spaces' emerge from combining the two axes of uncertainty, and each 'scenario-space' is then elaborated into complete narratives that consider relevant drivers and highlight key characteristics to make them relevant for decision-making.
- You should make sure events and characteristics in the scenarios are plausible and logically consistent. Also make sure that the four scenarios are structurally or qualitatively different.

## Driver-based scenarios

- Rather than organising scenarios around critical uncertainties and a 2 x 2 matrix, the driver-based approach anchors each scenario in a different core driver.
- You select a core driver, or a small cluster of drivers, to serve as a scenario's anchor, the thing that dominates and gives the world its character, and then build outward, working through how everything else behaves in the scenario given that driver's prominence. Which drivers can carry a world is a judgement made as part of the process, taking into account what is relevant to the project at hand.
- Contrast between the scenarios therefore comes from which driver dominates. This makes the set considerably more flexible, as driver-based scenarios are each constructed on their own terms and are not structurally locked to one another in a matrix.
- There are a few reasons to pursue this alternative approach. Most simply, it can move directly from driver mapping to scenario development, without requiring an uncertainties assessment first. It also avoids a common weakness of the 2 x 2, which sometimes invites 'lazy' axis polarity definition, crossing axes that are unidirectional, such as fast/slow or high/low polarities, leaving you with four relatively uninteresting and 'flat' scenarios, with little room for world-building or for properly exploring the focal issue.
- Alongside the scenario anchors, you identify a set of tension fields. These are further drivers, or central dimensions, each expressed as a spectrum, or slider, between plausible opposing directions of development. Determined by how the scenario unfolds around its anchor, each scenario then sits at a different point on each slider. Because the same tension fields run across every scenario, you can read the whole set at a glance and see how each dimension plays out differently from one future to the next.

## Use scenario development to

- Provoke decision-makers to think differently about alternative future outcomes that may be difficult to grasp in the present.
- Create a basis for stress-testing strategies against plausible futures, and guide and inform organisations about the threats and opportunities those futures hold.
- Facilitate futures-oriented conversation that builds shared understanding and stimulates strategic thinking about the future.

## Key things to consider

- Scenarios are not predictions of the future. They are not meant to be 'right' or 'wrong', 'good' or 'bad'. Rather, their function is to challenge assumptions and explore alternative ways that the future may develop. Explorative scenarios can have a richness that quantitative methods can't capture, which also helps to stimulate creativity and to break from the conventional wisdom around present and short-term problems.
- Crafting credible and useful scenarios is difficult. A good scenario is not just an abstract analysis of trends. Rather, it tells a believable story set in the future. Using a 'behind-the-scenes' scenario grid to map out key variables and elements across all scenarios helps ensure consistency. Additionally, following general guidelines can support the writing of quality scenario narratives.
- To make a scenario 'come alive', it can be helpful to think about what different personas might be doing in the future. How are they living? What do they value? How are they impacted in this scenario?
- For scenarios to be used effectively in a decision-making process, stakeholders must be convinced of the soundness, relevance and value of the process. This hinges on the foundations on which scenarios are built, the structures that they use, and the reasoning they employ, which must stand up to critical examination.
- The articulation and presentation of scenarios depend greatly upon the intended users. Some scenarios stay at the level of broad generalities without much supporting analysis, which may make them less operational and less useful for decision-making, while they may still provide the general public with inspiration on potential futures. Other scenarios that are presented in much more technical and formalised ways may offer deeper insights for decision-making but can be challenging for ordinary readers to assimilate.
- In a decision-making context, experience suggests that when stakeholders evaluate scenarios that are too extreme or implausible, they often become more confident in their original assumptions about the future. On the other hand, scenarios that are not challenging enough are easily dismissed as pointless. Both situations can lead to distrust in the foresight process. Finding the right balance is crucial for scenarios to have an impact on decision-making.

## Figure: scenario matrix

A 2 x 2 grid formed by two crossing axes, each running between polarity A and polarity B, forming four scenario-spaces labelled scenario A (top left), B (top right), C (bottom right) and D (bottom left).

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="ffscn" viewBox="0 0 560 350" style="display:block;width:100%;max-width:480px" role="img" aria-label="Scenario matrix: two critical uncertainties, each running between polarity A and polarity B, cross to form four scenario spaces, A to D">
<style>
.ffscn text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.ffscn .b{font-weight:500;fill-opacity:.95}
.ffscn .s{font-size:10.5px}
.ffscn .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.ffscn .m{stroke-opacity:.5}
.ffscn .f{stroke-opacity:.2}
.ffscn .x{font-size:9px}
.ffscn text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="350" rx="14" fill="#fff"/>
<path class="l m" d="M280,164 L158,164"/><path class="l m" d="M163.3,161.1 L158,164 L163.3,166.9"/>
<path class="l m" d="M280,164 L402,164"/><path class="l m" d="M396.7,166.9 L402,164 L396.7,161.1"/>
<path class="l m" d="M280,164 L280,42"/><path class="l m" d="M282.9,47.3 L280,42 L277.1,47.3"/>
<path class="l m" d="M280,164 L280,286"/><path class="l m" d="M277.1,280.7 L280,286 L282.9,280.7"/>
<rect class="l f" x="172" y="56" width="216" height="216" rx="6"/>
<text x="226" y="114" class="b" text-anchor="middle">Scenario A</text>
<text x="334" y="114" class="b" text-anchor="middle">Scenario B</text>
<text x="334" y="222" class="b" text-anchor="middle">Scenario C</text>
<text x="226" y="222" class="b" text-anchor="middle">Scenario D</text>
<text x="150" y="158" class="s" text-anchor="end">Polarity A</text>
<text x="410" y="158" class="s">Polarity B</text>
<text x="150" y="172" class="x" text-anchor="end">Critical uncertainty 1</text>
<text x="410" y="172" class="x">Critical uncertainty 1</text>
<text x="280" y="22" class="s" text-anchor="middle">Polarity A</text>
<text x="280" y="34" class="x" text-anchor="middle">Critical uncertainty 2</text>
<text x="280" y="302" class="s" text-anchor="middle">Polarity B</text>
<text x="280" y="314" class="x" text-anchor="middle">Critical uncertainty 2</text>
<text class="ref" x="536" y="334" text-anchor="end">Scenario matrix · Source: CIFS (2026), Toolkit for Applied Strategic Foresight.</text>
</svg>
```

## How to frame good scenario axes

Characteristics of good axes:

- Anchored in critical uncertainty: each axis should represent high impact and high uncertainty, the top right corner of the impact/uncertainty matrix.
- Explanatory power and relevance: strong explanatory value for the core area of interest and relevance for generating strategic insights. An axis should explain why the future might evolve in different ways.
- Stretch current thinking: able to challenge organisational perspectives and assumptions and provoke new thinking.
- Distinct, balanced polarities: each axis's polarities should describe clearly different logics or states of the world and represent balanced plausibility, both feeling credible with some evidence pointing toward them. Ideally 50/50, perhaps 60/40; beyond that it is no longer an uncertainty.
- Appropriate level of abstraction: an axis often combines several related uncertainties into a single, more meaningful dimension, allowing adequate exploration space and narrative richness.

Common pitfalls:

- Axis dependence: the two axes and their polarities must be independent of each other, or the axes 'collapse' into one dimension. Movement along one axis should not mean movement along the other, like two independent dials on a control panel. Public trust and political stability, or severity of climate impact and strength of climate policy, are pairs that collapse; demographic structure and geopolitical competition is a pair that holds.
- Normative framing: avoid framing polarities as 'good' versus 'bad', or likely versus unlikely. Keep them neutral and descriptive.
- One-to-one translation from the matrix: the impact/uncertainty matrix shows where critical uncertainty is present, but these uncertainties often need to be adjusted or reframed into broader logics to define scenario boundaries.
- Choosing two trends instead of two uncertainties, such as two developments that might both simply increase; one axis dominating the other, yielding two meaningful quadrants and two empty ones; conceptually interesting but strategically irrelevant axes that do not inform real-world choices.

Do not lock into axes too early. Experiment with different combinations on paper, and prompt with: do the four quadrants make intuitive and strategic sense? Can four distinct, believable futures be built around them? Adding a few bullets to each quadrant makes this clearer.

## Types of scenario approach

- 2 x 2 scenarios: built around two critical uncertainties that are independent and high impact, creating four structurally distinct worlds to stretch strategic thinking.
- Scenario archetypes: pre-imposed narrative structures such as growth, decline, constraint and transformation. Helpful for rapid framing, less tailored to specific system dynamics.
- Driver-based scenarios: organised around selected high-impact driving forces and assumptions about how they evolve, focusing on causal pathways rather than fixed narrative quadrants.
- Techniques from design disciplines: speculative and critical design methods that make futures tangible and experiential, prioritising provocation, imagination and embodied exploration over structural completeness.

## The scenario grid

The grid is the scaffolding behind scenario building. Its rows are the dimensions every scenario must address; its columns are the scenarios.

- Contextual dimensions are common to any scope: the zeitgeist or mood of the times, economy and global aspects, society and people, technology and the digital domain, sustainability and resources, regulation and governance.
- Context-specific dimensions belong to the scope in focus: for example the physical places and communities concerned, the landscape of the domain itself, the needs and expectations of its users, and work life.
- Scenarios should cover all three layers of the environment: megatrends and the contextual environment, the operating environment, and the strategy development space.

## Building a scenario

1. Spend a few minutes in silence listing the variables and dimensions that should be examined across all scenarios.
2. Start with the broad strokes: discuss the polarities that define the scenario and what their combination entails, prompting with "This is a world where...".
3. Work through the grid to unfold the scenario's dimensions, getting the dynamics right and making sure characteristics and events are plausible and consistent.
4. Build a short narrative from the grid that captures the essence of the scenario and helps people understand and relate to this future, with a catchy scenario title.
5. Present each scenario with its title, its narrative and an emerging dilemma. The scenario is not yet the organisation's strategy; it is a plausible future that should inform it.

<!-- /canon/methods/scenario-immersion.md -->

---
type: Method
title: Scenario immersion
description: Places the organisation inside one scenario at a time to read changed user needs, the competitive landscape and the strategic implications that must be considered.
status: stable
use_when: "scenarios exist and the person needs to work out what one future would mean for users, the competitive landscape and the organisation's strategic direction"
depends_on:
  - /canon/methods/scenario-development.md
sources:
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 112 to 122"
---

# Scenario immersion

Scenario immersion is the step from foresight to strategic insights. Having built a set of scenarios, the organisation immerses itself in one future at a time to understand what it would mean for its users, its competitive position and its strategic direction. It pulls on elements from strategy tools frequently used in strategic planning, such as the value proposition canvas and industry dynamics analysis.

## How it works

- Work one scenario at a time, from inside it.
- Consumer or user needs and expectations: what are they in this scenario, and how are they different from today?
- Competitive landscape: what does the playing field look like? Who are the players, what are the market characteristics, how has the field changed?
- Strategic implications: which future outcomes must be strategically considered, because they may impact strategic direction, objectives or actions? Identify fewer clear implications rather than many unclear ones.

A strategic implication is a future outcome that must be strategically considered, as it may impact strategic direction, objectives or actions.

## Which tools, for which insight

Depending on the sought-after strategic insight, different tools can be brought into the immersion.

Understanding tomorrow's options:

- Value proposition, or jobs to be done: what is our future value proposition, and what solution will fit our users and markets in this scenario?
- Business model canvas: what does the future competitive landscape look like, and what business model will fit our solution in this scenario?
- Industry dynamics analysis, personas and customer journeys, segment analysis, value-chain analysis.

Identifying today's decisions:

- SWOT-TOWS: how will we use our strengths and overcome our weaknesses to grasp the future opportunities and mitigate the future threats in this scenario?
- Wind-tunnelling: will our current strategies and initiatives still provide a path to success, and what appears successful across scenarios?
- Must-win battles: what are the key things we need to do to win in this scenario?

## Key things to consider

- Keep the scope of an immersion explicit, for example implications related to consumers, competition and market only, so the discussion does not sprawl.
- The immersion is not yet strategy. It explores a plausible future that should inform strategy.

## Figure: scenario immersion template

A tall worksheet with three rows and space beneath each heading: consumer or user needs and expectations, considering how they differ from today; competitive landscape, with market players and market characteristics; strategic implications, each a future outcome that must be strategically considered as it may impact strategic direction, objectives or actions.

<!-- /canon/methods/signposting.md -->

---
type: Method
title: Signposting
description: Defines observable indicators and triggers in advance so an organisation can tell which future is arriving and when to act.
status: stable
use_when: "the person needs to know which future is arriving and when to act, by defining indicators and trigger thresholds to monitor after foresight work"
depends_on:
  - /canon/methods/driver-mapping.md
  - /canon/methods/scenario-development.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Signposting"
  - id: root-schwartz-long-view
    resource: "Schwartz, P. (1991), The Art of the Long View. Planning for the Future in an Uncertain World"
---

# Signposting

Signposting is a structured approach to monitoring change in the external environment by identifying and tracking specific developments that indicate how key drivers are evolving, or whether future scenarios are beginning to unfold. Where most foresight tools help you explore what could happen, signposting helps you notice what is actually happening, and when it might be time to respond.

## How it works

- Signposting builds directly on previous foresight work, often Driver Mapping or Scenario Development, and is set up accordingly.
- Progressing from Driver Mapping, signposting monitors how key drivers evolve over time.
- Progressing from Scenario Development, signposts are tied to the critical uncertainties or key characteristics within each scenario, so that developments can be tracked to assess whether a particular scenario, or aspects of it, is starting to take shape.
- The value of signposting lies in timing. Foresight work widens the range of futures an organisation is prepared for, but it cannot say which one is arriving.
- The signposts should be defined as observable indicators that give early indication of which way things are moving, while triggers are specific thresholds or events that, once reached, signal that action or adjustment is needed.
- Together, they translate abstract scenarios into measurable realities, and a reached threshold becomes the prompt to revisit a strategic priority, activate a contingency plan or shift resources.

## Use signposting to

- Assess whether a particular scenario is beginning to play out, or whether a key driver is accelerating, decelerating or transforming.
- Establish when to act, by defining in advance what would signal that a strategic adjustment is needed.
- Keep foresight work alive after a project ends, translating scenarios into something that can be checked against reality and discussed over time.

## Key things to consider

- A good signpost is specific and observable, rather than a vague direction of development. It has to be something from which you can actually derive a shift in the relevant driver or scenario. Avoid indicators like 'regulatory changes' and focus on something you could point at and agree had happened, such as 'new privacy protection legislation being announced in three or more major jurisdictions'. That said, a signpost does not have to be a number. Some developments can be measured and supported by data, while others are only partially quantifiable and better understood through examples and observation.
- Keep the list focused. A handful of well-chosen signposts is more effective than a long list that dilutes attention and becomes impossible to maintain. For each one, decide what specifically will be monitored, how often it will be reviewed, and what would count as a significant development.
- Review and refine the signposts periodically. Because they are derived from a particular reading of drivers and scenarios, they go stale when that reading changes. Remove those that have become irrelevant and add new ones as strategic priorities shift, new intelligence emerges, or the underlying foresight work is revisited.
- Be cautious of confirmation bias. It is easy to notice the developments that confirm what you already believe, or hope, and to overlook equally valid signals pointing the other way. Aim for balanced evaluation by deliberately looking for evidence of outcomes you would rather not see.

## Figure: signposting template

A blank six-column worksheet with empty rows for entries. The first three columns, signpost (the observable development clearly described), driver/scenario (what this signpost tells you about) and threshold/trigger (what counts as significant), are marked as clearly defined when setting up. The last three columns, observations (what has been seen), status/interpretation (what it indicates) and action (what it prompts), are marked as revisited at each review.

<!-- /canon/methods/the-ma-brief.md -->

---
type: Method
title: The Ma brief
description: Before building a story that acts, one page answers where it ends, where it pauses, what it opens and when it falls silent, and one small experiment on one continuing issue tests whether people have more room to think for themselves.
status: stable
sources:
  - id: root-naij-fojo-2026-eeman
    resource: "Eeman, E. (2026), Journalism with room to move, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
use_when: a team wants to try a story that acts on one continuing issue and needs to settle its limits before any feature list, code or prompt is written
depends_on:
  - /canon/concepts/the-story-that-acts.md
---

# The Ma brief

A simple experiment over a couple of months, built around one continuing issue, is enough to begin exploring journalism with room to move. No agent that understands everything about us is needed first.

## Start with

- One continuing issue: a school merger, an energy transition, a hospital reorganisation, a housing plan.
- One story that can help people understand the issue and, if they choose, do something about it.

## The brief

Before anyone writes a line of code, before the feature list and before the prompt engineering, write one page answering four questions:

1. Where does it end? When does a person know they are done, and how does the product tell them?
2. Where does it pause? Which moves should wait, ask twice, or suggest sleeping on it?
3. What does it open? What will it offer that nobody asked for, chosen by whom, and labelled how?
4. When does it fall silent? What is the threshold below which it says nothing, and how can a person check that the story is still being followed?

## The experiment

- Keep the first version small. Offer a few supported ways to explore or apply the reporting, and make it easy to see how a person's question connects to the wider issue.
- Test it with a small group that includes people who rarely use the newsroom's products. Compare their experience with the article on its own and with the newsroom's existing alerts.
- Ask: did they understand the issue more accurately? Did they encounter a relevant question they had not considered? Could they take a useful step on their own terms? Could they finish when they had what they needed, without feeling pushed to keep interacting or to take a suggested action?
- Record the failures and the maintenance costs as carefully as the successful uses, then share the findings publicly so other newsrooms can learn what helped, what failed and what it took to maintain.

## The closing question

After spending time with this journalism, do you have more room to think and act for yourself?

## Key things to consider

- A calmer interface does not make reporting cheap. An acting story creates new costs as well as new value, and the people who would benefit most from help navigating public decisions may have the least money to spend on it.
- By 2030 this could start with a few stories that offer a useful service and grow only if the benefit is worth the work of maintaining them.

<!-- /canon/methods/the-seven-provocations.md -->

---
type: Method
title: The Seven Provocations
description: Audits the assumptions behind a view of the future, reframes each through one of seven provocations and plays out what follows if the future behaves differently.
status: stable
use_when: "a plan or outlook rests on unexamined assumptions about the future and the person needs a light way to surface, flip and play them out"
depends_on:
  - /canon/concepts/assumptions.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section The Seven Provocations"
---

# The Seven Provocations

The Seven Provocations, first developed in-house at CIFS, uses structured provocation to surface the assumptions underpinning a current view of the future, confront them, and explore what follows if the future behaves differently. The assumptions it targets are the embedded beliefs that underpin an organisation's understanding of how the future will behave, and ultimately its future strategic outlook. These are assumptions that often go unexamined in strategic thinking, and, left unchallenged, they can create a confirmation pathway towards a flawed or overly deterministic view of the future.

The method is simple and accessible by design. While provocation is embedded in many traditional foresight methods, the Seven Provocations is particularly valuable in contexts where those methods may prove too abstract, complex or demanding.

## How it works

1. An assumption audit surfaces the assumptions central to your understanding of how the future will unfold, making explicit the external conditions that need to hold true for a current outlook to be 'on point'.
2. You reframe those assumptions through the lens of one or more of the seven provocations.
3. You play out the implications if the provoked version of the future were to unfold.

## The seven provocations

Each of the seven provocations takes a different angle, depending on the nature of the assumption you are seeking to challenge.

### Provocations that challenge assumptions about direction, continuity and inevitability

- The Flip: What if an assumption you hold turns out to be misaligned, or even in direct opposition, to how the future eventually unfolds?
- The Discontinuity: What if defining features of current reality or dominant 'ways of doing' are rendered obsolete in the future?
- The Resistant: What if a development or change you strongly expect to happen is delayed or stopped by the weight of present structures or habits?

### Provocations that challenge assumptions about timing and pace

- The Overcorrection: What if an emerging change that appears transformative today levels off or becomes less transformative in the long term?
- The Undercorrection: What if a change that seems marginal or easy to dismiss today becomes far more transformative in the longer run than initially assumed?

### Provocations that challenge emotionally and morally loaded assumptions

- The Uncomfortable Truth: Which uncomfortable or inconvenient 'truths' about the future are being consciously or subconsciously avoided?
- The Value Lock-in: As we lock in on a transformation towards a system or paradigm seen as more desirable, what embedded constraints, exclusions or dependencies might shape that preferred future in limiting ways?

## Use the Seven Provocations to

- Surface the assumptions underpinning an organisation's current outlook on the future, and by extension the strategic decisions, business models and policies that stem from it.
- Work through what would follow, strategically, if a foundational assumption does not hold and the future behaves differently from what is expected.
- Bring provocation into a strategic conversation on the future where more demanding foresight methods would be too abstract, complex or resource-heavy.

## Key things to consider

- Some assumptions are explicit and widely shared across organisations or industries, while others are more implicit and specific to a particular context. By asking people to articulate why they believe something to be true, their assumptions become embedded in the answers. The facilitator's role is then to listen critically, identify those assumptions, both explicit and implicit, and make them discussable.
- The provocations can be used individually or in combination. While some provocations may overlap and some implications will repeat, each offers a distinct lens to reframe what is currently taken for granted about the future. When selecting which provocations to use, it is helpful to consider the nature of the assumptions you are seeking to challenge.
- The Value Lock-in is the most philosophically layered of the seven and may be less operationally relevant at an organisational level than the others. But it is also the one that provokes the deepest layer of assumptions.
- The template provides a practical structure for working through one provocation at a time. You can use it repeatedly to test different assumptions, or to apply several provocations to the same one. Remember to capture additional reflections on whether the provocation exposes something worth exploring further.

## Figure: the Seven Provocations template

A blank worksheet. A single field runs across the top, provocation used, followed by a fill-in line. Below it are four empty columns for working through one provocation: assumption to challenge (state an assumption, expectation or belief about how the future will unfold), reframed assumption (rewrite the assumption through the lens of the provocation), potential (strategic) implications (list key implications if this provoked version of the future were to unfold), and additional reflections (consider how central this assumption is to your current outlook, and whether this provocation exposes something worth exploring further).

## Exercise sheet: What are we assuming?

One of the kit's optional exercises: a one-page canvas with short instructions and space to work, for use with pen, paper and conversation, or alongside the assistant.

- Start with: one plan and the period it needs to work in. Name the plan and its time horizon, then choose one assumption in the plan: what do we expect to be true about how the future will unfold?
- The canvas: the seven provocations as prompts beside four writing columns for an assumption, its reframing, implications and reflections.
- At the end: one assumption reframed, its implications and a question worth exploring.

<!-- /canon/methods/three-horizons.md -->

---
type: Method
title: Three horizons
description: Frames change as a dominant system declining while a transformed one rises, explored in the order H1, H3, H2 to avoid path-dependent thinking.
status: stable
use_when: "the person needs to see how today's dominant way of working may decline as a transformed one rises, and what is transitional between them"
depends_on:
  - /canon/concepts/assumptions.md
  - /canon/concepts/weak-signals.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Three Horizons"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 45 and 116"
  - id: root-sharpe-three-horizons
    resource: "Sharpe, B. (2013), The Three Horizons: The Patterning of Hope"
  - id: root-curry-hodgson-2008
    resource: "Curry, A. & Hodgson, A. (2008), Seeing in Multiple Horizons"
---

# Three horizons

The Three Horizons framework, developed by Bill Sharpe, is useful to assess pathways of change, and how change can unfold over different time horizons. The framework assumes that change happens in waves in which a dominant form is eventually overtaken and displaced by another. Emerging change will challenge our current paradigm and assumptions, and over time today's decisions, policies and products will become obsolete. This is particularly useful for understanding societal transitions, where a status quo or dominant system declines and a new system rises in its place.

## The three horizons

- Horizon 1 (H1) is the dominant system at present. It represents the 'business as usual' in terms of developments and current assumptions that are important/manifested in the present and that define how we engage with the world. We rely on these systems being stable and reliable. But as the world changes, aspects of 'business as usual' begin to feel out of place, misaligned or even obsolete.
- Eventually, H1 will be superseded by new systems, developments and realisations that will grow in importance in the medium term: Horizon 2 (H2). Exactly how H2 will develop may not be apparent yet. Some aspects will be absorbed into the H1 systems to improve them and to prolong their life, while others will facilitate a transition from the present to Horizon 3.
- Horizon 3 (H3) will bring transformational shifts and completely new paradigms from the present.

## Order of exploration

- You normally progress through the exploration of the different horizons in this order: H1, H3, H2.
- Without establishing H3 before H2, it becomes impossible to make the distinction between aspects in H2 that will contribute to sustaining H1 and those that will facilitate a transition to H3.
- This sequence will also help prevent 'path-dependent' thinking through the three horizons.

## Use Three Horizons to

- Reveal current assumptions about the future and make them explicit, allowing us to reimagine how transformational shifts away from today may arrive.
- Better assess potential pathways of change, and identify drivers that maintain the status quo and drivers that push towards transition.
- Recognise how strategies aligned with the present will decline in changing and emerging conditions, and where current assumptions leave you vulnerable.
- Highlight the value of thinking in different horizons at the same time.

## Key things to consider

- The Three Horizons exercise should ideally be highly collaborative and include diverse perspectives. This is key to revealing current assumptions and making them explicit, better allowing us to reimagine how we might arrive at a Horizon 3 future that represents transformational shifts from today.
- Remember to debrief the key takeaways from the exercise, with a specific focus on the most interesting and intriguing Horizon 3 futures and the most relevant 'transitions' in Horizon 2.
- The three horizons should not just be seen as abstract representations of change, but as three qualitatively different orientations to the future in the present. There is no fixed definition of what 'near- to mid- to long term' means and all three horizons are always present. For example, early manifestations of H3, pockets of the future, are already visible in the present.
- A powerful feature of the framework is the built-in distinction between aspects that are maintaining or improving on the status quo versus those that are pushing towards transformation. This helps organisations think about change that has the potential for deep transformation. The displacement of horizons may be gradual, but in times of rapid change they can be quite abrupt as different tipping points may occur.

## Figure: the Three Horizons framework

A line chart with three overlapping S-curves plotted against a horizontal time axis marked now, medium term and longer term. H1 starts high on the left and declines steadily across the chart. H2 starts low, rises to a peak around the medium term, then declines again. H3 starts very low on the left, labelled pockets of the future found in the present, and rises steadily to become dominant in the longer term. The curves cross one another, illustrating how the dominant system (H1) is progressively displaced, first by transitional developments (H2) and ultimately by the transformed paradigm (H3).

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="ffhz" viewBox="0 0 560 264" style="display:block;width:100%;max-width:480px" role="img" aria-label="Three horizons: H1 declines from the present, H2 rises and falls through the transformation, and H3 rises to dominate in the long term, which is shaded">
<style>
.ffhz text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.ffhz .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.ffhz .z{fill:#FFC7A5;fill-opacity:.22}
.ffhz .c1{fill:none;stroke:#5B63AD;stroke-width:2.2;stroke-linecap:round}
.ffhz .c2{fill:none;stroke:#E3DBCC;stroke-width:2.2;stroke-linecap:round;stroke-dasharray:12 8}
.ffhz .c3{fill:none;stroke:#FFC7A5;stroke-width:2.2;stroke-linecap:round;stroke-dasharray:5 5}
.ffhz .h1{font-size:18px;font-weight:700;fill:#5B63AD;fill-opacity:1}
.ffhz .h2{font-size:18px;font-weight:700;fill:#E3DBCC;fill-opacity:1}
.ffhz .h3{font-size:18px;font-weight:700;fill:#FFC7A5;fill-opacity:1}
.ffhz .y{font-size:8px;font-weight:500;letter-spacing:.7px;fill-opacity:.9}
.ffhz text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="264" rx="14" fill="#fff"/>
<rect class="z" x="368" y="24" width="146" height="184"/>
<path class="l" d="M76,58 V208 H514"/>
<path class="c2" d="M76,146 C153,142 215,78 295,78 C375,78 437,142 514,146"/>
<path class="c3" d="M76,186 C245,186 318,86 514,82"/>
<path class="c1" d="M76,86 C235,66 297,176 514,182"/>
<text x="149" y="48" class="h1" text-anchor="middle">H1</text>
<text x="149" y="226" class="y" text-anchor="middle">NOW</text>
<text x="295" y="48" class="h2" text-anchor="middle">H2</text>
<text x="295" y="226" class="y" text-anchor="middle">TRANSFORMATION</text>
<text x="441" y="48" class="h3" text-anchor="middle">H3</text>
<text x="441" y="226" class="y" text-anchor="middle">LONG-TERM</text>
<text class="ref" x="536" y="248" text-anchor="end">Three horizons · Source: Curry, A. &amp; Hodgson, A. (2008), Seeing in Multiple Horizons. Modified by CIFS.</text>
</svg>
```

## Strategic fit changes over time

- The vertical axis of the framework is the degree of strategic fit with the external environment. The first horizon, the prevailing system as it continues into the future, loses fit over time as its environment changes. The third horizon holds ideas or arguments about the future of the system that are at best marginal in the present, 'pockets of future' embedded in it, but which over time may displace the first. The second horizon is the intermediate space where the first and third collide, a space of transition that is typically unstable.
- Two kinds of thinking sit over the chart. Tactical thinking, working from data and evidence, is the traditional strategist's 'predict and control', improving the existing. Transformation and novelty, explorative and creative, is the work of strategic foresight, challenging assumptions and anticipating novelty. Which kind fits depends on where the organisation stands on the horizons.

## Exercise sheet: Where does this innovation belong?

One of the kit's optional exercises: a one-page canvas with short instructions and space to work, for use with pen, paper and conversation, or alongside the assistant.

- Start with: three to five innovation projects and a short description of each.
- The canvas: three curves on a time axis, where H1 declines, H2 rises and falls and H3 rises, with writing areas that explore H1, H3 and the H2 transition.
- At the end: a map of where each innovation project belongs, the reasons behind it and one missing connection.

The people doing the exercise place each innovation project by the change it supports, and write why. A project's purpose and effects determine the placement, never its launch date or its technology. Three questions guide it, taken in the order of exploration, H1, H3, H2:

1. H1: does it fit the current strategy? Are you optimising existing products and processes based on data, control and return on investment in the short term?
2. H3: is it something that completely rethinks? Is it a pocket of future that serves a new ecosystem? Is it challenging core assumptions?
3. H2: is it an experiment that might soon fit? Is your project a smaller experiment that might fit for a short time or be a bridge towards H3?
4. One missing connection: look at the map as a whole. Which connection is missing between what you do today and the H3 you have described?

<!-- /canon/methods/uncertainties-assessment.md -->

---
type: Method
title: Uncertainties assessment
description: Sorts drivers by impact and degree of uncertainty to isolate the critical uncertainties that longer-term planning must prepare for.
status: stable
use_when: "the person has a set of drivers or future issues and needs to know which are high impact and genuinely uncertain, the critical uncertainties to plan for"
depends_on:
  - /canon/concepts/uncertainty.md
  - /canon/concepts/drivers-of-change.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Uncertainties Assessment"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 66 to 75"
  - id: root-schwartz-long-view
    resource: "Schwartz, P. (1991), The Art of the Long View. Planning for the Future in an Uncertain World"
  - id: root-uk-futures-toolkit
    resource: "UK Government Office for Science (2024), The Futures Toolkit"
---

# Uncertainties assessment

A fundamental aspect of strategic foresight is identifying and engaging with critical uncertainties for the purpose of longer-term strategic planning. Critical uncertainties are high-impact drivers with uncertain outcomes that can significantly influence the future. To identify these uncertainties, the Impact/Uncertainty matrix can be used to assess drivers based on their impact and degree of uncertainty in relation to the focal issue. Identifying critical uncertainties often serves as the starting point for defining axes of uncertainty, which are then used in scenario building to explore different possible futures.

## How it works

- Uncertainties are different from trends in that they involve a lack of predictability regarding the future direction, strength and/or outcomes of a particular driver. Uncertainty, in this context, refers to the unpredictability of how things might manifest in the future.
- Hence, we should be able to identify two 'extreme' but plausible directions of development or outcomes, polarities, by describing alternative ways that a driver might bring change.
- Uncertainties are then deemed critical when they are also assessed to have high strategic impact.

## The quadrants of the Impact/Uncertainty matrix

- High-impact/low-uncertainty drivers (top left quadrant): the high-impact drivers with relative certainty. These are factors that should be monitored closely and preferably acted on in current strategic planning.
- High-impact/high-uncertainty drivers (top right quadrant): the critical uncertainties. They could shape very different futures, so longer-term planning should seek to anticipate and prepare for them.
- Low-impact drivers (bottom quadrants): secondary drivers that, for the time being, can be disregarded for the purpose of strategic foresight. They should still be monitored, as they may develop into higher-impact drivers over time.

## Use uncertainties assessment to

- Evaluate which drivers are surrounded by more or less certainty and identify strategically important critical uncertainties.
- Help question the assumptions we have about the direction of the future and guide decision-making under uncertainty.
- Lay the groundwork for scenario development, where two critical uncertainties form the axes of a scenario matrix.

## Key things to consider

- A driver is assessed to have high impact (on the 'impact' axis) when it possesses the ability to fundamentally alter the business environment or the focal issue. This axis is often used in relative terms to help prioritise the drivers with the most significant potential to drive fundamental change.
- Be especially aware of how the 'degree of uncertainty' is defined in this context. A driver is assessed to have a low degree of uncertainty when you find reasonable certainty around its future direction of development. On the other hand, a driver is assessed to have a high degree of uncertainty when you are very uncertain about the future direction in which it will bring change. In other words, a driver is deemed uncertain when we are faced with alternative ways it might bring change in the future.
- Be aware of how our biases affect the assessment of uncertainties. You should always refrain from claiming that something is not uncertain (low degree of uncertainty) just because one of the outcomes is less desirable for you or your organisation.
- It is not easy to identify genuine critical uncertainties. Hence, for the critical uncertainties (top right quadrant) you always need to have a discussion to crystallise what exactly it is you are uncertain about in relation to the specific driver. There is likely more than one uncertain factor related to a critical uncertainty. This depends on the level of granularity at which an uncertainty is described. Also, check for the possibility to group any related critical uncertainties, to make sure that you don't have different versions of the same uncertainty.
- The Impact/Uncertainty matrix can be used in two different ways. Sometimes you have a consolidated list of drivers that you want to map according to their impact and uncertainty to identify the critical uncertainties before you describe alternative ways that a driver might bring change (i.e. define polarities). At other times you may want to use the matrix as a prioritisation mechanism of already defined uncertainties with polarities.

## Figure: Impact/Uncertainty matrix

A two-by-two matrix. The vertical axis is impact, from low at the bottom to high at the top. The horizontal axis is degree of uncertainty, from low on the left to high on the right. Three boxes are drawn inside, with scattered dots representing individual drivers: high-impact drivers at the top left, which should be considered in all scenarios; critical uncertainties at the top right, the main focus of scenario analysis; and secondary drivers along the bottom, spanning the full width, which should not currently be used in the scenario analysis.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="ffimp" viewBox="0 0 560 344" style="display:block;width:100%;max-width:480px" role="img" aria-label="Impact and uncertainty matrix: high-impact drivers, critical uncertainties and secondary drivers">
<style>
.ffimp text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.ffimp .b{font-weight:500;fill-opacity:.95}
.ffimp .s{font-size:10.5px}
.ffimp .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.ffimp .m{stroke-opacity:.5}
.ffimp .f{stroke-opacity:.2}
.ffimp .k{fill:#413C38}
.ffimp .w{fill:#FFC7A5;fill-opacity:.45}
.ffimp text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="344" rx="14" fill="#fff"/>
<path class="l m" d="M76,44 V268 H524"/>
<rect class="l m" x="90" y="52" width="196" height="118" rx="8"/>
<rect class="w" x="300" y="52" width="210" height="118" rx="8"/>
<rect class="l m" x="300" y="52" width="210" height="118" rx="8"/>
<rect class="l f" x="90" y="184" width="420" height="72" rx="8"/>
<text x="102" y="74" class="b">High-impact drivers</text>
<text x="102" y="90" class="s">in all scenarios</text>
<text x="312" y="74" class="b">Critical uncertainties</text>
<text x="312" y="90" class="s">the focus of the scenarios</text>
<text x="102" y="206" class="b">Secondary drivers</text>
<text x="102" y="222" class="s">not used for now</text>
<circle class="k" cx="132" cy="128" r="3"/>
<circle class="k" cx="182" cy="148" r="3"/>
<circle class="k" cx="238" cy="120" r="3"/>
<circle class="k" cx="262" cy="152" r="3"/>
<circle class="k" cx="352" cy="128" r="3"/>
<circle class="k" cx="412" cy="114" r="3"/>
<circle class="k" cx="458" cy="150" r="3"/>
<circle class="k" cx="392" cy="152" r="3"/>
<circle class="k" cx="484" cy="112" r="3"/>
<circle class="k" cx="262" cy="216" r="3"/>
<circle class="k" cx="322" cy="238" r="3"/>
<circle class="k" cx="402" cy="212" r="3"/>
<circle class="k" cx="472" cy="236" r="3"/>
<circle class="k" cx="212" cy="242" r="3"/>
<text x="70" y="58" class="s" text-anchor="end">High</text>
<text x="70" y="264" class="s" text-anchor="end">Low</text>
<text x="44" y="160" text-anchor="middle" transform="rotate(-90 44 160)">Impact</text>
<text x="90" y="288" class="s">Low</text>
<text x="510" y="288" class="s" text-anchor="end">High</text>
<text x="300" y="308" text-anchor="middle">Degree of uncertainty</text>
<text class="ref" x="536" y="328" text-anchor="end">Impact / uncertainty matrix · Source: Schwartz, P. (1991), The Art of the Long View. Modified by CIFS.</text>
</svg>
```

## From issues to critical uncertainties

Assessing critical uncertainties is a deductive phase that usually follows the exploration of trends and dynamics of change.

- A future issue is broader in scope than a trend. It encapsulates interactions, frictions and sometimes paradoxes between related underlying driving forces, where future developments are ambiguous or unclear, yet where the potential developments carry relevance for the future in focus.
- For each issue, the discussion crystallises what it is we are uncertain about, and whether two 'extreme' but plausible sets of outcomes, polarities, can be meaningfully identified.
- There can be more than one uncertain factor related to each issue, depending on the level of granularity at which an uncertainty is described. Check for the possibility to group related uncertainties, so that there are not different versions of the same uncertainty.
- Issues with high impact and high uncertainty are the critical uncertainties, and identifying them is often the outset for defining the axes of uncertainty for scenario building.

| Future issue | Uncertainty | Polarities |
|---|---|---|
| Access versus ownership | How will end-users engage with asset ownership? | Access more important than ownership, or ownership still widespread |
| Urban mobility alternatives | To what extent will cars remain central in future urban mobility systems? | Cars are marginalised, or cars maintain a dominant position |

## Types of uncertainty

Uncertainties relating to an identified issue come in different types. The lines between them are not fixed, and most strategic uncertainties are a little of each, but it helps to be aware of them.

- Conceptual uncertainties: two conceptually different future states, such as global versus regional, or access versus ownership.
- Unidirectional uncertainties: where we will be at a given point, from 'now' to an 'end state'; the uncertainty lies in the degree.
- Intensity or magnitude uncertainties: 'high/low' or 'fast/slow'; also unidirectional in nature.
- Tipping point uncertainties: events or paradigm shifts.

## Definitions of impact and uncertainty

- High impact: the issue will have a significant impact and fundamentally alter the business environment or the topic in scope. Low impact: the issue will not significantly alter it.
- Low uncertainty: you are reasonably certain about the future direction of the issue, with relative certainty of one of the two directions. High uncertainty: you are very uncertain about the future direction, closer to 50/50.
- Do not claim something is not uncertain just because you do not want it to happen.
- Where you assess relatively low uncertainty, mark the polarity you think most likely.

## What each quadrant calls for

- Critical uncertainties, high impact and high uncertainty: the focus of scenario analysis; discover the uncertainty related to the issue.
- High impact issues, high impact and low uncertainty: should be considered in all scenarios and require an immediate strategic response.
- Secondary issues, low impact: should rarely be in the analysis; park them for now but monitor their development.

## Polarities as bookends

The power of working with polarities is that they provide clear contrasts. Polarities should not be seen as endpoints but as 'bookends' that help explore the plausible space in between. Be careful with false or unclear dichotomies.

<!-- /canon/methods/visioning.md -->

---
type: Method
title: Visioning (preferred future)
description: Builds a shared, co-owned preferred future together with the challenges, enablers and actions that lead to it.
status: stable
use_when: "a team needs to agree on a shared preferred future and the challenges, enablers and actions that lead towards it"
depends_on:
  - /canon/methods/scenario-development.md
  - /canon/methods/futures-wheel.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Visioning (Preferred Future)"
  - id: root-un-global-pulse-vision-building
    resource: "UN Global Pulse (2023), Vision Building"
  - id: root-sibbet-vision-canvas
    resource: "Sibbet, D. (n.d.), 5 Bold Steps Vision Canvas"
---

# Visioning (preferred future)

Visioning as a foresight tool is a powerful participatory approach that empowers individuals and organisations to imagine a preferred future and commit to achieving it. It is a method for identifying, developing and enriching a compelling, preferred future, often as a step in creating a transformative strategy. This process emphasises the importance of collaboratively and deliberately envisioning the future, as it is often challenging to realise a future that we cannot clearly imagine. It helps move the conversation away from what we expect will happen, the conventional expectation of the future, towards making aspirational and transformational futures more tangible. In doing so, it deepens participants' understanding of their aspirations, fostering a sense of agency and a stronger commitment to shaping the desired outcome.

## How it works

- In foresight, visioning is sometimes referred to as 'incasting' because it involves exploring a particular preferred scenario in depth and mapping out the pathway to that preferred future. This contrasts with the visioning approach used in conventional strategic planning to focus on a 'vision statement'.
- A visioning exercise should build on preceding foresight work and can be a valuable next step after a futures wheel, scenario development or other exercises that help you think about alternative possibilities or change.
- Using visioning in conjunction with backcasting is especially helpful in exploring possible paths towards your preferred future, making it more actionable to get there.

## Use visioning to

- Align stakeholders on a shared vision of a preferred future.
- Outline actionable steps needed to reach a preferred future.
- Connect individual and collective aspirations, fostering a sense of agency and a stronger commitment to shaping desired outcomes.

## Key things to consider

- The purpose of visioning in foresight is always to create a shared vision co-owned by stakeholders. Elaborating and enriching a vision for a preferred future is one of the most effective mechanisms for engaging a team, organisation or community and getting them excited to push forward into new territory. Including diverse perspectives, experiences and values in the process also helps challenge dominant narratives and reduce the risk of perpetuating past problems.
- There are different approaches to visioning. Some are more analytical while others are more unconstrained and experimental. For all approaches, it is essential to include a set of visioning questions that can help inspire and guide participants' thinking and help them adopt the visioning mindset, as well as a canvas to help capture output in a structured way.
- The visioning canvas offers a useful framework for initially uncovering stakeholders' hopes and aspirations for a preferred future, serving as a foundation before defining what that future might look like. The process involves explicitly identifying challenges that may hinder progress, and enablers that can support reaching the desired future. Finally, it outlines concrete and attainable actions necessary to achieve this vision. Part of this exercise may even be to define audacious goals, to complement the articulation of the preferred future.
- As part of defining actionable steps to deliver the preferred future, a useful prompt is "Who or what will be the winners and losers in this change?" Answering this requires a collective understanding of the current reality you are looking to transition from, which should be part of any visioning exercise.

## Figure: visioning canvas

A canvas in two parts. In the upper part, a large half-circle in the centre labelled preferred future rests on a horizontal baseline, with five smaller circles arching over and around it, labelled aspiration 1 to 5, running left to right across the arc. In the lower part, three columns of blank ruled lines for capturing output are headed challenges (left), actions (centre, the widest column) and enablers (right).

<!-- /canon/methods/wind-tunnelling.md -->

---
type: Method
title: Wind-tunnelling
description: Tests strategic options against a set of scenarios to separate robust moves from contingent ones and big bets.
status: stable
use_when: "the person has strategic options or initiatives and needs to test them across scenarios to find no-regret moves, contingent options and big bets"
depends_on:
  - /canon/methods/scenario-development.md
  - /canon/methods/premortem.md
sources:
  - id: ref-toolkit-2026
    resource: "CIFS Toolkit for Applied Strategic Foresight, 2026 edition, section Wind-Tunnelling"
  - id: ref-asf-course-2026
    resource: "CIFS, Applied Strategic Foresight course deck, February 2026 edition, slides 117 to 128"
  - id: root-uk-futures-toolkit
    resource: "UK Government Office for Science (2024), The Futures Toolkit"
---

# Wind-tunnelling

Wind-tunnelling is an approach used to stress-test strategies or policies against a set of scenarios to evaluate how well they hold up under varying future conditions. It involves assessing the performance of different strategic options and objectives when facing given scenarios, considering the emerging issues and different future conditions that each scenario presents.

## How it works

- The exercise helps organisations understand which aspects of their strategy are resilient and which are vulnerable across different future contexts. It also helps identify specific aspects that may become important if a certain scenario begins to unfold.
- The outcome of a wind-tunnelling exercise is typically a matrix that assesses the effectiveness of strategic options and objectives across a range of scenarios.
- For each option, you assess whether it works and will have a positive impact, needs adaptation to be more effective, or whether it has no impact or may even lead to negative outcomes.

## Use wind-tunnelling to

- Explore how different future conditions might impact current strategies, identify the most resilient aspects, and become aware of weak spots.
- Evaluate strategic options and objectives against a range of plausible futures to see which perform well across them.
- Build a portfolio of options suited to different external conditions with the goal of balancing the need to define a clear strategy with the need to maintain a high level of strategic agility in uncertain conditions.

## Key things to consider

- Strategic actions or options that yield benefits in all or most scenarios are considered robust. These should be pursued as no-regret moves if resources allow. Actions that work disproportionately well in specific scenarios can serve as contingency plans to be adopted in suitable circumstances or modified to make them more robust across scenarios. Additionally, high-risk, high-reward 'big bets' could lead to significant breakthroughs or catastrophic failures depending on how the future unfolds. Taken together, these categories help you build a portfolio of actions that balances immediate needs with the potential need for quick pivots as the future unfolds.
- Wind-tunnelling can also be used the other way around. Rather than testing what you already have, you put existing strategies to one side and use each future as a resource for imagination. What solutions does this future point to? What different or altogether new strategies does it suggest?
- A variation of stress-testing worth trying is the pre-mortem. You start by establishing a strategy, priority or project, and then imagine it has failed in a given future. You then work backwards, speculating and debating the causes of that failure, to ultimately identify actions that would make the strategy more adaptive and resilient. Run the pre-mortem inside each scenario in turn, so the same strategy meets failure under different future conditions. The causes will differ from one scenario to the next, and comparing them shows not just whether a strategy is vulnerable but how it breaks in each world.
- The true value of wind-tunnelling comes from thinking through the consequences of an uncertain future and asking the question "What if this future happens?" Engaging a diverse set of stakeholders ensures a broader range of perspectives and helps identify strategic blind spots.

## Figure: wind-tunnelling matrix

A matrix with strategic options as rows and scenarios as columns. Each cell holds a dot indicating how the option performs in that scenario: a filled dot for positive impact in the specific scenario, a peach dot for needs adaptation in the specific scenario, and an open dot for negative impact or counter-productive in the specific scenario. In the example shown, option 1 is positive in scenarios A and B, needs adaptation in C and is negative in D; option 2 is positive in all four; option 3 is negative in A, B and C and positive in D.

For the assistant: draw this only in the reply after the person has said yes to your offer to draw it, never in the reply that explains. Show it as a small card, exactly as it is. Never mark, place or add their plan, their assumptions or anything else of theirs on it: placing it for them would make the theory behind the figure too reductive. Where they stand on it is theirs to work out, with you, in words; if they ask you to place it, say why you do not. Add a sentence or two on what to look at. Where HTML would arrive as code, describe it in words instead.

```html
<svg class="ffwnd" viewBox="0 0 560 310" style="display:block;width:100%;max-width:480px" role="img" aria-label="Wind-tunnelling matrix: three options tested against four scenarios, each cell positive, needing adaptation or negative">
<style>
.ffwnd text{font:12.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.5}
.ffwnd .b{font-weight:500;fill-opacity:.95}
.ffwnd .l{fill:none;stroke:#413C38;stroke-width:1.25;stroke-linecap:round;stroke-linejoin:round;stroke-opacity:.85}
.ffwnd .m{stroke-opacity:.5}
.ffwnd .f{stroke-opacity:.2}
.ffwnd .k{fill:#413C38}
.ffwnd .o{fill:#FFC7A5;stroke:#413C38;stroke-opacity:.5;stroke-width:.75}
.ffwnd text.ref{font:9.5px 'Kessel 105',Futura,'Century Gothic','Avenir Next',system-ui,sans-serif;fill:#413C38;fill-opacity:.55;font-weight:400}
</style>
<rect width="560" height="310" rx="14" fill="#fff"/>
<text x="262" y="54" text-anchor="middle">Scenario A</text>
<text x="340" y="54" text-anchor="middle">Scenario B</text>
<text x="418" y="54" text-anchor="middle">Scenario C</text>
<text x="496" y="54" text-anchor="middle">Scenario D</text>
<path class="l f" d="M40,75 H520 M40,125 H520 M40,175 H520 M40,225 H520"/>
<text x="40" y="104" class="b">Option 1</text>
<circle class="k" cx="262" cy="100" r="7"/>
<circle class="k" cx="340" cy="100" r="7"/>
<circle class="o" cx="418" cy="100" r="7"/>
<circle class="l m" cx="496" cy="100" r="7"/>
<text x="40" y="154" class="b">Option 2</text>
<circle class="k" cx="262" cy="150" r="7"/>
<circle class="k" cx="340" cy="150" r="7"/>
<circle class="k" cx="418" cy="150" r="7"/>
<circle class="k" cx="496" cy="150" r="7"/>
<text x="40" y="204" class="b">Option 3</text>
<circle class="l m" cx="262" cy="200" r="7"/>
<circle class="l m" cx="340" cy="200" r="7"/>
<circle class="l m" cx="418" cy="200" r="7"/>
<circle class="k" cx="496" cy="200" r="7"/>
<circle class="k" cx="46" cy="258" r="6"/>
<text x="58" y="262">Positive</text>
<circle class="o" cx="138" cy="258" r="6"/>
<text x="150" y="262">Needs adaptation</text>
<circle class="l m" cx="284" cy="258" r="6"/>
<text x="296" y="262">Negative or counter-productive</text>
<text class="ref" x="536" y="294" text-anchor="end">Wind-tunnelling matrix · Source: CIFS (2026), Toolkit for Applied Strategic Foresight.</text>
</svg>
```

## Scenario-tested and scenario-led strategy

- Most organisations already have a strategy and a portfolio of initiatives and responses. The strategy-forward approach evaluates current strategies, initiatives, products, services, projects and risk responses against the set of scenarios, to see whether they still provide a path to success. This is wind-tunnelling.
- The future-back approach puts existing strategies to one side and starts from the scenarios, using each future as a resource for imagination: what solutions does this future indicate, what different or altogether new strategies does it suggest? In practice the two approaches are often blended.

## Decisions for robustness

- No-regret moves largely deliver benefits across all scenarios, regardless of how the future unfolds. These are typically implemented immediately.
- Options are largely geared toward offering benefits in some, but not all, scenarios. They can be scaled up or down and adjusted as conditions evolve, enabling faster pivots from the current strategy to another that has been pre-developed.
- Big bets are bold, high-stakes decisions that rely on strong convictions about specific aspects of the future. They often require significant commitment and involve limited reversibility, so they should be selectively implemented, as they may stake the organisation's future.
- Strategic options are the courses of action an organisation can consider; strategic objectives are the specific goals it aims to achieve within a defined timeframe. Options can be deployed at any point of the value chain, not only in customer-facing products and services: optimising logistics networks, partnerships, joint ventures and acquisitions, procurement and sourcing, divesting or leaving markets, new revenue streams.

## Running it in a room

- Each group holds one scenario and has developed initiatives from within it. A 'host' stays with the group's initiatives to explain them and answer questions; the rest rotate around the room, visiting each of the other scenarios in turn.
- From your own scenario's perspective, assess whether each other group's initiatives would work and add value in your world. Mark green where the initiative is robust, yellow where it could work with modifications, red where it would not work, would be counter-productive or would destroy value.
- Debrief in the group and in plenary: do any initiatives prove robust across all scenarios? Did any seem particularly attractive, worth a bet? Could several be pursued at once, for the value of strategic options? Could elements of several be combined into one superior strategy?

## Exercise sheet: Would this idea survive a different future?

One of the kit's optional exercises: a one-page canvas with short instructions and space to work, for use with pen, paper and conversation, or alongside the assistant.

- Start with: up to three options or strategic initiatives and a set of plausible scenarios for the same time horizon. Agree the aim and time horizon, and test every option against the same scenarios.
- The canvas: a matrix with up to three options as rows and four scenarios as columns. Each cell holds an impact judgement and a short reason.
- At the end: an options-by-scenarios matrix showing what works, what needs adapting and what could fail.

On the sheet:

- Add a judgement and a reason in every cell: + works, ~ needs adaptation, 0 no impact, - negative impact, ? unclear.
- Read across the matrix: which options hold up across scenarios, and which depend on particular conditions? Keep disagreements and unknowns visible.
- Scenarios are plausible alternatives, not predictions. If you only have a single trend, develop contrasting future conditions before filling the matrix.

<!-- /canon/principles/broad-range-of-organisational-contexts.md -->

---
type: Principle
title: Strategic foresight can be applied to a broad range of organisational contexts
description: Foresight serves anticipation of opportunities and risks, innovation, future-proofing of strategies against plausible futures, and even thought leadership and visioning beyond the organisation.
status: stable
use_when: "someone asks what foresight is good for or whether it fits their purpose, from anticipating risks and innovation to stress-testing strategy or thought leadership"
sources:
  - id: ref-principles
    resource: CIFS' 10 Principles for Strategic Foresight
---

# Strategic foresight can be applied to a broad range of organisational contexts

## Contexts within the organisation

- Better strategic and policy anticipation, to identify and prepare sooner for future opportunities and risks.
- Business or policy innovation, to spur new thinking.
- Future-proofing, to identify gaps and stress-test existing or proposed strategies against a range of plausible futures.

## Contexts beyond the organisation

- Context can be extended beyond the organisation to inspire thought-leadership or visioning.

<!-- /canon/principles/challenge-mental-models.md -->

---
type: Principle
title: Strategic foresight seeks to challenge mental models and organisational perspectives
description: Foresight should counter the tendency to favour the business-as-usual future and refresh obsolete imagery of the future so that decisions are less clouded by bias and misguided assumptions.
status: stable
use_when: "a conversation defaults to the business-as-usual future or an outdated image of it, and the person needs a reason to question the assumptions behind it"
depends_on:
  - /canon/concepts/assumptions.md
  - /canon/concepts/cognitive-biases-in-futures-thinking.md
sources:
  - id: ref-principles
    resource: CIFS' 10 Principles for Strategic Foresight
---

# Strategic foresight seeks to challenge mental models and organisational perspectives

## What to challenge

- Our tendency to favour the 'business as usual' future.
- Our tendency not to adequately explore viable alternatives.

## What to refresh

- Old and obsolete imagery of the future, so often held onto by organisations.

## Why

- For the betterment of decisions that are more informed.
- For decisions less clouded by judgemental biases and misguided assumptions.

<!-- /canon/principles/explore-the-future-before-the-present.md -->

---
type: Principle
title: Strategic foresight explores the future before considering implications for the present
description: Foresight learns about the present through the lens of the future, in contrast to trying to understand the future from the perspective of the present.
status: stable
use_when: "the person wants to start from today's situation or plan, and needs to see why foresight first explores the future and then reads the present through it"
sources:
  - id: ref-principles
    resource: CIFS' 10 Principles for Strategic Foresight
---

# Strategic foresight explores the future before considering implications for the present

## The principle

- Strategic foresight focuses on exploring the future before considering implications for the present.

## The direction of learning

- We are trying to learn about the present through the lens of the future.
- This is in contrast to trying to understand the future from the perspective of the present.

<!-- /canon/principles/foresight-and-strategy-are-one-process.md -->

---
type: Principle
title: Foresight and strategy are complementary parts of one process
description: Without foresight, strategy goes blind to contextual change; without strategy, foresight becomes conjecture, so foresight outcomes should inspire strategic planning rather than replace it.
status: stable
use_when: "someone expects foresight to deliver a strategy, or plans strategy without foresight, and needs to see how the two connect"
sources:
  - id: ref-principles
    resource: CIFS' 10 Principles for Strategic Foresight
---

# Foresight and strategy are complementary parts of one process

## The principle

- Foresight and strategy are complementary parts of one process in pursuit of future organisational success.
- Foresight should always be connected to strategic purpose.

## Without foresight

- Strategy easily becomes blind to contextual change.
- Strategy becomes a recipe for failure when change occurs.

## Without strategy

- Foresight easily becomes conjecture.
- Foresight becomes disconnected from organisational reality.

## The relationship

- Foresight outcomes are not strategies in themselves.
- Foresight outcomes should inspire insights for strategic planning.

<!-- /canon/principles/foresight-as-collective-intelligence.md -->

---
type: Principle
title: Strategic foresight should be approached as a form of collective intelligence
description: Quality foresight outcomes can only be generated and assessed through dialogue between people bringing diverse, non-partisan perspectives, because the future cannot be studied passively.
status: stable
use_when: "the person plans to do foresight alone or with a like-minded group and needs to see why diverse perspectives and dialogue are essential"
sources:
  - id: ref-principles
    resource: CIFS' 10 Principles for Strategic Foresight
---

# Strategic foresight should be approached as a form of collective intelligence

## The principle

- Strategic foresight should be seen and approached as a form of collective intelligence.

## How quality outcomes arise

- Quality strategic foresight outcomes can only be generated and assessed through dialogue and exchanges between people.
- Those people bring diverse perspectives to the table, as non-partisan as possible.
- This is key to facilitating new, viable perspectives concerning future developments of relevance.

## What does not work

- It is not possible to passively 'study the future' and hope to learn much worthwhile.

<!-- /canon/principles/look-beyond-the-planning-horizon.md -->

---
type: Principle
title: Strategic foresight looks beyond the traditional strategic planning time horizon
description: Thinking within the three-to-five-year planning horizon limits mental flexibility and breeds path dependence, whereas thinking ten or more years out opens up alternatives significantly different from today.
status: stable
use_when: "the discussion is confined to the three-to-five-year planning horizon and the person needs a reason to look ten or more years out"
sources:
  - id: ref-principles
    resource: CIFS' 10 Principles for Strategic Foresight
---

# Strategic foresight looks beyond the traditional strategic planning time horizon

## The principle

- Strategic foresight most often deals with the medium to long-term future.

## The current planning horizon

- The current strategic planning time horizon is three to five years.
- Thinking within this horizon tends to limit 'mental flexibility'.
- It often leads to path-dependent thinking.

## Thinking further out

- Thinking ten or more years out better enables the exploration of viable future alternatives.
- These alternatives may be significantly different from today.

<!-- /canon/principles/plausible-futures-not-predictions.md -->

---
type: Principle
title: Strategic foresight explores plausible futures rather than making predictions
description: Because the future is inherently unpredictable and non-linear, foresight explores plausible futures informed by trajectories, emergent signals and critical uncertainties instead of seeking definitive answers.
status: stable
use_when: "someone asks what will happen or wants a forecast, and needs to understand why foresight explores plausible futures instead of predicting"
sources:
  - id: ref-principles
    resource: CIFS' 10 Principles for Strategic Foresight
---

# Strategic foresight explores plausible futures rather than making predictions

## The principle

- Strategic foresight is not about making predictions of the future, but rather exploring plausible futures.

## Why prediction fails

- The future is inherently unpredictable.
- Many factors may come together in complex ways to create surprising futures in a non-linear world.
- There are no definitive answers about what the future will hold.

## What informs plausible futures

- Trajectories and external sources of change.
- Emergent signals of change.
- Emerging critical uncertainties.

<!-- /canon/principles/practice-not-academic-exercise.md -->

---
type: Principle
title: Applying strategic foresight in practice is not an academic exercise
description: Successful foresight rests on robust academic underpinning but is pragmatic and hands-on, relying on rigorous methodologies together with sense-making, intuition, curiosity and creativity.
status: stable
use_when: "someone doubts foresight is rigorous, or fears it is too theoretical to use, and needs to see how method and practical judgement combine"
sources:
  - id: ref-principles
    resource: CIFS' 10 Principles for Strategic Foresight
---

# Applying strategic foresight in practice is not an academic exercise

## The academic foundation

- Foresight is a well-established field with a robust academic underpinning.
- It adopts principles of good scientific practice.

## The practice

- Successful strategic foresight is pragmatic and hands-on.

## What the practice relies on

- Rigorous and structured methodologies.
- The fine art of sense-making, intuition, curiosity and creativity.

<!-- /canon/principles/process-matters-as-much-as-outcomes.md -->

---
type: Principle
title: The strategic foresight process is at least as important as the final outcomes
description: The future is a tool rather than a destination, so the process itself should develop learning, broaden horizons and build shared understanding of potential outcomes.
status: stable
use_when: "the person judges foresight only by its outputs and needs to see the value of the process in learning and shared understanding"
sources:
  - id: ref-principles
    resource: CIFS' 10 Principles for Strategic Foresight
---

# The strategic foresight process is at least as important as the final outcomes

## The principle

- In strategic foresight, the future is not a destination; it is a tool.

## What the process should do

- Develop learning.
- Broaden participants' horizons.
- Help build a shared understanding of potential future outcomes.

## The hardest task

- The most difficult task when working with strategic foresight is to facilitate the transition of helping people think of the future in new ways.

<!-- /canon/principles/systems-thinking-for-resilient-futures.md -->

---
type: Principle
title: Strategic foresight is a systems-thinking approach to support resilient organisational futures
description: Foresight looks at potential changes in the external environment, including outcomes beyond the numbers and signals that would otherwise be disregarded, and lets these shape strategic decisions.
status: stable
use_when: "the person relies on forecasts and numbers alone and needs to see why external change, outcomes beyond the numbers and overlooked signals should shape decisions"
sources:
  - id: ref-principles
    resource: CIFS' 10 Principles for Strategic Foresight
---

# Strategic foresight is a systems-thinking approach to support resilient organisational futures

## The principle

- In a time where forecasts and projections are not enough, strategic foresight aims to achieve a genuinely high-quality view of potential future outcomes.
- Strategic foresight focuses on potential changes in an organisation's external environment.

## What this includes

- Outcomes 'beyond the numbers'.
- Potentially impactful signals that would otherwise be disregarded.

## Why it matters

- These changes influence the strategic environment.
- The strategic environment in turn shapes strategic decisions.
