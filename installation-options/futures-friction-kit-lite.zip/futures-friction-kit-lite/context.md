# context

What the world and the sector look like: interview claims, megatrends, signals, and the organisation's own material.

This file holds everything under /context/. A bundle path such as /context/<folder>/<name>.md is not a separate file: it is an entry below, headed by that exact path and listed by title in the index here. The path finds the entry; it is never cited.

## Index

### /context/megatrends

- [The biotech revolution](/context/megatrends/biotech-revolution.md): when a plan for health, science, food or climate coverage assumes those fields, their audiences and their controversies over access and ethics will stay as they are today.
- [Concentration of wealth](/context/megatrends/concentration-of-wealth.md): when a plan depends on platform owners, wealthy patrons or philanthropic funders, or assumes a broad middle-class audience able and willing to pay for news.
- [The constrained economy](/context/megatrends/constrained-economy.md): when a business case assumes advertising, subscription or public funding will grow with the economy, or that cheap capital and a steady supply of staff will carry it.
- [The green transition](/context/megatrends/green-transition.md): when a plan touches climate coverage, energy and infrastructure costs, or advertisers and audiences whose behaviour and regulation the move off fossil fuels will change.
- [Health beyond the clinic](/context/megatrends/health-beyond-the-clinic.md): when a plan for health, wellbeing or service journalism assumes audiences rely on clinicians, not on managing chronic conditions themselves with apps, wearables and AI.
- [Individualised everyday life](/context/megatrends/individualised-everyday-life.md): when a plan assumes a shared household audience, a mass front page or stable life-stage segments, while people live alone, defer family life and look for community.
- [Inversion of the population pyramid](/context/megatrends/inversion-of-the-population-pyramid.md): when a plan assumes today's age mix of audience, subscribers or staff will hold, or treats loyal older readers and missing young ones as a temporary imbalance.
- [The new face of urbanisation](/context/megatrends/new-face-of-urbanisation.md): when a plan for international, regional or local coverage, or for growth markets, assumes cities and their audiences will grow the way earlier urban waves did.
- [Power through networks](/context/megatrends/power-through-networks.md): when a plan depends on cloud, platform or AI infrastructure owned by a few foreign companies, or treats that dependency as a neutral technical choice.
- [The rise of embedded AI](/context/megatrends/rise-of-embedded-ai.md): when a plan treats AI as a tool to adopt, not as infrastructure that will mediate how audiences find information and how newsroom work and expertise are valued.
- [Shifting world order](/context/megatrends/shifting-world-order.md): when a plan for foreign coverage, international partnerships or technology suppliers assumes a stable rules-based order and settled alliances.

### /context/sector

- [AI adoption and literacy](/context/sector/ai-adoption-and-literacy.md): when a plan assumes staff already use AI widely and well, leaves adoption, training and shadow use unowned, or depends on how people read, question, feed and set up AI assistants.
- [AI systems and governance](/context/sector/ai-systems-and-governance.md): when a plan connects AI to internal data or archives, or builds a shared AI tool, and meets data protection, EU compliance, security review or staff fear of surveillance.
- [Culture and psychology](/context/sector/culture-and-psychology.md): when a change or experiment meets fear for jobs, a newsroom built for accuracy rather than error, or consensus-seeking that makes the safe choice the default.
- [Horizons, measurement and priorities](/context/sector/horizons-measurement-and-priorities.md): when long-horizon or radical work is judged on the same near-term KPIs and return as operations, or the question is how to measure and prioritise it.
- [Innovation process](/context/sector/innovation-process.md): when an idea or project lacks a route to decision, an owner or room to iterate, or the team is designing how ideas move from proposal to production.
- [Innovation structures](/context/sector/innovation-structures.md): when the organisation is choosing where innovation should sit, such as a lab, spin-off, cross-functional team or forum, or struggles to carry ideas into production.
- [Leadership and mandate](/context/sector/leadership-and-mandate.md): when long-horizon work needs leadership buy-in, a mandate or resources, or depends on a few individuals whose departure would take the capacity with them.
- [Organisational memory](/context/sector/organisational-memory.md): when a plan risks repeating earlier attempts, or the organisation wants to capture what it has learned in a shared knowledge base or 'organisation brain'.
- [Sector conditions](/context/sector/sector-conditions.md): when a plan rests on assumptions about distribution, legacy revenue, business models or audiences that the media sector's shifting conditions may no longer support.
- [Strategy, planning and practice](/context/sector/strategy-planning-and-practice.md): when strategy set at the top must reach operational levels, planning horizons are shrinking, or the team relies on strategy and sprint tools rather than futures practice.

### /context/signals

- [AI moves into the physical world](/context/signals/ai-moves-into-the-physical-world.md): when a plan for physical operations such as printing, distribution, events or studios assumes automation stays confined to fixed machinery away from people.
- [Attention splinters](/context/signals/attention-splinters.md): when a plan relies on a shared front page, mass reach or engagement metrics while audiences move into personalised AI feeds that know them but stay opaque to them.
- [Audiences move to creators](/context/signals/audiences-move-to-creators.md): when a plan to reach younger audiences assumes they will come to the brand's own channels and trust institutional objectivity rather than creators and personalities.
- [Convenience over accuracy](/context/signals/convenience-over-accuracy.md): when a plan or paywall rests on audiences valuing precise, verified news enough to choose or pay for it over approximately right AI answers.
- [The cyber security of AI-mediated infrastructures](/context/signals/cyber-security-of-ai-mediated-infrastructures.md): when a plan connects AI to archives, workflows, email or publishing systems, or treats AI security as an IT matter rather than a risk to trust and operations.
- [From static to liquid](/context/signals/from-static-to-liquid.md): when a plan invests in fixed articles, formats or interfaces that win the click, while answers are increasingly assembled in real time by AI systems.
- [The geopolitics of tech](/context/signals/geopolitics-of-tech.md): when a plan depends on foreign cloud, AI models or platforms and treats supplier choice as a cost question rather than a strategic dependency.
- [Machine audiences](/context/signals/machine-audiences.md): when a plan assumes the audience is human readers, while a growing share of traffic is AI agents that want structured data and clear context rather than narrative.
- [Machines as the primary audience](/context/signals/machines-as-the-primary-audience.md): when a plan assumes its journalism will be read by people on the newsroom's own pages, or that the article stays the unit of information and of value.
- [Neurotechnology and the cognitive dimensions of AI](/context/signals/neurotechnology-and-the-cognitive-dimensions-of-ai.md): when a plan hands research, editing or judgement to AI, or builds audience products that do the thinking for users, without asking which cognitive skills are lost.
- [Newsrooms start to explain their AI choices](/context/signals/newsrooms-start-to-explain-their-ai-choices.md): when a plan uses AI in the journalism without deciding whether and how to tell the public, or assumes that nobody explains their AI choices.
- [Platforms move from distribution to content](/context/signals/platforms-move-from-distribution-to-content.md): when a plan depends on platform or AI distribution, licensing deals or a direct relationship with users that the tech companies owning the AI entry points could take over.
- [Public scepticism of AI in news](/context/signals/public-scepticism-of-ai-in-news.md): when a plan assumes the audience will welcome AI in the journalism, will not notice it, or will credit a newsroom for not using it.
- [Quantum – the next era](/context/signals/quantum-the-next-era.md): when a long-range technology, security or data plan leaves out shifts in computing that could break encryption or change what can be modelled, and no one owns watching them.
- [The reshuffling of ecosystems](/context/signals/reshuffling-of-ecosystems.md): when a plan defends the product or content the organisation makes while value moves to whoever interprets intent, coordinates data and owns the trusted layer.
- [The rise of agentic organisations](/context/signals/rise-of-agentic-organisations.md): when a plan brings AI agents into editorial or business workflows without settling who decides, who is accountable and where human judgement stays.
- [Simulations on the rise](/context/signals/simulations-on-the-rise.md): when a plan or decision could be rehearsed before launch, for instance by testing audience or advertiser responses with simulations, synthetic data or digital twins.
- [Sustainability challenges of AI infrastructure](/context/signals/sustainability-challenges-of-ai-infrastructure.md): when a plan scales AI use, compute or data infrastructure without weighing its energy, water and climate costs or how audiences and regulators will judge them.
- [The great information repricing](/context/signals/the-great-information-repricing.md): when a business model counts on selling general news awareness, while value moves to intelligence that reduces uncertainty for decisions and to grant-funded civic journalism.
- [The knowledge freezer](/context/signals/the-knowledge-freezer.md): when a plan assumes AI companies can keep drawing on journalism while newsrooms shrink, or weighs licensing content to AI without asking what happens when fewer stories are made.
- [The zero-click era](/context/signals/the-zero-click-era.md): when a plan relies on search or social referrals still delivering audience when it pays off, rather than on a direct relationship with users who choose to come.


<!-- /context/megatrends/biotech-revolution.md -->

---
type: Megatrend
title: The biotech revolution
description: Biotechnology is being integrated into food, energy, materials and medicine, letting societies redesign living systems while raising contested questions of access and ethics.
status: stable
use_when: "a plan for health, science, food or climate coverage assumes those fields, their audiences and their controversies over access and ethics will stay as they are today"
sources:
  - id: ref-megatrends
    resource: "CIFS (2026), Megatrends: The foundations of long-term change, chapter The Biotech Revolution"
---

# The biotech revolution

## What it is

Biotechnology, the use of living organisms to make products and raw materials, is set to revolutionise the world over the next half-century. It enables us to transcend natural limitations, understand and manipulate genetic codes of plants and animals, create modified crops that are more resilient or require less fertiliser, develop new treatments for hereditary illnesses, and increase life expectancy, perhaps drastically. Over the course of this century, biotechnology will be integrated deeper into nearly all facets of modern society, including healthcare, food production, material design and energy production.

Every day when we open our fridge, we see the products of biotechnologies: bread made from selectively bred wheat, fruit juice with enzymes, or meat and dairy from animals raised on genetically modified feeds. Biotechnology is so central to the modern world that many of us would not be alive without it. High-yielding crop varieties increased yields by 44% between 1965 and 2010, reducing famine and helping sustain the rapidly growing populations of the late 20th century.

## Sub-trends

- Genomics becoming the operating system of life's essentials, medicine and food production
- Bioenergy leading to more sustainable heat and fuels
- Rise of biological carbon sequestration
- Emergence of bio-based materials
- Bio-enhanced food production
- AI-enhancement of biotech innovation

## Uncertainties

- Will ecological engineering be applied on a wide enough scale to counteract the effects of climate change?
- What regulatory frameworks will shape the rollout of emerging biotechnologies?
- Can cultivated (lab-grown) foods move from niche innovation to mainstream acceptance?
- How successfully will synthetic biology deliver on its promise of designing organisms fit for a changed world?
- What role will ethics play in an accelerated biotech revolution, if any?

## Drivers

- Food production continues to be one of biotechnology's most important frontiers, not only in total yield but increasingly in what ends up on a plate. Six billion people regularly consume milk or dairy products, and the land and water use demanded by conventional livestock, along with the emissions it produces, is a major driver of climate change and environmental degradation.
- Direct emissions from livestock production are a major source of greenhouse gases, making improvements in animal agriculture an important climate strategy.
- In shipping and air traffic, electrification is not a viable option, leaving a gap that advanced biofuels (fuels made from non-food biological material) are poised to fill. Past generations of biofuel production competed with food production for agricultural land; during the 2010-11 global food crisis, rising food prices, with land use for first-generation biofuels as a contributing factor, caused riots in Egypt that eventually contributed to the toppling of President Mubarak.
- The convergence of biotech with artificial intelligence may accelerate progress even further. AlphaFold, Google DeepMind's protein-structure prediction system, solved a problem in months that had occupied structural biologists for half a century, earning its creators the Nobel Prize in Chemistry in 2024. Drug discovery pipelines that once took vast infrastructure and decades are being compressed into years, computationally, by smaller teams at a fraction of the cost.
- Money is flowing into longevity research, with patrons like Amazon's Jeff Bezos and Saudi Arabia's Crown Prince turning their attention this way. Saudi Arabia's Hevolution Foundation has bankrolled USD 40 million of a USD 101 million XPrize competition for the first team to demonstrably reverse aspects of ageing by ten years.

## Manifestations

- Cultivated meat grabs the most headlines, but an arguably more significant prospect is precision fermentation in dairy production. CIFS research estimates that, based on the technology price curve, milk protein from precision fermentation might reach parity with milk from cows in 10-15 years and from then on start disrupting milk production.
- Research into the relationship between the rumen microbiome, feed composition and cattle genetics may help lower methane emissions significantly while maintaining productivity. Crops like wheat can be genetically modified to sequester more CO2 underground while increasing food productivity, though these techniques are at a very early stage. Grass-to-protein production could reduce the structural dependence on imported soy that ties American and Asian food systems to land-use decisions in South America; the feedstock is abundant, the land already in use, and the supply chain implications of even modest substitution are significant.
- Advanced contemporary biofuels largely avoid the land-use dilemma, using feedstocks that do not require agricultural land. The EU's RefuelEU Aviation Regulation (adopted in 2023) mandates 20% sustainable aviation fuel in 2035 and 70% in 2050, most of it from advanced biofuels.
- In January 2026, the US Food and Drug Administration approved a human clinical trial by Life Biosciences, co-founded by Harvard geneticist David Sinclair, testing a gene therapy targeting vision loss in patients with glaucoma and rare optic nerve conditions. The overarching ambition is the possibility of reversing ageing itself. Longevity research is often at odds with mainstream medical science, but the money flowing into the field makes it difficult to disregard.
- For the 200 million people worldwide dependent on insulin, manufactured using recombinant DNA techniques, the life-sustaining necessity of biotechnology is self-evident. Within a few years of the COVID-19 viral genome being published, mRNA vaccines were manufactured and administered to billions of people worldwide, perhaps the fastest and largest deployment of a biotechnology product in history. Christopher Voigt of MIT assesses that by 2030, most people in the developed world will have consumed, worn, used, or received medical treatment from products that involved synthetic biology somewhere in their production chain.
- Neglected diseases, including several tropical diseases affecting hundreds of millions of people, are a prime target for AI-powered drug discovery, which can accelerate the identification of drug candidates and cut the time and cost of bringing new treatments to market.

## Implications

- Longevity research is hugely contested, not just for scientific reasons but for the ethical questions it raises. The most significant is who gets access to treatment. If treatment to extend life significantly becomes mainstream or universally accessible, what happens to pension systems, housing markets and inheritance? Globally, its impacts on population growth and the Earth's already strained resources will have to be considered. Scepticism is warranted, but as with Artificial General Intelligence, considered science fiction two decades ago, longevity research may prove to be one of those rare fields where the science outpaces what human imagination thought possible.
- The use of biotechnology has been riddled with controversy, particularly surrounding GMO and human cloning. There is no single worldwide treaty that legally prohibits human reproductive cloning; the closest is the UN Declaration on Human Cloning (2005). A powerful taboo around cloning has nevertheless helped prevent an international biological arms race during a period when the technology remained unsafe and its benefits uncertain. The real test of that taboo will come if human enhancement becomes demonstrably safe and effective.
- The controversies will not disappear and will continue to shape the direction, speed of rollout and impact of biotech. Concerns and risks include ecosystem impacts, monopolisation issues (such as seeds preventing farmers from saving and replanting their own seed stock), and public trust issues, particularly regarding health. The very plausibility of the claim that COVID-19 was engineered in a laboratory and escaped, whatever its truth, shows the potentially very negative consequences that biotechnology could have.
- Despite risks and controversies, biotech will enable the redesign of biological systems for better health, more resistant food, sustainable fuels and new materials. The challenges of this century will not be solved by any single discipline, but it is hard to construct a credible path through them that does not, at some point, run through biotechnology.

<!-- /context/megatrends/concentration-of-wealth.md -->

---
type: Megatrend
title: Concentration of wealth
description: Wealth is concentrating at the top at a pace with no post-war equivalent and hardening through inheritance, converting into political influence that hollows out democratic capacity.
status: stable
use_when: "a plan depends on platform owners, wealthy patrons or philanthropic funders, or assumes a broad middle-class audience able and willing to pay for news"
depends_on:
  - /context/megatrends/rise-of-embedded-ai.md
sources:
  - id: ref-megatrends
    resource: "CIFS (2026), Megatrends: The foundations of long-term change, chapter Concentration of Wealth"
---

# Concentration of wealth

## What it is

The gains of economic growth have never been distributed evenly across the globe, not between countries, not within them, and not between those who own capital and those who sell labour. But the present configuration of global wealth accumulation constitutes something historically distinct, not least in its extremity. As the world gets progressively richer, more productive and more populous, the benefits of this sustained growth are far from shared equally. Growing wealth inequality presents future challenges to state capacity, the ability to meet existential challenges, and perhaps even to the future of democracy itself.

## Sub-trends

- The 'oligarchising' of politics
- Ownership of platforms, democracy's news and information 'infrastructure', in the hands of the super-wealthy
- Accounting and tax rules lagging new models of wealth and value creation
- Declining labour share of income
- Intergenerational wealth transfer and the concentration of inheritance
- Asset-based stratification

## Uncertainties

- Can governments act on wealth redistribution before inherited wealth concentrations become too entrenched to reverse?
- Can democracies effectively counteract 'oligarchising' when wealth easily evades national jurisdictions?
- How will wealth concentration among platform owners evolve under potential regulatory pressure?
- Can global collaboration on taxation and financial market controls become a stronger counterweight to inequality?
- Can redistributive instruments such as a universal basic income compensate for a falling labour share of income, and can a national tax base in the exposed country fund them when the productivity gains accrue elsewhere, i.e. Chennai vs. California?

## Drivers

- Some causes of this extreme divergence have been decades in the making: the deregulation of capital markets, capital accumulation outpacing economic growth, and the gradual weakening of workers' bargaining power relative to capital across much of the world.
- Other structural drivers are newer. Platform monopolies generate returns at near-zero marginal cost, enabling rapid wealth accumulation. The list of top wealth holders today has an overrepresentation of technology platform owners whose fortunes were built on this mechanism.
- Platform-based business models have opened a gap between where economic value is created and where it can be measured, taxed and redistributed. Through the 2010s, some of the world's most valuable companies generated extraordinary returns with comparatively little physical capital, their value sitting in intangible assets, networks and globally scalable digital infrastructure. That may now be changing, as the same firms spent several hundred billion dollars in 2026 on data centres, chips and power, tying their value back to places, grids and permits.
- Accounting, financial and especially taxation systems remain poorly adapted to both versions of the model. The OECD mechanism for shifting taxing rights to the countries where users are, Amount A of Pillar One, has still not come into force, and more than twenty national digital services taxes have filled the gap. Much of the wealth of the very rich is held in appreciating shares, which generally generate tax revenues only when sold, giving owners little incentive to realise gains.
- Recent international tax negotiations suggest the principal barriers are political rather than technical: many of the necessary mechanisms exist, but access to them is shaped by the relative bargaining power of states and corporations. The clearest example is the January 2026 'side by side' agreement, which largely exempts US multinational companies from the OECD's global minimum tax rules.
- A new and perhaps more durable dynamic is the transmission of accumulated wealth between generations on a scale unprecedented in recent history. Market-generated concentration is, in principle, reversible through labour market dynamics, taxation or shifts in competitive conditions. Generational wealth does not depend on the continued performance of the inheritor and is protected by trusts, foundations or offshore vehicles designed to minimise erosion through taxation or market risk. The generations set to inherit the so-called Great Wealth Transfer, primarily Generation X and Millennials, are the first to do so after four decades of intensified accumulation at the top.
- AI is a 'capital-biased' innovation whose returns flow disproportionately to capital rather than labour. This winner-takes-most dynamic echoes past industrial revolutions, from textile mills to industrial robots, which concentrated ownership of capital-intensive machinery while lowering skill requirements and creating an oversupply of replaceable workers.

## Manifestations

- Between 2000 and 2024, the richest 1% of the world population captured 41% of all new wealth, while the bottom half received just 1%. The top 10% own three-quarters of global wealth, while the bottom half holds only 2%. The top 1% alone, roughly the adult population of the United Kingdom, controls 37% of global wealth. Fewer than 6,000 individuals hold 3% of all wealth, more than the entire bottom half of the world's adult population.
- Corporate tax revenues have broadly held up, so the central dispute is not only how much tax is collected but which country has the right to collect it. The taxation of concentrated corporate and platform wealth is becoming less a question of institutional design than a contest over who has sufficient leverage to determine, and benefit from, the rules.
- The conversion of concentrated wealth into political influence, the 'oligarchising' of politics, ranges from buying political support to consolidating ownership of key societal institutions and infrastructure. A study covering 120 countries over 23 years found a negative effect of economic concentration on a nation's level of democracy, with corporate political activity as a likely mechanism. Pressures include the funding of foundations, think tanks and policy-planning networks; campaign finance; the shaping of public opinion through media and expert commentary; and constitutional provisions that protect property and create veto points at which change can be blocked.
- Increasing wealth inequality has been associated with a reduction in the proportion of individuals identifying with the subjective middle class, the group most supportive of democratic governance.
- 2026 marked the first year when social media and video networks were the most widely used source of news globally (54% of all audiences). Legacy media must lean on corporate scaling or partner with massive tech ecosystems to maintain reach. Social media networks and algorithmic search engines, voting-controlled in several cases by a single individual, act as primary news and information gatekeepers worldwide. Algorithmic ranking by predicted engagement creates new risks, accentuated by the fact that dissemination precedes fact-checking.
- The rise of 'mega-philanthropy', itself a product of wealth concentration, shows that where public capacity recedes (or was never present), what replaces it is defined by those who own the capital. That replacement is largely unaccountable, and its priorities follow donor preference rather than public consensus.

## Implications

- Wealth polarisation does not in itself produce risks to state capacity, democratic stability and governance. But the uneven playing field it creates contributes to hollowing out the democratic process and makes policies and outcomes that systematically favour the interests of the wealthy more likely.
- The qualitative shift in the social logic of wealth towards inheritance may further widen the gap between economic position and social contribution, something close to the emergence of a new aristocracy.
- When the greatest fortunes sat in oil, retail or property, the asset and the political voice it afforded were separable. When the asset is society's information, news and communications infrastructure, the asset and the megaphone are the same object.
- As AI graduates from tool to embedded infrastructure, one potential outcome, even with productivity growth, is that absent political intervention it contributes to widening inequalities. Past industrial revolutions were followed by counterbalances: organised labour movements, government regulations, the expansion of the welfare state. What the redistributive institutions of the future will look like is an open question. Universal basic income is one proposition, yet it is unclear how it would be financed: the productivity gains of platform and AI infrastructure accrue to owners concentrated in a small number of jurisdictions, while the labour markets those technologies reshape are global. A parliament in Delhi cannot legislate a tax rate in California. Proposals for a coordinated minimum tax on the very wealthy, and the ongoing negotiation of a UN framework convention on international tax cooperation, are attempts to close exactly this gap.
- For non-inheriting majorities, wealth-based stratification means labour market participation may be increasingly insufficient to generate the asset accumulation necessary for retirement security and housing access. Capital returns concentrate in metropolitan areas where asset prices are highest, producing 'geographies of discontent' and a risk of political backlash.
- Wealth concentration drives other risks through the social polarisation it foments. Democratic systems eroding through elite capture face another angle of attack from the political mobilisation of those who believe they are not seeing their fair share of growth. The rise of populism in the 2010s and 2020s is also a story of the inequalities produced by a globalised and stratified economy. Some of the most significant upheavals in modern history, pre-revolutionary France, tsarist Russia, Weimar Germany, were preceded by periods of intense inequality.
- The risks are heightened by the lock-in of structural constraints that make course-correction increasingly difficult. Where governments depend on private capital to finance public functions, through debt, de-risking and public-private partnerships, the range of democratic choice narrows, constrained by the preferences of the private wealth on which fiscal states depend. Rebuilding redistributive institutions requires coalitions that wealth concentration makes harder to assemble. This could create legitimacy problems for a social contract resting on the premise that effort, skill and participation generate a proportional meritocratic reward.
- The unprecedented concentration of wealth has not been matched by any comparable growth in the capacity to solve shared problems, whether stemming climate change or eradicating hunger. The question for the coming decades is whether fiscal, regulatory and democratic capacity can be rebuilt at the scale at which capital now operates. How it is answered will determine whether the concentration of wealth remains an economic outcome or hardens into a structural feature of how societies are governed.

<!-- /context/megatrends/constrained-economy.md -->

---
type: Megatrend
title: The constrained economy
description: The global economy is shifting from the expansionary post-Cold War configuration to one bounded by debt, shrinking labour supply, fragmented trade and scarce resources.
status: stable
use_when: "a business case assumes advertising, subscription or public funding will grow with the economy, or that cheap capital and a steady supply of staff will carry it"
sources:
  - id: ref-megatrends
    resource: "CIFS (2026), Megatrends: The foundations of long-term change, chapter The Constrained Economy"
---

# The constrained economy

## What it is

The global economy is undergoing a structural shift from the expansionary configuration of the post-Cold War era to a more constrained one. Many of the enabling conditions that drove growth, integration and convergence for three decades have either exhausted themselves or gone into reverse. Lower growth is one consequence of this shift, but the deeper change is the constraints and conditions under which states, companies and individuals now pursue economic activity.

The story of the global economy in the late 20th and early 21st century has been one of convergence and expansion: rising international trade, aided by deeper multilateral engagement and developing nations opening to trade, and the emergence of a truly global economic system following China's opening (late 1970s) and the USSR's collapse (1991), alongside the proliferation of bilateral trade and FDI deals. Underpinning this was a unique set of monetary conditions, dollar hegemony and cheap capital, combined with falling marginal tax rates, privatisation and deregulation. Industrial policy was treated as a controversial, even taboo, topic. The global economy is now entering a new phase defined less by the structures that enabled its expansion and more by those that constrain it.

## Sub-trends

- Rising fiscal and private financial stress
- Constrained global growth
- Fading demographic tailwinds leading to shrinking labour supply
- Geopolitical uncertainty
- Rise in trade and supply chain disruptions
- Growing resource constraints

## Uncertainties

- Will rising public debt and underfunded pension systems constrain fiscal space and slow long-term growth, particularly in ageing economies and highly indebted countries?
- How will geopolitical tensions and shifting trade and industrial policies reshape global trade, investment flows and the resilience of the global economy to external shocks?
- How large will the economic costs of climate mitigation and adaptation be?
- Will financial innovation outside the regulated banking system strengthen economic dynamism or create new systemic risks and financial instability?
- To what extent will the expansion of AI lead to productivity increases, and where in the economy?
- Can ageing economies reconcile their need for migrants and talent with rising nationalist and anti-immigration politics?

## Drivers

- Many of the conditions that made the post-1990 growth era possible are exhausted. As the demographic tailwinds of the 20th century fade in many regions, labour supply growth is reduced. In the OECD's long-run scenarios, global annual potential output growth is projected to moderate from around 2.9% today to 2.7% in the early 2030s and 2.1% in the early 2040s, reflecting declining working-age population growth and a slowing trend in labour productivity growth in emerging market economies.
- Investment has weakened, feeding directly into slower productivity growth and lower output growth. Trade has lost momentum as policy uncertainty rises and fragmentation increases trade costs.
- Debt is a further constraint. High levels of debt have translated into high debt service burdens. Over the last decade, an increasing number of low-income economies spend more on servicing public debt than on health, education and public investment. Higher interest rates amplify this pressure by raising refinancing costs and narrowing fiscal space for infrastructure, education and industrial policy.
- The distribution of gains from growth remains highly uneven. The key dynamic in the past couple of years has been an increase in the share of wealth of the 0.01% richest people globally. Such concentration shapes consumption patterns, investment allocation and political stability, even when headline GDP growth remains positive.
- Geopolitical conflict and war have become a more visible economic constraint. Beyond the human cost, conflict increases risk premia, disrupts supply chains, raises energy and food price volatility and accelerates strategic decoupling. With tensions at their highest since the end of the Cold War, the resulting uncertainty depresses investment and trade and can lock economies into lower growth paths. Rising defence spending draws resources away from budgets without the same long-term productive return as other public investment.
- The structure and complexity of global finance is evolving. The US dollar remains the dominant reserve currency, but official central bank reserves have slowly diversified toward non-traditional reserve currencies such as Australian dollars. Shifts in reserve composition influence liquidity conditions, capital flows and the resilience of the international monetary system in periods of stress.
- Resource constraints are more pressing. Money cannot simply buy access to what is scarce or politically restricted. Inputs such as lithium, cobalt, nickel, copper and graphite are becoming strategically important for electrification and advanced manufacturing, with rising demand and growing supply chain concentration risks. If access becomes a binding constraint, it can reshape industrial competitiveness and slow the transition investments that many growth strategies rely on.

## Manifestations

- Lower growth rates are the most visible symptom of the structural shift, but they are a consequence rather than the story itself. Global growth slowed from an average of 3.6% per year in the decade before the Global Financial Crisis (1998-2008) to 3.2% in the decade before the Covid pandemic (2010-2020). Restoring growth to earlier decade averages will require a very large collective policy effort, including stronger cooperation, larger financing and mobilising private capital.
- In the long term, weak growth may be offset by AI, primarily through productivity gains. The IMF describes AI as a potential force that could jumpstart productivity, boost global growth and raise incomes, while warning that benefits may be uneven and could deepen inequality without policy responses. Goldman Sachs Research estimates that generative AI could raise global GDP by 7% over ten years and lift productivity growth by 1.5 percentage points per year, conditional on adoption and task exposure. The OECD frames AI as a general-purpose technology with the potential to influence productivity, distribution and growth, while emphasising uncertainty around macro outcomes and diffusion beyond leading firms.
- Regardless of whether AI eventually offsets weaker growth rates, the underlying structural reconfiguration of labour, capital, trade, debt and resource conditions is more persistent. An economy that grows at 3% through AI-driven productivity gains while operating under demographic constraint, fragmented trade and resource scarcity is structurally different from one that grew at 3.6% through demographic expansion, open trade and cheap energy. Growth rates can recover while the structure underneath them, debt capacity, labour supply, trade openness and input access, remains permanently more constrained.

## Implications

- Nations and companies will increasingly pay a premium for security in the form of redundant supply chains, strategic reserves, domestic capacity and trusted partners. What once looked inefficient may now become economically rational.
- Governments will face harder choices on defence, climate, welfare, pensions and more, in an environment where the economic pie expands more slowly and prioritisation matters more.
- With shrinking domestic labour forces, productivity becomes even more important. AI, automation and organisational innovation become strategic imperatives, while people face growing pressure to continuously adapt their skills.
- A smaller workforce will be asked to finance larger ageing populations, forcing difficult choices on pensions, healthcare and taxation. For younger people, the implicit promise that each generation will become wealthier than the last could become harder to sustain.
- Heightened competition for migrants and talent may be expected globally. Individuals with scarce skills gain bargaining power, while others face greater pressure to reskill.
- Uncertainties abound. Redundant supply chains, strategic reserves and trusted-partner sourcing come at a cost that becomes difficult to sustain amid the rising fiscal and financial stress driving the trend in the first place; resilience may become one of the first casualties when governments and firms are forced to economise. Whether competition for migrants and talent materialises as open competition, or whether nationalist and anti-immigration politics in ageing economies foreclose migration as a lever, is a crucial question. And even in an optimistic scenario, it remains open whether AI-driven productivity growth arrives quickly and broadly enough to ease the financing burden on ageing populations, or stays concentrated in leading firms and high-skill workers, doing little to relieve the distributive strain.

<!-- /context/megatrends/green-transition.md -->

---
type: Megatrend
title: The green transition
description: Climate change, ecological degradation and cheaper renewables are forcing the economy off fossil fuels and resource-intensive production, unevenly and not yet fast enough.
status: stable
use_when: "a plan touches climate coverage, energy and infrastructure costs, or advertisers and audiences whose behaviour and regulation the move off fossil fuels will change"
sources:
  - id: ref-megatrends
    resource: "CIFS (2026), Megatrends: The foundations of long-term change, chapter The Green Transition"
---

# The green transition

## What it is

Climate change, ecological degradation and breached planetary boundaries are forcing a shift away from the fossil-fuel-based, resource-intensive economy of the 20th century. That shift is increasingly reinforced by economics, as renewables are quickly becoming the cheaper option in many markets. The Green Transition encompasses both the shift to renewable energy and efforts to halt the environmental degradation driven by resource-intensive production.

This transition is underway, but it proceeds unevenly, both in terms of geographies and efforts. Renewable energy capacity is expanding, and CO2 emissions are measurably lower than they would otherwise be, while progress on protecting natural habitats and reducing material consumption lags further behind. Political backlash against sustainability agendas in several major economies creates noise and distracts attention, but it has not reversed the trajectory of the megatrend. The visible pressures continue to build, but these dynamics alone are no guarantee that the transition will happen fast enough to avert severely disruptive climate risks.

Unlike most megatrends, which concern human actions in the social system, the Green Transition occurs in a complex physical system with feedback loops and system thresholds that can produce sudden reversals in indicators. Human action can improve a wide range of parameters, such as the net forest area, but physical mechanisms such as the die-off in the Amazon could still be triggered, fundamentally disrupting the indicator being improved.

## Sub-trends

- Energy transition from fossil fuels to renewables
- Circular economy and sustainable resource use
- Electrification
- Increase in policies to prevent environmental degradation
- Increase in nature-related financial disclosures
- Growing climate mitigation and regulation efforts
- New regions and countries stepping up in climate leadership

## Uncertainties

- What will be the duration and impact of the current backlash against renewables?
- Will new energy storage technologies achieve major gains in efficiency and propel the pace of electrification and renewable energy use?
- What would it take for consumer awareness to translate into a widespread shift in consumer choices?
- Will Earth system tipping points be reached, resulting in runaway climate calamities, before the transition can prevent them?
- Will the restoration of natural habitats keep in step with the energy transition, or will biodiversity loss continue to worsen?
- Will the world unite around climate action, or will efforts be regionalised?

## Drivers

- For most of the past century, economic growth came at a measurable cost to the natural world. Livestock now outweigh wild mammals and birds tenfold, air pollution accounts for approximately seven million premature deaths each year, and climate change proceeds at a pace that inches closer to dangerous tipping points in the planet's climate systems.
- As climate change accelerates, the physical impacts in the form of severe weather events and ecosystem collapse place increasing adaptation demands on societies. The need for robust, science-based tools to anticipate risk, manage uncertainty and design resilient systems will grow over the long term, regardless of short-term political cycles. The transition is not only an environmental necessity but increasingly an economic and strategic one.
- Economics reinforce the shift. Global clean energy investment stands at USD 1.8 trillion annually, against USD 1 trillion in fossil fuels. Solar paired with 4-hour battery storage is now cheaper than new coal generation in major markets.
- China's scale and policy direction make it a deciding factor in the global outcome. China leads the world in installed capacity of both solar and wind power and accounts for a substantial share of new additions each year. Massive investments in utility-scale solar farms and offshore wind have driven down costs globally through economies of scale and manufacturing dominance, and grid modernisation, including ultra-high-voltage transmission lines, enables renewable energy generated in remote regions to reach dense urban centres.
- The evolving climate risk landscape pushes in the direction of a transition. As carbon is increasingly priced into major markets and institutional investors are required to account for climate risk, the economics are shifting in ways that reach beyond the energy sector. Decisions once made purely on cost and convenience now increasingly involve assessing climate risk and meeting new and stronger regulations.
- International environmental governance is expanding. The High Seas Treaty in 2025 marks a significant step toward protecting marine ecosystems in international waters. The UN Convention to Combat Desertification has gained renewed momentum, with parties pledging to restore one billion hectares of degraded land by 2030. Trade in endangered species is being restricted.

## Manifestations

- The overall picture is one of mixed signals. The global deforestation rate is slowing (from 17.6 million hectares per year in 1990-2000 to 10.9 million in 2015-2025). The average proportion of key biodiversity areas under protection has increased from roughly 25% in 2000 to about 45% in 2025. The share of renewables in the global energy mix is growing steadily. Yet the Red List Index, an indicator of overall extinction risk, has been continuously worsening for decades, and seven of Earth's nine planetary boundaries are now breached.
- The energy transition is the part of the megatrend furthest along. Across major economies there has been a decoupling of GDP growth and CO2 emissions. Renewables account for a relatively small share of primary energy consumption, but that figure conceals the higher efficiency of electricity: around 40% less renewable energy than fossil fuel energy is needed to perform the same task, so the actual substitution share of renewables is higher and rising quickly.
- Electrification of transport is a critical trend. The electric vehicle share of global car sales stands at 25% in 2026 and is rising quickly. In Norway, EVs' share of new passenger vehicle sales reached 96% in 2025.
- The transition is not fast enough. National emissions plans are expected to cut emissions by 12% in the next 10 years, which is not sufficient to curb accelerating climate change. The Paris Agreement aimed to limit warming to well below 2°C with efforts to cap it at 1.5°C, yet the world is on track for 2.6°C. The planet is already 1.41°C warmer than pre-industrial levels, and the Copernicus Climate Change Service projects a breach of 1.5°C as early as May 2029 rather than March 2042.
- Restoration and protection of natural habitats lag behind the energy transition for several reasons. Nature preservation efforts do not scale in the same way renewable energy does. Institutional frameworks are at an earlier stage than climate mitigation. Protecting natural environments often means not doing something, or forgoing short-term economic gain, which is harder to incentivise. And since industrialised agriculture and food production are the leading cause of both deforestation and biodiversity loss, addressing root causes means reforming the very systems that sustain a growing global population and on which the livelihoods of billions depend.
- Businesses face regulatory pressure in the form of carbon pricing mechanisms and supply chain due diligence laws. Companies that once treated sustainability as a voluntary commitment now navigate it as a compliance obligation, and the pace of regulatory change is itself a challenge. The EU's Right to Repair Directive (adopted 2024, applicable from 2026) and the Ecodesign Regulation for Sustainable Products (2024) aim to combat planned obsolescence.
- Consumer uptake is slow. Surveys consistently show that large majorities consider climate change a serious threat, yet this concern rarely translates into proportionate changes in behaviour. Most people still fly, consume and buy as many products as they can afford, motivated by convenience and comfort more than ethical considerations. This gap between values and behaviour is one of the defining tensions of the Green Transition. The consumer society is also a product of deliberate psychological and cultural pressures, as industries engineered products and marketing to exploit reward circuits while eroding the expectation of quality.
- Public resistance accompanies change on this scale. The costs of the transition are sometimes immediately felt as higher fuel prices, restricted choices or disrupted livelihoods, while the benefits feel distant or abstract, so political backlash often follows. Farmers block highways, yellow vests flood the streets, lobbyists roll up their sleeves, and governments that moved ambitiously on climate policy walk back commitments under electoral pressure.

## Implications

- Humanity's shift away from a resource-intensive economy is an accelerating trend, unlikely to be reversed by short-term political backlash, but it does not guarantee arrival at a stable end state. The transition is to a future in which we will likely be forced to mitigate, and adapt to, climate change and environmental degradation simultaneously.
- The climate is approaching a high risk of Earth system tipping points such as the polar ice sheets melting, permafrost thawing and warm-water coral reefs dying, which would be catastrophic and irreversible. Modestly reduced emissions curves are not likely to prevent one or more of these from being reached. Planning on the assumption of an intact climate system is no longer prudent. Every tenth of a degree still counts, and so does the possibility that some thresholds are passed anyway.
- The societal and economic knock-on effects are already evident. Clean energy jobs surpassed those from fossil fuels for the first time in 2021, and the clean energy sector accounted for 10% of global GDP growth in 2023, including 20% of China's and nearly one third of the EU's.
- A 'degrowth' future may be doubtful, but a forced re-emphasis on quality over volume is quite possible.
- Backlash will not reverse the transition, but it will continue to shape how it proceeds: slowly, unevenly, and through periods of contest and friction.

## Figure: share of primary energy consumption from renewable sources

A single line chart labelled World, plotted from 1997 to 2024, with a vertical axis from 0% to 16%. The line sits flat at roughly 7% from 1997 through about 2008, dips slightly around 2005, then climbs steadily: past 8% by 2010, 10% by 2014, 12% by 2018, and on to roughly 15% by 2024. The share is measured using the substitution method, estimating the fossil fuel input that would have been required to generate the same electricity. Renewables include hydropower, solar, wind, geothermal, bioenergy, wave and tidal, but not traditional biofuels, which can be a key energy source, especially in lower-income settings.

<!-- /context/megatrends/health-beyond-the-clinic.md -->

---
type: Megatrend
title: Health beyond the clinic
description: Health is shifting from acute treatment of infectious disease to lifelong management of chronic conditions shaped by food, work, housing and air long before anyone sees a doctor.
status: stable
use_when: "a plan for health, wellbeing or service journalism assumes audiences rely on clinicians, not on managing chronic conditions themselves with apps, wearables and AI"
sources:
  - id: ref-megatrends
    resource: "CIFS (2026), Megatrends: The foundations of long-term change, chapter Health Beyond the Clinic"
---

# Health beyond the clinic

## What it is

Health management is shifting from a matter of communicable disease and acute treatment to one of chronic, long-term management embedded in everyday life. A century ago, infectious disease dominated mortality. Today, non-communicable diseases account for most non-pandemic deaths. This reflects not only ageing, which means people live longer with chronic conditions, but also health outcomes being shaped by people's environment and circumstance well before they reach a doctor.

The future of health is marked by a series of challenges which include growing self-management (and the inequality in who can do it well), healthcare systems strained by long-term care, and an ageing population whose extra years do not necessarily translate proportionately into extra years of health. New tools like wearables and AI guidance offer partial help but create new risks around reliability, health literacy and trust. Whether interventions can close these gaps, and how, remains a central question.

## Sub-trends

- Rise of chronic diseases
- Health risks embedded in everyday systems
- Recognition and growth of mental health needs
- Expansion of self-managed healthcare
- Growth of digital health tools
- New actors and business models
- Inequality in access to care, health literacy and prevention

## Uncertainties

- Will government interventions in areas such as food security and housing quality mitigate health risks, or will structural drivers of chronic risk remain embedded in systems and infrastructures?
- How will misinformation and trust (or lack of it) in science-based health information affect attitudes towards public health interventions, medications and diagnostic tools?
- How will health innovation impact health systems and preventive models of care?
- Who will have the overview and ownership of all relevant individual health data? Will a balance be struck between data protection and privacy and interoperability of systems and institutions?
- Who will be held responsible when decision-support tools, AI-mediated or otherwise, produce adverse health outcomes or behaviour?
- Will health financing and incentive structures evolve to reward innovation, outcomes-based reimbursement for medical professionals, and preventive, healthier-living behaviours among individuals? Or will financing remain anchored to volume-based care and treatment of illness after the fact, leaving current incentive structures largely intact?

## Drivers

- A century ago, infectious diseases such as tuberculosis, influenza and pneumonia were the leading causes of death across much of the world, and only one in six deaths were due to a chronic condition. This began to change in the mid-twentieth century, when sanitation, clean water, vaccination programmes, and the widespread adoption of antibiotics and public health measures greatly extended life expectancy, allowing populations to live long enough to develop chronic conditions.
- Dietary shifts toward calorie-dense processed foods and increasingly sedentary lifestyles compounded the prevalence of these same chronic conditions. Rapid urbanisation (linked to poor diets, physical inactivity and air pollution), rising global obesity rates, tobacco use and increasingly sedentary jobs are more important contributors than longer lives alone.
- Health risks are increasingly embedded in everyday systems, like food environments, work life, transport patterns, urban environments and housing conditions. Health outcomes are often shaped long before people consider contacting their doctor.
- Because chronic disease develops slowly, today's prevalence figures reflect exposures accumulated across a generation rather than recent changes in behaviour. Annual per capita sales of ultra-processed foods rose 40% across lower-middle income countries between 2007 and 2022, and by as much as 60% in Uganda, while sales in high-income countries stayed flat. Today, 31% of adults worldwide do not meet minimum physical activity levels, projected to rise to 35% by 2030 if present trends hold.
- Pollution in rapidly developing urban areas is a tenacious cause of chronic illness. Air pollution in megacities such as Delhi, Dhaka and Lahore routinely exceeds WHO limits, sometimes more than tenfold. As climate change intensifies, extreme weather and its associated health risks become a permanent part of everyday life in large parts of the world, especially in Africa and Asia. Extreme heat significantly accelerates the progression of chronic kidney disease and can trigger acute cardiovascular problems.

## Manifestations

- Non-communicable diseases account for 75% of all non-pandemic deaths globally. The conditions driving this burden (heart disease, diabetes, cancer, chronic respiratory disease) are not resolved through a single treatment but are lived with and managed over years. Living with multiple chronic conditions at once has become much more common.
- An estimated 650 million people were living with cardiovascular disease in 2023, some 468 million with a chronic respiratory condition in 2021, and the International Diabetes Federation projects 853 million people living with diabetes by 2050, nearly one in ten adults alive today. Most will be managing their conditions at home or at work, through apps, medication adherence, dietary choices and daily decisions made without clinical support.
- 82% of premature deaths from non-communicable diseases occur in low- and middle-income countries, where prevention infrastructure is limited, diagnosis often comes late, and chronic disease compounds rather than replaces the existing infectious disease burden.
- Nearly one in seven people live with a mental disorder, most commonly anxiety and depression. Suicide is the third leading cause of death among people aged 15 to 29 worldwide, with men twice as affected as women, and 73% of the world's suicides happen in low- and middle-income countries. Mental disorders frequently co-occur with physical chronic conditions.
- Care increasingly relies on tasks that patients and their families carry out themselves. Individuals must navigate an immense amount of health information from clinical portals, apps and wearables, insurers, employers and social media, with varying degrees of reliability or alignment.
- Health literacy tracks the socioeconomic gradient. Those with more education, more time and more stable circumstances are best placed to engage with a system that requires self-management, while those with the least of these things are offered the least structured support. The democratisation of health technologies, and of AI-mediated health guidance in particular, has begun to narrow parts of this gap by making tailored information available to people who previously had no route to it. But the same tools deliver unverified or unverifiable information at scale, and the capacity to tell the difference is itself a function of health literacy.
- In nearly three-quarters of countries with data, medicines account for at least 55% of out-of-pocket spending, rising to a median of 60% among people living in poverty. In 2022, 2.1 billion people experienced financial hardship due to out-of-pocket health spending.
- Health wearables support continuous individualised monitoring of heart rate, nutrition, stress levels and sleep patterns. With AI-powered chatbots, individuals can seek guidance on any health-related question in seconds, though some researchers have found the error rate of AI-generated health answers to be twice as high as for human physicians. People's confidence in their own ability to make health decisions has fallen sharply, down ten points globally in a single year. The erosion of trust in scientific authority predates generative AI, which entered an information environment already shaped by social media and few trusted intermediaries between researchers and the public.
- The number of years people live in poor health (the morbidity gap) widened globally from 8.8 years in 1990 to 10.7 in 2023, with the largest gaps in the wealthiest countries, led by the United States, Australia and Canada. Those years are spread across adulthood, not only the end of life. 80% of long-term care in Europe is performed by informal caregivers, the majority women.
- Long-term care is the fastest-growing component of age-related public spending, projected to almost double across OECD countries by 2050 to 2.8% of GDP, and it is the component least amenable to productivity gains, since care requires human interaction.
- Assisted dying legislation has surfaced in many countries and is under active consideration across a widening set of European jurisdictions. The contested path of Portugal's 2023 law, adopted by parliament but held up by presidential veto and constitutional challenge, illustrates how unsettled the terrain remains.
- Some signals point to a healthier future. Tobacco use has fallen worldwide continuously over the last 20 years, although gains are partly offset by a shift to e-cigarettes, heated tobacco and nicotine pouches. Consumers in the US, UK, Germany and China rank wellness as a top or important priority, with mental and cognitive health among the areas of greatest unmet need. The global wellness economy has roughly doubled in value since 2013, though it remains concentrated in high-income markets.

## Implications

- Health management is becoming a permanent condition of life, stretching across childhood, education, work, family formation and old age.
- The health outcome of a worker in an Asian or African megacity is decided less by their genetic makeup or which communicable disease they may contract than by systemic factors: the city they live in, the air they breathe, the food they can access or afford, the way they must conduct their work, and more extreme weather. Health is a systemic challenge like no other and will need to be addressed in a systemic manner.
- For one group, the new health landscape means flexibility and autonomy. For the other, it is an added burden. More responsibility for health management may also mean higher costs for individuals and families.
- More input alone, from doctors, AI tools, social media creators and other sources, does not create a better or more empowering information environment.
- If medicine is increasingly capable of extending life without proportionately extending the quality of it, societies will have to decide what they are extending life for.
- A major question is how to close the gap between those who can manage their health proactively and those who cannot. If left unsolved, growing health inequality will become a defining feature of this century.
- Traditional healthcare systems will likely remain the bedrock of health, but they may only handle a fraction of what health management will entail over the coming decades. The rest will be distributed across everyday life: homes, workplaces, devices, family and friends.

<!-- /context/megatrends/individualised-everyday-life.md -->

---
type: Megatrend
title: Individualised everyday life
description: Shrinking households, deferred family formation and blurred life-phases are replacing standardised communal scaffolding with self-authored lives, at the cost of rising loneliness.
status: stable
use_when: "a plan assumes a shared household audience, a mass front page or stable life-stage segments, while people live alone, defer family life and look for community"
sources:
  - id: ref-megatrends
    resource: "CIFS (2026), Megatrends: The foundations of long-term change, chapter Individualised Everyday Life"
---

# Individualised everyday life

## What it is

As individualisation in its various expressions becomes a worldwide condition, the standardised communal scaffolding of the past is giving way to a manifold, negotiated and self-authored pluralisation of everyday life. Across very different societies the underlying indicators point the same way: smaller households, more people living alone, postponement of marriage and childbirth, and less defined and linear life-phases. On the level of individual consciousness, identity shifts from something that is given to something that is constructed, maintained and revised. The forms and expressions of individualisation vary sharply by culture, social structures and political system, yet its overall direction is unmistakable. This also comes with a cost, in the form of rising loneliness, isolation and social fragmentation.

Individualisation has typically been connected to the progression of developed nations and (Western) values like personal autonomy, self-direction and individual rights, sometimes invoked as the ideal in contrast to the constraints of traditionalism and communal living. The realities of social life are not that simple. Humans are individuals but also social animals, and the idea that we can strip away the layers of collective belonging, social values and culture to arrive at our true authentic selves is little more than a myth. Individualisation can rhyme with empowerment, but it can also rhyme with fragmentation, loneliness and isolation. Considered less as an abstract ideal and more as a composite of concrete indicators, how people live, what their social and relational arrangements are, their goals and values, what they teach their children, it is a trend that has been growing worldwide for decades. Socially, we are moving from more standardised configurations towards more diverse, hybrid, negotiated and context-dependent arrangements.

## Sub-trends

- The decline of traditional social institutions
- Household downsizing
- Blurring of life-phases
- Expansion of the global middle class
- Expansion of access to education
- Increasing integration of women into the labour force
- Lifestyle and consumption as identity markers
- Individual life becoming 'place-polygamous'
- Alternative family formations

## Uncertainties

- What will be the extent of the current wave of traditionalist backlash (visible in legislative rollbacks and cultural and political movements)?
- Will societal efforts to counteract social atomisation, loneliness and other mental health concerns be sufficient to alleviate the negative fallout of individualisation?
- Might economic constraints and precarity become further barriers for individualised practices?
- Will renewed spirituality, religion and other forms of cultural community offer an alternative to the isolating effects of individualisation?
- Does individualisation produce more trust overall (because relationships are chosen rather than inherited) or less (because shared frameworks erode)?

## Drivers

- The shift began in the mid-twentieth century when perceptions, norms and behaviours built around the male-breadwinner household, traditional family formation and household patterns, and a relatively predictable life sequence that organised everyday life across much of the world started to break down.
- Changes in household structure and life-phase sequencing are the visible outcomes of underlying socioeconomic shifts. Among the most consequential are the global expansion of education, especially for girls and young women, and the steady integration of women into paid work. Other key drivers include the move from rural to urban living and the growth of white-collar employment. Together these forces are the structural engines beneath individualisation and the reconfiguration of social life.
- The global middle class (people who live on between 10 and 20 USD a day) now comprises over 4 billion people, around half of the world's population. Rapid economic development in Asia means this group is expected to grow by another billion within the next decade, reaching 5.7 billion out of a world population of 8.7 billion by 2035. World Values Survey data show 'self-expression values' rising in step with economic development across many cultures, not only Western ones.
- Globalisation, technology and media have connected individuals to large abstract systems in a new way, on both a local and a worldwide level. Through technologies, the internet, increased mobility and mass media, the individual has become 'place-polygamous', connected to several places at once that in concert help to form their identity.
- The social theorist Anthony Giddens links this to 'the institutional reflexivity of modernity' and the reorganisation of time and space, whereby life has become separated from its previous forms and structures and has become more fragmented, unstructured and uncertain. What emerges is the self as a 'reflexive project'.
- The global ubiquity of platforms like TikTok, Douyin, Instagram, KakaoTalk and WhatsApp, all of which structurally reward individuality and self-presentation, reinforces these dynamics from the digital side.

## Manifestations

- Since the 1960s, a documented trend has been a rise in both individualist practices (indexed by household size, the share of single-person households, and the ratio of divorced or separated to married or widowed people) and individualist values (the relative importance of friends versus family, whether independence rather than obedience is endorsed as a value to teach children, and preference for self-expression goals).
- Household sizes have been declining by approximately 0.5 people per decade over the past five decades, linked primarily to the global increase in people living alone, but also to declining fertility, smaller families, increasing life expectancy, and smaller household formations arising from divorce or single parenthood. The home is the primary site for the manifestation and reproduction of many of our most fundamental social arrangements.
- Each society has historically supported one or more dominant family-and-household norms: the extended-family household in South Asia, the nuclear family household in much of the post-war West, polygynous arrangements in parts of West Africa and the Middle East, the matrifocal household across parts of the Caribbean. With decreasing household size comes the weakening grip of these locally dominant family forms and the proliferation of alternative arrangements alongside them.
- The consequences take culturally distinctive forms. South Korea and Japan have produced perhaps the most extreme expressions: honbap (solo eating), ohitorisama (party of one) culture, some of the world's lowest fertility rates, and kodokushi (lonely deaths) as a social category in its own right. China's post-1980 generations have been described as undergoing a 'rise of the individual', visible in the 'single economy', in tangping ('lying flat'), and in mass migration from close-knit villages to anonymous megacity life. India's urban middle classes have largely shifted away from traditional forms of arranged marriage in a single generation. In Latin America, secularisation and fertility decline run alongside vibrant urban self-expression cultures. Urbanists working in African cities document deeply aspirational, individualised urban subjectivities.
- Life-phases are blurring, replacing the old linear script of school, career, marriage and retirement with a fluid and more self-authored sequence. The age brackets for when individuals are perceived to be 'young' or 'adult', when they settle down and start a family, or how old they are when they retire are changing, and life-phases are becoming more liquid, extended and overlapping.
- Family formation is increasingly deferred across the world. The age at which women give birth to their first child began to increase steadily in industrialised countries in the 1960s, and the age span for when the family life phase is initiated widened (at its extreme, family life for women can now start before their 20s or around their 50s). In former Soviet countries a similar trend began in the 1990s, and across many countries in South America and Africa the same postponement is visible today.
- Marriage is postponed and becoming less common overall. Average marriage age for women has increased across much of the world, from the early-to-mid-twenties to the late twenties or early thirties in some countries. Unmarried couples increasingly live and have children together, leading to a 'decoupling' of marriage and parenthood.

## Implications

- Smaller and more diverse family household manifestations, increasingly decoupled from marriage and distributed across multiple households and locations, will greatly impact how individualisation continues to be nourished and how everyday life is reorganised and lived. These changes extend from consumption patterns and needs, abilities and constraints, over to mobility and communication practices and demands, and much more.
- Individualisation moves at different speeds and takes different shapes across societies, refracted by class, gender, region, culture and political system.
- It comes with significant collateral effects. Individual freedom is accompanied by rising loneliness and isolation; self-expression by fragmentation; and in many places by a vigorous re-traditionalising backlash, particularly around gender, religion and family.
- Across the variation, the structural direction is unmistakable. As households continue to shrink and diversify, life-phases loosen, access to education expands, and the global middle class grows, the standardised social scaffolding of the twentieth century gives way to more plural, negotiated and self-authored arrangements of everyday life.

<!-- /context/megatrends/inversion-of-the-population-pyramid.md -->

---
type: Megatrend
title: Inversion of the population pyramid
description: Sustained fertility decline and longer lives are turning youth-heavy societies senior-heavy, at an uneven pace that leaves ageing, shrinking and youth-expanding populations coexisting.
status: stable
use_when: "a plan assumes today's age mix of audience, subscribers or staff will hold, or treats loyal older readers and missing young ones as a temporary imbalance"
sources:
  - id: ref-megatrends
    resource: "CIFS (2026), Megatrends: The foundations of long-term change, chapter Inversion of the Population Pyramid"
---

# Inversion of the population pyramid

## What it is

The global population is being fundamentally restructured through a shift from youth-heavy to increasingly senior-heavy societies, driven by sustained fertility decline and longer lifespans. This transition is universal in direction but uneven in pace. Some countries are already experiencing rapid ageing and population decline, while others still face continued population growth and younger age structures for decades to come. The result is a period where ageing, shrinking population and youth expansion coexist globally.

The knock-on consequences of this demographic inversion extend across societal domains. They strain pension, healthcare and education systems built for populations that were, on average, younger. They create imperatives for investment in AI and automation to offset a shrinking labour supply. They drive migration flows and affect intergenerational relations. And they shift the political calculus around conflict, innovation and institutional risk-taking.

## Sub-trends

- Uneven population growth concentration
- Sustained decline in fertility rate
- Rising life expectancy and ageing
- Increasing dependency burdens
- Migration pressures

## Uncertainties

- Will barriers to family formation, including housing costs, labour market insecurity, gender inequality and changing social norms, persist or intensify, further suppressing fertility rates?
- To what extent will international migration cushion the effects of ageing and workforce contraction in low-fertility countries?
- Is migration managed or disruptive, both at point of origin and destination?
- To what extent can productivity gains through technology and automation offset the economic effects of shrinking or ageing workforces?
- Will governments be able to adapt social systems such as pensions, healthcare and education to match changing population structures?
- Will lower-income countries be able to keep up with the needs of their rapidly growing young population?

## Drivers

- The latest century of human history has been marked by unprecedented population growth. For millennia, the global population was on a slow but steady increase, as high birth rates were largely offset by high death rates. Beginning in the mid-20th century, this rough equilibrium was broken. Although growth is now slowing, the world population is projected to rise to around 10.3 billion in the mid-2080s (up from 8.2 billion in 2024). This future growth will occur mainly in Sub-Saharan Africa and Asia. More than one fifth of population growth between 2024 and 2054 is expected to come from just nine countries, including Angola, the Democratic Republic of Congo, Niger, Somalia and Tanzania, where populations are projected to at least double.
- At the core of this shift lies a sustained decline in fertility. Globally, fertility rates have fallen to around 2.3 children per woman, less than half the level observed in the 1950s. Even in many of the world's most populous countries, including India and China, fertility has dropped below the replacement level of approximately 2.1, making long-term population decline increasingly likely without sustained immigration.
- In many countries, people have fewer children than they desire, pointing to a gap between fertility intentions and outcomes driven by high childcare costs, job insecurity, difficulties in reconciling work and family life, and reproductive health. Fertility outcomes depend not only on financial support for families but also on gender dynamics. In France and Sweden, family policies combined with more equal care structures help sustain relatively higher fertility. In Japan and South Korea, where gender inequality and work-life imbalance persist, increased spending has had limited impact. In other countries, the preference to have fewer or no children is the deciding factor, as in Hungary, where baby loans and income tax exemptions for mothers among the most generous in the world have produced no durable rise in fertility.
- Alongside declining fertility, rising life expectancy is extending the upper end of the age distribution. Improvements in healthcare, nutrition and living standards have increased longevity across most regions, contributing to increasingly 'top-heavy' age structures. By 2060, 28% of the OECD population will be aged 65 or older, rising to roughly 37% in Italy and Japan.

## Manifestations

- More than one quarter of the global population already lives in countries where population growth has peaked, including China, Germany, Japan and the Russian Federation. Countries such as India, Indonesia, Nigeria, Pakistan and the US are projected to continue growing, with population peaks expected later in the century or beyond 2100. In the long term, even some of the most populous countries today will face a future where labour force expansion can no longer be taken for granted, where dependency ratios begin to rise, and where economic growth becomes increasingly reliant on productivity rather than demographic momentum.
- The inversion occurs across all regions but at an uneven pace. All societies face a demographic race against time. Some will be pressured to fundamentally restructure their economic and social welfare systems to account for rapidly ageing populations and shrinking workforces, while others will need to make sure that their expanding, youthful population is converted into a productive, healthy and utilised labour force.
- Ageing leads to financial constraints. Alzheimer's and other dementias alone will cost the world economy USD 14,513 billion between 2020 and 2050, putting pressure on pension and healthcare systems designed for a very different demographic outlook.
- As populations age, the growing political weight of older cohorts influences fiscal priorities, with increased support for pensions, healthcare and other forms of social protection. Ageing populations are associated with relatively lower public spending on education and lower long-run economic growth, reflecting a shift towards present-oriented welfare over future-oriented expenditure.
- Automation is being taken up in response. In Japan, faced with steep population decline, increased automation efforts can be seen in the context of the acute need to expand labour productivity and extend working lives. China is heavily investing in automation and AI to offset the negative economic impact of an ageing population.
- In youthful countries such as Nigeria, Tanzania and the Democratic Republic of Congo, the primary concerns relate to absorbing rapidly expanding labour forces into productive employment and ensuring sufficient investment in education, job creation, housing and infrastructure. Where this is achieved, it could generate a demographic dividend; where it is not, it could increase the risk of persistent unemployment, informality and social instability. This demographic momentum often coincides with mounting pressure on food systems and essential resources, even as fast-growing countries are expected to account for a growing share of global economic expansion.
- Migration is often seen as a solution to the twin challenges of growth and decline. The global stock of international migrants reached 304 million in 2024, nearly twice as many as in 1990. In several low-fertility destinations, including the United Arab Emirates, Germany, Italy, Portugal and the Czech Republic, immigration accounted for all population growth between 2000 and 2020. Advanced economies already experience societal polarisation and a rise in nativist politics partly in response to immigration. In countries with an outward flow, brain drain and loss of economic momentum become pressing. The African Development Bank estimates that 10 to 12 million young Africans enter the labour market each year while only around three million formal jobs are created; where this gap persists, a youth population that could have powered growth is pushed into unemployment and informality and pressured to seek opportunity abroad.

## Implications

- The growing imbalance will fundamentally alter the relationship between working populations and dependents.
- Ageing may lessen both the preferences and capacity for warfare in aged countries. A scarcity of young people tends to make 'wasting' their lives in war more costly, and their labour will be needed elsewhere in the economy, potentially pulling the international arena in the direction of a geriatric peace.
- Risk-averseness is a general characteristic of aged electorates, who tend to be more conservative than younger ones. Ageing populations will increasingly represent a governance dilemma, evident in the tension between systems that function as investments in the future (education, climate and the environment, infrastructure) and those oriented toward managing the present (pensions, sick care and eldercare). As retirees crowd out workers, the notion that each generation supports the previous one in old age will come under increased pressure.
- One could imagine a future society that is more peaceful, perhaps, but also more stagnant, less innovative, more nostalgic in its culture and politics, and much more demanding on the youth to perform their role as custodians of an ageing society rather than innovators. The generational tensions already evident where young people feel locked out of housing and asset markets could intensify in a future where the youth become simultaneously the most protected and the most extracted-from demographic.
- In most societies, informal eldercare is performed primarily by women, sometimes at the cost of labour market participation. An ageing society heightens the risk of a structural reinforcement of gender inequality, and may exacerbate declining fertility, since the unequal domestic burden on women is one of its documented drivers.
- Over the century, as more countries experience labour shortages, large-scale migration will be harder to resist politically, but the impetus to grow the labour force in receiving countries will need to be continuously balanced with the risk of political backlash.
- There will be an increasingly uneven distribution of labour, capital and institutional capacity. A growing share of global labour force expansion will be concentrated in Sub-Saharan Africa, while capital, financial depth and institutional capacity remain concentrated in higher-income economies. This divergence is expected to reshape patterns of global interdependence and could generate new tensions around migration and investment flows.
- Two potential futures emerge. One in which intensifying competition for younger workers becomes the focal point of geopolitical bargaining. Another where automation and AI displace jobs at scale, so that labour scarcity is not as big an issue as expected, placing economic and social systems on new foundations and raising questions about who owns the output and how it is shared, and about the value of care work that markets still do not price.
- The great demographic inversion will not produce a single global outcome. Economies will face fundamentally different challenges, whether managing labour scarcity and fiscal pressure in ageing societies or creating employment and opportunity in younger ones. These asymmetries will shape economic performance, social organisation and political dynamics for decades to come.

## Figure: the East Asian demographic inversion

Two population pyramids side by side, each split into male and female halves, with five-year age bands from 0-4 at the bottom to 100+ at the top and a horizontal scale from 10% through 0% to 10%. Eastern Asia in 2000, with a population of just under 1.5 billion, is a broad-based triangle whose widest bands sit in the 25-39 brackets, tapering steadily upward with very narrow bands above 70. Eastern Asia in 2100, with a population of around 770 million, has inverted: the base below age 20 is narrow, the widest bands sit in the 70-89 brackets, and the profile bulges near the top before tapering at 100+. A sustained fertility decline narrows the base while longer lives fill out the top, and the region's population is expected to fall over the century to roughly half its size in 2000.

<!-- /context/megatrends/new-face-of-urbanisation.md -->

---
type: Megatrend
title: The new face of urbanisation
description: Cities in Asia and Africa are growing faster than institutions can adapt and at lower income levels than any earlier wave, producing megaregions, informal settlements and planned cities side by side.
status: stable
use_when: "a plan for international, regional or local coverage, or for growth markets, assumes cities and their audiences will grow the way earlier urban waves did"
sources:
  - id: ref-megatrends
    resource: "CIFS (2026), Megatrends: The foundations of long-term change, chapter The New Face of Urbanisation"
---

# The new face of urbanisation

## What it is

Over the course of this century, urban milieus, primarily in Asia and Africa, will undergo developmental changes with unprecedented speed and complexity. The new urban epicentres will expand faster than institutions can adapt, often at lower income levels, and under demographic, climate and governance pressures that make comparison to any previous wave of city-building difficult. The central question is not only how many people will live in cities, but also what kinds of urban worlds will emerge and who will be included in them.

Cities have always been where human civilisation experiments on itself. Novel ideas emerge there, and radical solutions often get tested there first. They are microcosms of the plurality of futures ahead. More than half of the world's population currently lives in urban areas, and by 2050 this share is projected to rise to 68% (6.6 billion people). Asia and Africa will host around 90% of the additional urban population in the next three decades.

## Sub-trends

- Ascension of megacities (10+ million residents)
- Urbanisation happening earlier in economic development
- Growing prevalence of informal housing
- Housing affordability pressures
- Rural-to-urban influx
- Forced migration and displacement

## Uncertainties

- Will governance be able to adapt in the fastest urbanising regions to prevent entrenched poverty at scale?
- What will be the balance between public and private ownership and governance of the urban infrastructure?
- To what extent will climate and environmental constraints disrupt urban growth trajectories?
- Will urban concentration generate broad-based prosperity or deepen inequality between formal and informal zones?
- Will the new megacities leapfrog to design paradigms suited to emerging needs, or will they be built on models designed for a world that no longer exists?

## Drivers

- Historically, cities have been associated with economic expansion and rising incomes, but the relationship is not straightforward. What makes the current wave historically distinct is the income level at which it is happening. Sub-Saharan Africa and much of South Asia are urbanising far earlier in their economic development than Latin America or East Asia did. These regions cannot always supply the infrastructure, institutions and services that dense urban populations require, leaving them in a permanent state of catch-up.
- Even under these conditions, cities tend to offer substantially higher incomes and better access to services than the areas people are leaving, which is precisely what sustains the migration.
- The forces driving urban growth are the economic pull of cities over rural alternatives, the displacement effects of climate stress on agricultural land, and the concentration of infrastructure investment in urban centres.
- Some planned cities are motivated by existential necessity. Parts of Jakarta, currently the world's most populous city with nearly 42 million inhabitants, are sinking by as much as 25 centimetres per year, with sections at risk of being submerged by 2050, prompting Indonesia to develop Nusantara, a new political capital over 1,000 kilometres away.

## Manifestations

- Dhaka in Bangladesh is expected to become the world's largest city by mid-century with 52 million inhabitants, roughly the size of South Korea's total current population. Towards 2050, Africa's urban population is estimated to double from 700 million to 1.4 billion, almost the equivalent of the entire populations of the United States and the European Union moving into cities within less than 30 years.
- Megaregions are forming in Asia and Africa as neighbouring cities expand outwards until they merge into continuous urban corridors, such as India's emerging Delhi-Kolkata corridor along the Indo-Gangetic Plain and the Lagos-Abidjan corridor spanning five countries. Both exceed the capacity of governance infrastructures designed for individually separated cities. Megaregions can be products of megacities subsuming urban areas within their reach, or of several closely located cities morphing together. The number of megacities has quadrupled from eight in 1975 to 33 in 2025 and is projected to reach 37 by 2050.
- Rapidly expanding cities and megaregions will increase informal settlements globally. As new urban epicentres draw in workers, housing costs often exceed what is affordable to low-income migrants, who settle on the urban fringes. Informal settlements are not aberrations from planned urban development but its predictable offshoots, often characterised by self-organised construction along new highways or railways that provide access to the formal city economy. Informality moves into the periphery, the 'gray spaces', producing a tension between the formal core and the gray zones that formality itself generates at the margins.
- Urban populations in the rest of the world are also expanding, at a much slower pace. In Europe and North America, built-up areas expand faster than urban populations can occupy them, the opposite dynamic from fast-growing cities in Africa and Asia. Housing affordability is an issue across OECD countries, where close to half of low-income owners spent over 40% of disposable income on a mortgage in 2022, as did low-income renters.
- The flip side is the rapid depopulation of smaller cities and rural areas, risking their collapse. Around 3,000 cities experienced population decline between 2015 and 2025, most with fewer than 250,000 inhabitants, over a third in China and 17% in India, showing that urban growth and decline often occur simultaneously within the same country.
- In contrast to emergent informal milieus is the wave of master-planned satellite cities in Africa, South-East Asia and the Middle East. Over 90% of urban planning projects announced in the 21st century have or will take place in low-income economies. Egypt's New Administrative Capital, a 700 km2 development east of Cairo, is built to house government ministries and relieve pressure on a city of over 22 million. Tatu City near Nairobi is designed as a self-contained urban hub to attract investment, as is Nigeria's Enyimba Economic City. Saudi Arabia's The Line, now heavily scaled back, was meant to be a model concept city built for liveability, sustainability and urban innovation.

## Implications

- The world's new urban epicentres will not follow neat formulae of growth and development, nor necessarily be considered the pinnacle of urban achievement. Given the speed of their expansion, they will face circumstance-specific obstacles and completely novel forms of urban environment will emerge.
- The makeshift and the intermediary have traditionally been presented as developmental problems to solve, but cities that have had to improvise their way forward have developed a particular resourcefulness. Coupled with relatively youthful populations, these urban epicentres provide fertile ground for novel solutions to local and global problems. It is also in the margins where ideas and solutions to novel challenges might be sown.
- The future of urbanisation will be a set of deeply divergent urban worlds, shaped by the speed of each city's expansion, the capacity of its institutions, the climate vulnerability of its location, and the income level of the populations it absorbs. In some places, informal self-organisation will prove more adaptive than formal planning. In others, the gap between population growth and service delivery will become self-reinforcing, locking communities into persistent precarity. In others still, planned city experiments will attract capital and expertise while leaving the surrounding urban fabric largely untouched.
- What ties these trajectories together is the structural momentum behind them. Even where urban governance fails to keep pace, the cities will grow. The central question is what kinds of places this urbanisation produces and who bears the cost of the gaps it could leave behind.

<!-- /context/megatrends/power-through-networks.md -->

---
type: Megatrend
title: Power through networks
description: Authority is shifting from territorial states to the transnational digital infrastructures that critical functions depend on, redistributing power to their owners and to the states that act through them.
status: stable
use_when: "a plan depends on cloud, platform or AI infrastructure owned by a few foreign companies, or treats that dependency as a neutral technical choice"
sources:
  - id: ref-megatrends
    resource: "CIFS (2026), Megatrends: The foundations of long-term change, chapter Power Through Networks"
---

# Power through networks

## What it is

Power Through Networks describes the long-term shift from territorial, state-centred sovereignty and power towards authority that is distributed, networked and overlapping. Critical social, economic and security functions increasingly depend on transnational digital infrastructures that no single state controls. Authority is redistributed rather than drained away, since the same networks that put a function beyond one state's reach can extend another's.

Meta, Alphabet, Amazon and other infrastructural giants defy easy categorisation as mere market participants. They are companies, but also private entities grown into para-states with unprecedented political and economic power and geographical reach, achieved through ownership of the infrastructure on which the daily functioning of society, global commerce and states increasingly depend. They exercise power in their own interests, sometimes to the point of influencing elections. But the reverse holds as well: states govern through these private networks, treating their reach as an extension of national jurisdiction and their services as levers that can be tightened or withdrawn. The general picture is a dynamic and fluid reconfiguration, of 'new territories superimposed on older territories'.

## Sub-trends

- Hyperscaler dominance over critical digital infrastructure
- Divergence of competing infrastructure models: US commercial, EU regulatory, Chinese state-aligned
- Shift from 'territorial' to 'operational' sovereignty (from jurisdiction over territory to control over infrastructure)
- Increasing state and public sector dependency on private networks
- Growing political influence of US-based and Chinese tech sectors, domestically and internationally
- States projecting power through privately operated infrastructure

## Uncertainties

- Will most developing economies come to depend on US or on Chinese digital infrastructure and solutions?
- Which public institutions will struggle to discharge their mandates when the infrastructure they depend on sits outside their jurisdiction?
- Will service suspension become a routine instrument of statecraft, or remain exceptional enough to be shocking?
- To what extent will Europe succeed in its goal of achieving digital sovereignty through homegrown digital infrastructure?
- Will the gap between governing role and governing seat ever close formally?

## Drivers

- The megatrend has its origins in the transition of the internet from a government-sponsored network to a commercial one in the mid-1990s. Its historical roots go deeper: Britain's 'All-red Line' telegraph system safeguarded imperial communications though it was mostly privately owned and operated, a past version of today's sovereign cloud.
- Ownership of digital infrastructure is increasingly concentrated, and in most of the world that concentration sits with a handful of US-based hyperscalers. As of 2025, Amazon, Microsoft and Alphabet held 63% of the worldwide cloud market.
- Undersea cables, the arteries of the digital world, were historically built by regulated, route-neutral, multi-stakeholder carrier consortiums. Digital giants are now vertically integrating this infrastructure with their services. In 2010, Google, Facebook, Microsoft and Amazon had invested in just one long-distance undersea cable between them; by the end of 2024, they had stakes in more than 60 of about 600 worldwide. Content providers' share of total international cable capacity was 6.3% in 2010 and is expected to reach 78% by 2027.
- Data centres, fibre optic lines, cloud servers and cellular towers add to these material foundations, which suggest long-term durability.
- Nations now exercise power alongside and sometimes through 'virtual' or 'supplemental' sovereigns, tech companies and platforms exercising commercial development of and control over critical software and hardware.

## Manifestations

- Governments issue currency and maintain monetary sovereignty, but everyday payments and transactions are increasingly mediated by private transactional networks. Privately owned infrastructure, undersea cables, cloud computing, satellite networks and data centres, has become as crucial as public roads, grids and postal services, or more so.
- In the United Kingdom, 95% of central and local public sector organisations spent budget on hyperscale cloud services in fiscal year 2023/24, mostly with US-based providers.
- As passports and driving licences are supplemented by digital IDs, biometrics and verification via social media, citizens become 'users' as well as national subjects. Individual health data is simultaneously personal information safeguarded by national law and a valuable resource for private actors in healthcare and insurance.
- In politics, maintaining a presence in the 'new public square', digital platforms hosted by private firms, is a necessity for reaching constituents and voters. Political critique of the platforms must often take place on the platforms themselves. Governance relies heavily on private software and utilities, so even functions only the state is authorised to perform are executed on systems it does not own.
- Not everything is being uprooted. Land and property, many welfare functions, and criminal justice remain more classically territorial.
- In August 2026, a US presidential memorandum authorised vetted private cybersecurity firms to carry out offensive cyber operations against international criminal networks targeting Americans, breaking from decades-old policy restricting private entities to network defence. Here the state extended its own reach through private actors rather than ceding ground to them.
- During Covid-19, emergency pandemic response, a core function of territorial sovereignty, hinged on smartphone operating systems, cloud services and API standards outside state control.
- After Russia's invasion of Ukraine in 2022, Ukraine appealed to ICANN, the US-based non-profit that coordinates the Domain Name System, to exclude Russia from the network. ICANN opted for neutrality, but the refusal was itself an exercise of authority. Starlink, a privately owned civilian network, became essential to Ukraine's ability to defend itself, used particularly for drones and artillery targeting; as of 2026 Starlink operates roughly 59% of all active satellites. The reliance made Ukraine's military more effective, but that effectiveness could be revoked by decisions taken elsewhere.
- In the EU, a sustained institutional response has taken the form of a digital sovereignty agenda and efforts to reduce dependency on non-EU infrastructure through regulation and targeted investments.
- In China, tech giants such as Alibaba, Tencent, ByteDance and Huawei have built the country's critical platform and network layers as formally private companies. Rather than replacing them, the state has attached itself to them through 'special management shares' with privileged voting rights, party cells within companies, and at times overt pressure or forced rectification of business leaders, most famously Alibaba founder Jack Ma. Beyond its borders, China's Digital Silk Road has financed fibre-optic cable, mobile networks, satellites and cloud capacity across Africa, Southeast Asia and Central Asia, on the terms of the Chinese state and tech providers. The difference from the American arrangement is one of directness rather than of kind.

## Implications

- The question of who governs, operates and holds authority over the systems that facilitate the functioning of societies and states has become a defining question for the 21st century.
- Infrastructure owners are, in effect, in governing roles but without formal governing seats. As the logic of the network supersedes the logic of the map, the borders of authority and agency are becoming vague and overlapping.
- Power, agency and sovereignty are not zero-sum. For states reliant on private networks, augmentation can coincide with vulnerable dependence. Digital infrastructure owners also pose direct challenges to territorial sovereignty; both things are true at the same time.
- Even the most ambitious European programme will only reshape the terms of dependency, perhaps resulting in a more even balance between homegrown and US-based providers, rather than eliminating it. A fundamental change in ownership patterns from private to fully public would require a momentous historical shake-up, such as a forced breakup or nationalisation of digital infrastructure. Today's regulatory backlash should be understood as a negotiation of the terms of dependency rather than a potential disruption of the trend.
- The next phase may be determined by the global struggle over whose infrastructure model becomes the default, and where, as the private infrastructure on which sovereignty depends may increasingly be Chinese rather than American in origin in significant portions of the world. The rerouting of sovereignty may be replicated under a different flag but remain a defining feature of the 21st century.

<!-- /context/megatrends/rise-of-embedded-ai.md -->

---
type: Megatrend
title: The rise of embedded AI
description: AI is moving from tool to infrastructure, automating cognitive work, mediating decisions and raising unresolved questions about who keeps cognitive ownership and control.
status: stable
use_when: "a plan treats AI as a tool to adopt, not as infrastructure that will mediate how audiences find information and how newsroom work and expertise are valued"
sources:
  - id: ref-megatrends
    resource: "CIFS (2026), Megatrends: The foundations of long-term change, chapter The Rise of Embedded AI"
---

# The rise of embedded AI

## What it is

The Rise of Embedded AI represents the shift from AI as a tool to AI as infrastructure. As AI becomes embedded into more facets of our lives, society and the economy, new questions and uncertainties related to the relationship between humans and machines start to appear, highlighting that the shift does not imply one predetermined future. The same developments that augment human capabilities can also deepen dependencies on systems few people fully understand, reshape where the value of knowledge work lies, and raise unresolved questions about retaining cognitive ownership and control as more decisions are delegated to machines.

Digitalisation has transformed society so thoroughly that digital technologies now function as the invisible infrastructure that ties the world together. Microprocessors are built into nearly everything, and if these systems suddenly failed, society would cease to function. AI represents the newest wave in this development, in which intelligence, interpretation and agency are being embedded into that same infrastructure. The rise of embedded AI is characterised both by augmentation and mediation: AI can enhance an individual's capabilities while simultaneously reshaping the organisational structures within which those capabilities are exercised.

## Sub-trends

- Increasing automation and augmentation of cognitive tasks and jobs
- Embodied human competencies, judgement, discernment and deep expertise, as a growing source of value
- AI and robotics/humanoids converging, the rise of 'physical AI'
- Personal AI assistants, agents and algorithms as gatekeepers for information, consumer preferences and spending behaviours
- AI as our 'second brains', individual, collective and organisational
- Cognitive offloading and the changing nature of cognitive agency in human-AI work
- AI-mediated relationships and synthetic companionship
- Concentration of ownership and control of AI infrastructure

## Uncertainties

- Will AI infrastructure become more open and interoperable or consolidate around a small number of proprietary ecosystems?
- Will humans stay 'in the loop' (actively signing off on AI decisions), move to 'on the loop' (stepping in only if needed), or end up 'out of the loop' (fully autonomous systems with no human check)?
- Will the advancement of AI provoke job-preserving regulations?
- Will the energy demand of AI slow down either the energy transition or the rollout of AI?
- To what extent can the human capability to oversee and validate the labour of AI itself be augmented?
- Will AGI (a system that matches or exceeds human capabilities across all thinking and working tasks) emerge, and can its alignment with human goals be ensured?
- Will AI systems mainly be designed to remove cognitive friction, or to strengthen learning, judgement and cognitive agency through their use?
- Will we see robust and effective AI governance to safeguard humanity from existential risks?
- Will the gains from AI be broadly shared, or captured by those who already own capital and compute?

## Drivers

- Earlier waves of digitalisation connected people, information and services. Computers, the internet and smartphones revolutionised how people access information and blurred the boundaries between work and leisure. AI systems can now interpret context, generate outputs, recommend actions, and increasingly act across digital environments.
- AI's capacity for cognitive enhancement is developing rapidly, but not along a single smooth curve. Performance can advance quickly in domains with clear feedback and verifiable outputs, while remaining weaker or less reliable in tasks requiring contextual judgement, ambiguous goals, or interaction with messy real-world environments. This jaggedness makes simple extrapolations from one benchmark to 'AI capability' as a whole misleading.
- The shift depends on other connectivity technologies such as direct-to-device satellite networks, wearables, connected vehicles, edge computing and smart environments. Together they let AI systems operate across contexts and in more places than phones and laptops. With wearable devices equipped with built-in sensing capabilities, each personal device can effectively become a sensor, providing continuous feeds of location and motion data into spatial models that act as a digital-physical sensing layer.
- A parallel machine-readable layer is emerging alongside the human-facing internet. Information is increasingly valuable not only when people can read it, but when AI systems can interpret, combine and act on it. Automated traffic already accounts for a larger share of web page requests than human traffic, and the rapid growth of agentic AI points towards an internet increasingly used by machines acting on people's behalf. Machine-readable data, provenance, permissions, interoperability and access therefore become part of the infrastructure itself.

## Manifestations

- Within white-collar work, AI is already automating tasks in legal work, architecture and engineering, business and financial operations, office and administrative support, and sales. A 'reshuffling' of human-machine capabilities is underway, in which AI brings down the economic value of specific individual tasks and causes a revaluation of human competencies. This sets the current era apart from previous waves of automation, which primarily impacted manual labour.
- Uneven capabilities mean that bottlenecks are likely to move rather than disappear. As the technology is applied to new tasks, novel constraints and unforeseen bottlenecks arise. This is a key restraining factor that the wildest AI predictions tend to ignore.
- In a future where machines execute more of the tasks of knowledge workers, the inelastic human capability for validation, auditing, and underwriting meaning and responsibility becomes relatively scarcer. As AI graduates from systems with easily verifiable outputs (chatbot text, images, code) to more autonomous, agentic models employed for higher-stakes tasks, verification becomes more necessary, difficult and time consuming.
- New forms of work are emerging: agentic workflow management, data privacy oversight, output verification, AI literacy (a basic understanding of how AI works and where its limits lie), and AI fluency (the ability to use, question and collaborate with AI effectively and intentionally). Intelligent platforms also need to function with legacy structures. If systems are not trusted, they get overridden and worked around, and if the digital layer never gains internal legitimacy, it never delivers real value.
- Workforce effects are very uneven. Weaker early-career hiring in some AI-exposed occupations is an early signal that the transition may alter not only jobs but the pathways through which people build expertise and acquire tacit knowledge. Capabilities that are difficult to synthesise will be at a premium, yet the path to building them becomes steeper. This 'missing junior loop' could mirror the youth unemployment seen after the 2008 Financial Crisis.
- Delegating more cognitive tasks to AI may free up attention and expand human capabilities, but it also changes which skills we practise, retain, or come to depend on machines to perform. Generative AI extends this effect across a much broader range of activities, adding urgency to questions about technological dependence, agency and 'digital dementia'.
- The proliferation of 'AI slop', the notion of loss of cognitive ownership, and a wider sense that systems are influencing how humans think, feel and make sense of the world are fuelling resistance to broader AI adoption in workplaces and everyday life.
- Instead of repeatedly opening a chatbot or application, individuals and organisations may increasingly rely on assistants, agents and 'second brains' that carry context across tasks, devices and services.
- Humanoid robots combining flexible hardware with AI can adapt to different environments, learn human tasks via demonstration, and transfer them to other machine actors. The dynamic is sometimes referred to as 'the codifier's curse', where expert professionals, by sharing their tacit knowledge with AI, accelerate the automation and displacement of their own jobs. Over time, machine intelligence becomes less tied to screens and more capable of perceiving and acting within physical systems, although the timing and scale of general-purpose robots becoming mainstream remains uncertain.
- Generative AI is already being used to guide couples in their relationships, inform medical decisions, help people parent, or keep people company when they are lonely. AI companionship remains outside the norm for most people today.

## Implications

- How societies respond to shifts in employment, income and pathways into expertise will become an increasingly important policy question. Without a total restructuring of income redistribution, perhaps through a Universal Basic Income (UBI), regulations will likely be used to limit effects on unemployment, since high unemployment undermines social cohesion and destabilises governments. Such interventions need to be applied carefully: a UBI could dull incentives to work and retrain, or pacify displaced workers with a cheque rather than address the underlying loss of bargaining power that comes with being economically unnecessary.
- The constraint on verification signals a need in parts of the knowledge economy to rethink the value chain, how companies are organised internally, and what gives them an edge over competitors.
- The key uncertainty is how different forms of AI use and design shape cognitive agency over time. On a deeper level, it forces existential questions about what it means to remain human in increasingly machine-mediated environments.
- Questions arise about who controls society's emerging 'thinking infrastructure', and how commercial incentives, public interests and individual agency will be balanced. A growing competitive and societal question is who builds, structures, protects and activates the data and context that assistants carry.
- The machine-readable layer could fundamentally reshape how institutions work with AI, not merely through chatbot subscriptions but through the systems people use across their workflows, devices and organisations.
- Interconnectivity enables more immersive experiences and real-time coordination, while highlighting the importance of resilience, cybersecurity, sovereignty, and dependency on the infrastructure providers that connect these systems.
- With humanoid robots, the service economy will eventually face the same technological pressures now reshaping knowledge work, just as the mechanised loom, the steam engine, the conveyor belt and industrial robots reshaped the relationship between machines, labour and human value.
- Synthetic connection may be valid on its own terms, but this does not resolve what happens to human relationships once the more demanding parts of them can be outsourced and the friction of social interaction bypassed. Cultural norms around technology have shifted before, and what will be considered taboo or socially permissible in an AI-mediated future is not clear today.
- The benefits and risks of AI-mediated systems will not be evenly distributed. Well-designed AI could lower barriers to expertise, education and sophisticated services, but access to high-quality compute, data, contextual knowledge and trustworthy systems may become an important source of inequality.
- Like past evolutions in digital infrastructure, AI will become part of the background conditions through which societies organise information, coordinate activity and make decisions. But infrastructure is designed and governed, and it matters who owns it. The future will depend on choices between open and closed ecosystems, cognitive augmentation and passive dependence, distributed and concentrated control, and different models of human-AI agency.

<!-- /context/megatrends/shifting-world-order.md -->

---
type: Megatrend
title: Shifting world order
description: The US-led unipolar order is giving way to a multipolar one in which no single power sets the rules and middle powers multi-align rather than take sides.
status: stable
use_when: "a plan for foreign coverage, international partnerships or technology suppliers assumes a stable rules-based order and settled alliances"
sources:
  - id: ref-megatrends
    resource: "CIFS (2026), Megatrends: The foundations of long-term change, chapter Shifting World Order"
---

# Shifting world order

## What it is

The structural erosion of the US-led unipolar order and its replacement by a multipolar configuration means that no single power holds uncontested authority over the rules, institutions and norms governing international affairs. The rise of China takes centre stage in the reconfiguration of the geopolitical arena, but an equally important part of the story is played by middle powers with newfound autonomy and diverging interests.

Since the end of the Cold War, American power, military, economic, cultural and technological, has dominated international affairs. That era of near-uncontested hegemony has ended. Different concepts and frameworks have been proposed to help understand the transition period where no clear successor architecture to the Western-led order has yet crystallised, including 'multipolarity' and 'multiplex world'. No consensus has so far emerged, perhaps owing to the uncertainties around how exactly this new constellation will look, what the relative power balance between states will be, and which institutions, if any, will govern.

## Sub-trends

- From alliances to pragmatic and transactional bonds
- Middle powers multi-aligning
- The rise of China
- Breakdown in governing mythologies (e.g. the rules-based order)
- Rearmament and global growth in military spending
- Technological leadership rivalry
- Old institutional order challenged

## Uncertainties

- Which new governing mythologies will become dominant after the transition?
- Will the Thucydides trap spring, leading to direct conflict between the US and China? (The Thucydides trap is the tendency towards war as an emerging power threatens to displace an existing great power.)
- How will the distribution of power between the world's multiple geopolitical poles be weighted?
- Will we see effective global standards and agreements to address cross-border issues, ranging from IP rights and standardisation to climate policy?
- Will democracy continue its global decline? If not, what might spark its revival?
- How will the declining legitimacy of Western institutions and frameworks affect the development paths of nations across the world?

## Drivers

- Some of the building blocks for this transition were laid decades ago. The early 21st century saw a high point in US imperial overreach with the invasion of Iraq without a UN mandate in 2003, after which the credibility of American global leadership and the rules-based order it championed began a steady decline.
- China's rise to an industrial, economic and military powerhouse, decades in the making, has facilitated its ability to mount a growing challenge to the Western-led order.
- Russia's newfound assertiveness came to a culmination with the full-scale war in Ukraine started in 2022, but its beginnings can be traced back to the incursion into Georgia in 2008 (and the preceding Munich conference in 2007) and the annexation of Crimea in 2014.
- In the West, the democratic decline witnessed over the last decade has eroded trust in the institutions established in the 20th century to provide the scaffolding of the post-WW2 world order.
- Taken together, what may have started as weaker signals of a potential transition have converged into the unravelling of the 'unipolar moment' that began at the end of the Cold War in 1991.
- Macroeconomic indicators support the shift. Measured across regions, the share of global GDP is amid a multi-decade shift from the Global North to China and emerging Asian economies. 'De-dollarisation', a reduction in the use of USD for international trade and financial transactions, is another signal that relative financial and geopolitical power is shifting away from the US, although this trend's future trajectory is highly contingent.
- Technological leadership is becoming a central axis of geopolitical competition, and China has emerged as a credible systemic contender. Over the past decade, China has moved beyond catch-up dynamics to establish leadership positions in artificial intelligence, clean energy technologies, advanced manufacturing and space capabilities, underpinned by state-led industrial policy, scale advantages in data and infrastructure, and an ability to mobilise capital and coordinate long-term strategic priorities. In solar photovoltaics, battery production and electric vehicles, China already holds dominant global market positions, while in AI and space it is rapidly narrowing gaps with the US. The EU is on a downward slope of relative innovation capacity in many of the same domains.
- China's Belt and Road Initiative (BRI) is both an economic and a geopolitical instrument. Through large-scale investments in infrastructure, energy and connectivity across Asia, Africa, Europe and Latin America, it has expanded China's economic footprint and deepened interdependencies with participating countries, and it facilitates the diffusion of standards, technologies and governance approaches aligned with Chinese interests. It reflects the emergence of alternative frameworks for global integration that operate alongside, or in competition with, Western-led institutions.
- The post-Cold War 'peace dividend', a relative decline in interstate conflict along with disarmament and reduced military expenditure across much of the West, enabled a reallocation of resources towards economic integration and domestic development. That period is now clearly ending.

## Manifestations

- Multi-alignment among middle powers. Türkiye, a NATO member since 1952, positioned at the intersection of Europe, the Middle East and Asia, operates within multiple overlapping spheres of influence, balancing long-standing ties with Western-led institutions alongside deepening economic, energy, defence and diplomatic relations with non-Western partners. Singapore hosts US military assets while refraining from directly supporting US goals in the region that run counter to Chinese ambitions, and participates in both China's BRI and the US-led Indo-Pacific Economic Framework for Prosperity. India is simultaneously a member of the Quadrilateral Security Dialogue with the US, Japan and Australia, a founding BRICS state, a longtime buyer of Russian arms and (since 2022) discounted Russian oil, and a vocal advocate of strategic autonomy as an explicit doctrinal term. Such behaviour expresses a wider pattern of states hedging risks, diversifying dependencies and maintaining room for manoeuvre where global power is more diffused and less predictable. Multi-alignment is becoming a structural feature rather than a novel phenomenon.
- Growing geopolitical agency and confidence in the Global South, evidenced in the willingness of countries in Southeast Asia, Sub-Saharan Africa, the Middle East and parts of Latin America to resist alignment pressures, assert independent policy positions and demand greater representation in global governance institutions. Legitimacy is no longer conferred primarily by Western-led institutions but increasingly negotiated across a broader and more diverse set of actors, visible in UN General Assembly voting data where alignment of many Global South countries with Western goals is now less pronounced.
- Global democratic backsliding and the growing appeal of more autocratic forms of government, although whether this is a contributing cause, a symptom, or both, is an open question. According to the V-Dem Institute, the number of countries autocratising rose from 12 in 2004 to 45 in 2024, while countries democratising fell from 26 to 19. Features of strong liberal democracies like freedom of expression and quality of elections are on a global decline. The US is amid a decade-long democratic backsliding trend, with attacks on the judiciary, the abolition of accountability institutions, military purges and attacks on the freedom of the media as key contributors. Democratisation is highly historically contingent, its strongest waves flowing from changes to geopolitical power dynamics.
- The breakdown of the governing mythologies that have underpinned the international order for decades. One is the association between liberal democracy and 'the good life': while levels of democracy have decreased globally, the provision of public goods is on the rise across both illiberal and democratic states. Another is the 'rules-based international order', which some argue was always at least partly a mirage, a set of norms and institutions designed to provide legitimacy to powerful states acting out of self-interest. Recent events in Gaza, Ukraine and Iran, and the different responses to them, have illustrated that Western appeals to a 'rules-based order' differ from appeals to 'international law' as administered by the International Court of Justice and the International Criminal Court. The same US House of Representatives that welcomed ICC proceedings against Vladimir Putin voted in favour of the Illegitimate Court Counteraction Act to sanction ICC officials over arrest warrants for Benjamin Netanyahu and Yoav Gallant. Invoking 'the rules' while applying them selectively deepens perceptions of Western hypocrisy. The legitimacy of supranational governance is also counteracted by China's position, which emphasises the primacy of consent and the supremacy of state sovereignty.
- The growing appeal of non-Western governance frameworks, such as BRICS and Global East forums and the Mecca Defence Alliance between Türkiye, Saudi Arabia and Pakistan, constitutes an intensifying legitimacy contest over whose norms, institutions and governing mythologies get to define the international system.
- Military spending is rising globally, with significant increases across Europe, Asia and the Middle East, reflecting a renewed focus on deterrence, territorial defence and strategic competition.
- The nature of conflict is expanding beyond traditional domains to include cyber operations, economic coercion, weaponisation of migration and information, and technological rivalry. Space is emerging as a new frontier of great power contest, marked by growing militarisation and competition. The 1967 Outer Space Treaty faces growing strain as spacefaring nations prioritise military applications, and space is a site of competition for resources needed in such large quantities that transportation from Earth is not feasible. As national space agencies and private enterprises establish permanent settlements on the Moon, they may become increasingly controlling over access to certain natural resources found there.

## Implications

- These developments point to a structural transition away from an era defined by expectations of peace and towards one where conflict, both direct and indirect, is a more persistent feature of the international system.
- Conflict does not need to be the inevitable conclusion to a contested transition. The alternative is painful adjustments and negotiated accommodation by the world's new hegemons and the new cast of middle powers. Some will need to accept a diminished role while others must exercise restraint in their newfound influence and agency.
- Whether the right balance can be struck will be among the defining questions of the coming decades, shaped not only by Washington, Beijing and Moscow, but by the cumulative choices of the dozens of states now hedging between them.
- A key question is whether one set of institutions and narratives will dominate or whether the field will remain contested.
- Standards, platforms and innovation ecosystems may increasingly diverge along geopolitical lines as the technological order becomes more contested.

## Figure: Formal Bilateral Influence Capacity of three middle powers, 1991-2023

Three stacked line charts sharing a common time axis from 1990 to just past 2020, with a shared vertical axis labelled total FBIC. The United Arab Emirates rises from just above zero in the early 1990s, climbing steadily through the 2000s to roughly 6 by the early 2020s, the steepest of the three. Indonesia begins near 1 and rises only gently, to roughly 2-3 by the early 2020s. Türkiye begins near zero, rises through the 2000s to around 5 by 2015, then continues up to roughly 7-8 by the early 2020s. Formal Bilateral Influence Capacity measures the capacity for influence between pairs of states across economic, political and security relationships. By this measure, countries like the UAE, Indonesia and Türkiye have seen their influence in the international system increase since the end of the Cold War, demonstrating the growing agency of middle powers in a more fluid geopolitical environment.

<!-- /context/sector/ai-adoption-and-literacy.md -->

---
type: Claim
title: AI adoption and literacy
description: AI adoption is shallower and more fragmented than organisations believe, with ownership unclear and much use happening in the shadows.
status: stable
use_when: "a plan assumes staff already use AI widely and well, leaves adoption, training and shadow use unowned, or depends on how people read, question, feed and set up AI assistants"
sources:
  - id: interviews
    resource: interview programme with media organisations, 2026
---

# AI adoption and literacy

## Practices

- Individuals in technical, data or development roles have started building AI workflows for the business on their own initiative, often because their role puts them close to data or platforms. (9 mentions)
- Shadow AI use is widespread and often a workaround for sanctioned tools that lack system access or capability: journalists build and share their own custom GPTs, sales teams use whatever they like, marketing staff prefer external tools, and some paste restricted data into public tools. (7 mentions)
- Organisations run staged AI-literacy surveys starting with senior management to signal that AI is an organisation-wide matter, map tools and tedious tasks, reinforce staff curiosity rather than mandating courses, and expect technical material that works for a small literate group to confuse a wider audience. (6 mentions)
- Experienced users treat context as the working material. They keep track of what the model knows and does not know at each point, expect more from supplying the organisation's own knowledge than from a better model, and want a tool to spend its first exchanges asking for context before it advises. (4 mentions)
- Ideas travel between organisations at industry events; leadership groups find role-based customisation of AI tools compelling. (2 mentions)
- Coding productivity with AI agents is reported to improve by half or more; whether this means fewer developers or the same people doing far more is contested, and automation of heavy manual review work is framed as freeing staff time rather than replacing them.
- Where a good sanctioned tool exists, a large majority of editorial staff use it regularly, especially when they can tailor prompts to their own needs.
- Research on generative-AI adoption across organisations finds similar patterns, including reliance on internal ambassadors to explain the technology.
- People who use assistants daily report reading less of what they are given: long answers are skimmed rather than read, and short, structured ones are preferred. Where the tool itself suggests the user's next reply, accepted with one keystroke, the answer is skipped altogether and the user is out of the loop, which removes the friction from the exchange.

## Constraints

- Most media organisations are not set up for the newer ways of extending an AI assistant. Many are held to the single office assistant they already have, the one in which least can be done; installing a skill defeats even experienced users; and code-hosting platforms are a hill to climb for anyone non-technical, so one address to connect to is far easier to adopt. (5 mentions)
- Responsibility for adopting new tools and processes is unclear; where no one owns adoption, use fragments, and access decisions get made informally by individual managers. (4 mentions)
- Every new AI tool or feature increases complexity and load on the functions that handle security, integration, support and adoption; IT work has become far more reactive as employees introduce tools on their own initiative.
- There is no shared understanding of basic AI concepts inside organisations; asking colleagues to define an agent produces many different answers.
- AI initiatives reach good results on the first seventy per cent quickly, but reaching a quality level that can replace human work takes far more tuning than expected, delaying strategic value by a year or more.
- Because chat assistants write so fluently that their text cannot be told from a person's, users find it strange when another AI tool makes ordinary errors, although generative AI is never perfect. The fluency has blurred the understanding of AI as a tool, and people have to be pushed to think differently about new products.

## Needs

- Media organisations need someone able to follow developments at AI-native companies and frontier labs and translate them into the organisation's own environment.
- Technology is accelerating faster than people and organisations adapt; employees need time, permission and practical opportunities to develop a mental model of how AI can improve their work.

## Beliefs

- Organisations and their staff perceive internal AI adoption to be more widespread and mature than it actually is; the impression is skewed by highly visible AI-engaged voices, and leadership often initially rejects a more sober assessment. (7 mentions)
- Getting people to use new tools requires building a supporting culture and deliberate rollout choices such as workshops and demonstrations, not simply handing over the tool. (5 mentions)
- General AI assistants go straight to a solution. They are not built to raise questions or to deal with ambiguity: they assume from whatever context they hold, and what the user overlooked they decide on the user's behalf. People who work with them every day describe this as a weakness, and value a question that shows them what they had taken for granted. (5 mentions)
- AI is used for innovation because it is a major accelerator for getting things done, but the more basic work is understanding data activation across the organisation first; organisations discuss needing to become interoperable with AI systems to stay relevant yet are not ready.
- Cross-organisation collaborations on AI have been rewarding but depend on someone consistently taking the lead.
- The industry splits into three camps: those still debating whether they may use basic tools, 'tool collectors' who bolt many AI tools onto legacy workflows for efficiency, and a small group of 'rebuilders' redesigning workflows and roles from first principles.
- Early adopters are estimated to make up only three to five per cent of an organisation or market.
- Democratising AI and innovation requires more than access to technology: education, recognising that editorial staff have the ideas, easy platforms, ownership, human competencies, psychological safety, knowledge-sharing and integrated user feedback.
- Newsrooms have many unknown unknowns, and AI is weak at finding radically new ideas; it is better at synthesising and at brainstorming up to a point. In early idea work it carries a second risk: what an assistant has once put in front of a team cannot be unseen, and can corner the work onto a path that may not be the right one.

<!-- /context/sector/ai-systems-and-governance.md -->

---
type: Claim
title: AI systems and governance
description: A minority have built layered AI platforms while most stay unconnected to internal systems, and data protection, regulation and fear of surveillance decide what can be used and shared.
status: stable
use_when: "a plan connects AI to internal data or archives, or builds a shared AI tool, and meets data protection, EU compliance, security review or staff fear of surveillance"
sources:
  - id: interviews
    resource: interview programme with media organisations, 2026
---

# AI systems and governance

## Practices

- Some organisations deliberately stay model-agnostic and multi-model, treat chatbots as one interface among many, and run retrieval-based systems over their archives or distribute journalism into conversational AI environments as a channel. (12 mentions)
- External tool builders are moving from standalone chatbots to protocol-based integrations and constellations of several tools, including ones that stress-test plans and push back on ideas. (4 mentions)
- Some organisations invest heavily in keeping sensitive data in-house, isolating test environments for frontier tools and building internal tools where data cannot legally be shared with third-party services.
- Some organisations have built a layered AI platform, combining shared data infrastructure, an agent-building layer and specialised interfaces, with chained workflows from monitoring through drafting to distribution.
- Editorial colleagues are well placed to judge whether an AI idea is editorially sound when the data work is already involved in their day-to-day.
- Colleagues delegate routine email to agents that auto-answer, and meeting notes are taken by integrated AI agents; organisations should expect more such delegation.

## Constraints

- Staff are wary of a shared organisational tool exposing their interactions: unsophisticated questions, chat histories in projects with internal politics, or individual-level scoring of innovation performance feel like surveillance and would discourage use. Willingness to share depends on trust, and anonymising contributions risks losing an individual's distinctiveness. (8 mentions)
- Security perspectives distinguish individual experimentation at personal responsibility from organisation-wide implementation, which requires governance over which data a solution may read, who may write and read, what rights an agent receives, and separation between departments; organisations prefer personal and sensitive information hosted in-house and cannot observe individual AI use beyond network traffic. (8 mentions)
- Organisations face a dilemma between testing frontier tools and complying with European regulation: compliance status changes quickly, tools previously used have been ruled non-compliant, any AI tool may need a formal approval regime, and even meeting-recording practice is questioned. (5 mentions)
- What is built for one assistant tends not to carry over to another, and which model answers is increasingly not the user's choice: providers route between their own models, free accounts get the lesser ones, and company accounts drop to a cheaper model once a limit is reached. Making a tool behave the same everywhere is described as an uphill battle. (3 mentions)
- Staff lack the capacity to verify changes an autonomous agent makes on their behalf, and the resulting structures can become hard to track; security advisers warn that an agent's actions cannot be fully predicted. (2 mentions)
- Whether productivity tools may read staff email to organise their day is an open legal and compliance question. (2 mentions)
- Mixing very different roles' data, such as marketing and editorial, could pollute shared organisational learning and make it unusable for either group.
- Current generative models are poor at distinguishing between versions of similar content and at judging when differences matter, limiting their usefulness for surfacing the right version of institutional knowledge.

## Needs

- Organisations plan to expose internal databases through protocols or APIs so tools can be built on top, structure and centralise data before analysis, and link project, issue and performance data into a layer that tracks how initiatives perform. (11 mentions)
- Organisations want AI involvement in work to be transparent and traceable, since a lack of traceability is itself a problem in current AI-assisted workflows. (3 mentions)
- Participating organisations need clarity about what co-creation commits them to and an explicit clearing step before anything said travels further. (2 mentions)

## Beliefs

- Security review can stop an innovation project even when the issue is solvable; some practitioners argue security should not be the top priority for an innovation department's tool, while others list tight access management as a requirement. (4 mentions)
- Some organisations block AI crawlers as a strategic signal that media content should not simply be collected by external AI actors, treating control over content and data as a significant strategic theme.
- The AI-native ambition is not small applications such as summaries but a different operating logic: virtual co-workers, multi-agent systems and specialised skills that let a small team or a single journalist do far more; the strategic priority is the system and architecture around the model rather than the model itself.
- A platform philosophy in use is to build platforms that let people build their own solutions rather than having a central team build everything.
- Tools that hold context and prompt the user unasked, for instance by asking whether yesterday's discussion was followed up or feedback has come in, are described as a game changer in how people work with AI, compared with tools that wait for a question.

<!-- /context/sector/culture-and-psychology.md -->

---
type: Claim
title: Culture and psychology
description: Fear, consensus-seeking and a newsroom built for accuracy rather than error make experimenting with undefined futures feel unsafe.
status: stable
use_when: "a change or experiment meets fear for jobs, a newsroom built for accuracy rather than error, or consensus-seeking that makes the safe choice the default"
sources:
  - id: interviews
    resource: interview programme with media organisations, 2026
---

# Culture and psychology

## Practices

- Startup-style principles, acting on an idea at once and saying no wherever possible, shape some organisations' early culture.

## Constraints

- A cultural commitment to journalism as it is, and the trust that news depends on, make radical experiments with format feel like a break in identity. (4 mentions)
- Some employees actively resist AI because they fear it will take their job; this fear is psychological rather than technical, confronts people with questions about their security, and cannot simply be talked away. (3 mentions)
- Many teams keep running a familiar, comfortable routine even when it is not the best long-term approach. (2 mentions)
- Where staff turnover is low and hiring and firing are constrained, culture must evolve the people in place, which is slow and needs sustained resourcing; organisations must also keep serving user groups still on existing formats.
- Highly compliant, rules-driven cultures produce continuous improvement but almost no real innovation, ideas failing on 'not invented here' once they must scale; with nearly all staff oriented to routine operations, expecting otherwise without changing that reality is pointless.

## Beliefs

- Danish media innovation culture is seen as less diverse and more conservative than elsewhere in the Nordics: recruitment draws on known networks and legacy structures, media professionals are rarely trained in structured methods, and organisations with a high average age struggle to understand younger users. (6 mentions)
- Psychological safety is the foundation for experimenting with undefined futures: people need to feel safe raising half-formed ideas and asking naive questions, otherwise they simulate experiments with predefined success criteria; explaining the 'why' and curating positive, curious spaces made the biggest difference in real changes. (6 mentions)
- Where readiness has been built over time, even radical change meets little resistance provided staff were involved throughout; involving staff early in how AI is used works better than informing them afterwards, and ownership through involvement is distinct from making the strategic decision. (6 mentions)
- Some teams place high value on sharing knowledge openly and being open-source. (4 mentions)
- The debate about AI in media is held in binaries, replacement or not, made with AI or not, and says too little about how people and AI should work together. What matters is how AI is used, and a tool that sharpens an idea and shows its owner what they do not see is given as an example of AI helping a person, not replacing one. (4 mentions)
- The biggest cultural barrier is that newsrooms are built as accuracy machines and lack 'permission to be wrong', whereas innovation requires testing hypotheses that may fail; rigorous AI literacy turns fear into agency, and an organisation cannot assume every employee will move at the same pace. (3 mentions)
- Spreading a new way of working requires evangelists who carry the message through the flow of information; exciting the top of an organisation is necessary but not sufficient, and the people dealing with AI day to day need a practical sense of what is happening. (3 mentions)
- Innovation fails on human resistance to giving up what has worked: consensus-seeking, social proof and loss aversion make the safe choice the default. Protecting radical thinking is therefore a choice-architecture problem; experiments must be low-friction, future thinking made the default, and techniques such as pre-mortems and reference-class forecasting used against optimism bias.
- The word 'innovation' can be absent from an organisation's vocabulary or actively resented on the newsroom floor as consultant-speak; abstract, jargon-heavy packaging triggers instant scepticism, even where the underlying substance framed around concrete needs is welcome.
- Internal innovation processes are not designed to create habits and momentum, lacking triggers, variable rewards and investment loops, so people engage only when it fits their existing mental model; the gaming industry is an underrated case of deep user involvement and forced iteration.
- In principle everyone can be an innovator; organisations should involve as many people as possible, identify early innovators and give them mandate and resources.
- What matters in internal communication is feeling seen; an obviously AI-generated, generic reply from a colleague reads as not having been looked at.
- A tool that challenges is put down when its friction makes the user feel stupid: conclusions drawn too fast and provocation that seems deliberate frustrate and leave nothing to act on. Questions that guide the user towards something they can do are taken up.

<!-- /context/sector/horizons-measurement-and-priorities.md -->

---
type: Claim
title: Horizons, measurement and priorities
description: Operations absorb the attention long-horizon work needs, and radical and incremental work are judged on the same near-term return, so long-term bets are deprioritised and stifled.
status: stable
use_when: "long-horizon or radical work is judged on the same near-term KPIs and return as operations, or the question is how to measure and prioritise it"
sources:
  - id: interviews
    resource: interview programme with media organisations, 2026
---

# Horizons, measurement and priorities

## Practices

- Some organisations keep objectives at the operational level, treat depth of reading rather than a surface metric as the meaningful engagement signal, and categorise performance signals into editorial, funnel, conversion and cost, noting retention as a missing category. (4 mentions)
- Impact of innovation work is currently assessed by gut feeling rather than a defined metric, with formalisation deferred.

## Constraints

- Existing processes, structures and people absorb organisational attention, so the organisation must keep running today's business while creating capacity for a different future model; too much innovation starves operations and too little runs the organisation into the ground. (5 mentions)
- Practitioners fear that whatever is built gets pulled back into short-term operational framing; organisations cannot jump to long-horizon futures work without formal and cultural foundations, since leadership and colleagues need concrete results before engaging with abstract or radical discussion. (5 mentions)
- Most newsrooms work only in the first horizon. Where they explore the second, it is without stated objectives or a reason beyond having to try a few things, and the third, where the largest effect is expected, is mostly left alone; work on the long horizon has hardly been seen in the media industry. (3 mentions)
- Innovation and experimentation are structurally deprioritised in favour of operations because they do not visibly create bottom-line value from day one, unlike converting subscribers or publishing a good article. (2 mentions)
- Organisations had more slack before successive cost cuts, when media felt like a lifestyle and the path from idea to test was short; a culture where long-tenured staff can ask why things are done a certain way, and an external threat sustaining urgency, are credited for innovation culture, yet organisations question themselves more than they act.
- Timing is a central problem for long-horizon initiatives: they can be too early or too late, technologically possible but organisationally immature, or right for a future shift but impossible to anchor now.

## Needs

- Most organisations have not yet reached the point of dedicating resources to longer-term research and future preparation, though some intend to work toward it. (2 mentions)
- Open questions from practitioners about measurement: whether degree of innovation can be scored and at what level, whether the number of innovations per department should be made visible to stakeholders, what data is accessible with what margin of error, how to keep analysis future-oriented, and how to know how close a project is to its goal.

## Beliefs

- Innovation fails when radical and incremental work share the same governance and KPIs: long-term work gets measured on short-term return and is stifled. Organisations should run both in parallel as distinct disciplines, measuring incremental work by KPIs and radical work by hypotheses and learning, but most lack the structure to operate two logics at once. (8 mentions)
- The print-to-digital transition is the precedent: new activity treated as a marginal experiment while the legacy business keeps attention and power. Several organisations therefore separate radical work from the core, as a spun-out unit, a fully isolated fast track or a small 'speedboat' beside the 'oil tanker', and merge it back only once it dominates. (7 mentions)
- A three-horizon logic in use: H1 with short horizons, clear ROI and focus on the existing business; H2 connecting new initiatives to products and scaling; H3 as light, cheap experiments under high uncertainty where traditional measures fail and metrics should track learning, assumptions tested, speed to experiment and the ability to stop or promote initiatives. Visible H1 wins are used to earn permission for H2 and H3. (7 mentions)
- Innovation in media is too often optimisation disguised as innovation: the existing approach is improved but its premise never questioned; organisations are better prepared for sustaining than transformative innovation, which requires changing how journalism is produced and how humans and machines combine, not isolated experiments. (7 mentions)
- The dominant measure of success for new initiatives is near-term savings in time or money and a demonstrable business case; even projects with UX and technology ready can lack prioritisation because leadership funds what saves money now, and for top management the bottom line comes first with culture treated as secondary. (4 mentions)
- Organisations tend to bet everything on a single AI tool and stop if it fails; the alternative is many light, cheap parallel experiments with clear metrics, stopping quickly where there is no potential and reinvesting behind what succeeds. (4 mentions)
- Evolutionary, step-by-step change management remains useful but can be too slow relative to the pace of technological and market change.
- Whatever a media organisation builds with AI should launch within a couple of months rather than as a long theoretical build, because audiences are already far ahead.
- Traditional reach metrics such as page views measure a container of consumption that is shifting as human visits decline and AI-agent visits rise; a new paradigm centred on usefulness and retrieval is needed, and the right KPIs differ by type of organisation. The Nokia analogy is used: measuring a categorically new thing against old metrics.
- Practitioners accept a meaningful margin of error in data and would work with an assistant that is right roughly nine times in ten.
- At the scale of the whole organisation a single piece of work has negligible cost and value; zooming in to effort changes the picture.

<!-- /context/sector/innovation-process.md -->

---
type: Claim
title: Innovation process
description: Ideas in media organisations arise informally and die for lack of a route to decision, an owner, or room to iterate.
status: stable
use_when: "an idea or project lacks a route to decision, an owner or room to iterate, or the team is designing how ideas move from proposal to production"
sources:
  - id: interviews
    resource: interview programme with media organisations, 2026
---

# Innovation process

## Practices

- Most processes start from unexamined assumptions that sit as a shadow over innovation work; a few practitioners use assumption testing individually rather than as a shared method, and organisations want a tool that surfaces, structures and visualises the assumptions in project material so a team can test them systematically. (7 mentions)
- New ideas typically originate with a journalist, from a problem, or from inspiration seen at another organisation, online or at a conference; they arise from several siloed directions rather than one shared structure, get discussed informally until they gain verbal traction, and are shelved quickly if the responsible manager lacks capacity. (6 mentions)
- Live conversational-listening tools that mirror themes, tensions and decisions from a discussion are being prototyped and expected in mainstream collaboration platforms; AI has been reported to outperform humans at spotting outliers across large interview sets. (3 mentions)
- Some development processes are heavily iterative, with regular review of what works, and look to the software world and agile approaches for method. (2 mentions)
- Some organisations run a structured involvement cadence, with recurring idea-and-investment meetings and periodic all-staff development sessions, and a looping process from need through idea, involvement, decision, execution and evaluation feeding back into a shared record of what has worked.
- Practitioners run unsanctioned 'guerrilla' projects, building a quick MVP first and pitching leadership only once the use case is compelling, because formal processes would have meant the projects never happened; this becomes harder as processes formalise, and greater transparency of decision-making would make it impossible.
- Some staff hide their AI use from colleagues out of embarrassment, and unstructured output from humans predates AI.
- Reviewing a product a year after launch surfaces material for reconsidering the approach; practitioners argue such discovery should be continuous on everything the organisation builds, so it stays focused on committed priorities instead of many small uncoordinated initiatives.
- Small technical projects that worked from day one struggle to get follow-through for lack of time and anyone available to roll them out; promising automations go unadopted pending migrations or because outcome quality is uncertain.
- AI assistants are already routinely part of individuals' idea-generation, with many recent solution ideas developed in dialogue with an assistant rather than alone.
- Where work can be reused for a new platform, the path from idea to decision moves quickly, though this is not true of most innovation work.
- Early experiments rarely produce a finished product but build competencies, readiness, networks and a shared language, and the ability to react quickly when a shift accelerates.

## Constraints

- Good ideas often go nowhere because there is no clear route for who to bring them to; people feel alone with their ideas, ideas die inside large internal programmes before reaching senior leadership, and internal advocacy for change gets encouraging feedback and then silence for months. (5 mentions)
- Ambitions to work iteratively turn into a waterfall model roughly nine times out of ten, because waterfall is ingrained, easy to relate to and forced by time and resource pressure; there is little room to iterate and test, discovery is unstructured, there is no consistent way of working, and temporary fixes become permanent.
- In a typical editorial-product workflow an idea is discussed with the manager, involves many staff in workshops, proceeds on the promise of savings, and either strands for lack of prioritisation or survives only because a specific desk carries it; choosing among many possible paths and arriving at a deployable product are challenges in themselves.
- Organisations do not talk to their users directly enough and are reactive about innovation, acting only once a problem has surfaced; they assume what users want or ask in ways that confirm decisions already made, even though behavioural data is more honest than focus groups.
- Proposals discussed with editorial teams and managers often receive no clear, unambiguous yes; vague responses from leadership create a recurring pattern of unclear buy-in.

## Needs

- Prioritised requirements for an innovation sparring tool: frictionless, simple, valuable on first use, secure, cheap, platform-agnostic, restrictable to a small group, able to challenge assumptions and give concrete future-oriented recommendations, able to work across horizons, hackable, role-adaptive, source-transparent, visual where assumptions and management communication are concerned, and able to play a provocative devil's advocate that imposes constraints. (7 mentions)
- Organisations cannot do everything themselves and would value outside help connecting the dots between initiatives, surfacing practices and ideas from outside the media industry, and simulating how audiences or advertisers might respond to a proposed idea. (3 mentions)
- A check of the assumptions behind an idea belongs at the very start of product development, as a required step among the other checks an idea must pass, before anything is written down. Few people in a news organisation have the time to think a plan through, and leaving the check to each product manager's choice is not expected to work. (3 mentions)
- Experiments need portfolio management: an explicit mechanism to see which experiments exist, which horizon they belong to, what resources and metrics apply, which to stop or scale, and how to move them between horizons, since long-horizon work does not land in the next horizon automatically and areas such as AI move faster than expected.
- To keep innovation projects alive as they near their goal, practitioners propose status updates, reminders, agent support for building a pitch, quick demonstrations on the organisation's own stack, sparring for good process and help qualifying decisions and convincing leadership.
- Open questions at each stage of a proposed innovation process: vision and anchoring at the need stage, language at the idea stage, how many to involve and how to present work, and resourcing, return and KPIs at the decision stage.
- Practitioners want a tool that intervenes partway through an innovation process, before resources are spent, to redirect processes heading for the wrong result, and want to map how their process actually works today and where its pain points sit.
- Analysts want to automate personalised insight delivery to editorial desks and surface patterns they would not see in raw numbers, and internal chatbots over policy documents with human escalation are proposed.
- Practitioners want ready-made building blocks that already work rather than building from scratch, noting that a large share of what counts as innovation never reaches production.

## Beliefs

- Editorial is often the biggest bottleneck for change: organisations with AI-ready data foundations did not act for lack of leadership interest, and editors of the old school block changes to established formats on the assumption that readers want what they are used to and that the organisation knows best.
- Some staff frame the desired outcome as an internal community where ideas spark off one another rather than a revenue tool, while questioning whether people are willing to share ideas at all, which they frame as a question of ownership over ideas.
- Value-driven organisations with a clear mission and journalists retaining unique human expertise are believed to have a viable future; an AI cannot replace a specialist's twenty years of accumulated knowledge though it can support parts of the task.
- Innovation processes are changing because a working prototype can now be built fast enough to bring a test group to leadership within weeks, whereas many good ideas historically stalled on not knowing how a proposal reaches leadership.
- A tool that only draws on one team's history risks becoming an echo chamber that keeps re-solving the same systemic problems; insight into other teams' problems is what would let a team change direction.
- Whenever the organisation commits to a new bet it should set clear objectives and articulate what it expects; once goals are set, an AI agent nudging the organisation toward that shared direction is welcome.
- Journalists prefer not to write routine data-driven items that could be generated from good data, preferring to go and talk to the people involved.
- It has to be cheap to fail. A quick prototype in people's hands gets a response at once and says far more about the real need, what can be done and where the potential lies, and its failures hold that information. In older IT projects a failure was a catastrophe, because half a year and millions had already gone into it.

<!-- /context/sector/innovation-structures.md -->

---
type: Claim
title: Innovation structures
description: Organisations try labs, spin-offs, small cross-functional teams and recurring forums, and most struggle to carry ideas through to production.
status: stable
use_when: "the organisation is choosing where innovation should sit, such as a lab, spin-off, cross-functional team or forum, or struggles to carry ideas into production"
sources:
  - id: interviews
    resource: interview programme with media organisations, 2026
---

# Innovation structures

## Practices

- Organisations that succeed at long-term innovation rely on cross-functional teams on clearly defined problems, embed innovation in daily operations, give teams a mandate to test quickly, protect recurring cross-disciplinary time, run incremental work in sprints, and structure themselves around experiments rather than production. (11 mentions)
- Several organisations have set up small cross-departmental AI teams working across desks, with editorial perspectives included as needed, self-organising around existing roles with protected time for the work, and given either a cost-saving goal or a deliberately ambitious one. (10 mentions)
- Recurring, open, informal AI dialogue forums without agenda or minutes can grow quickly and be copied across departments; building cultural 'frequency' around AI through such formats is where some organisations invest most energy. (8 mentions)
- In current data and automation workflows an external request form is ranked by project leaders, developers are brought in late so information is lost, and communication runs through intermediaries; participants sketched a future state where the developer goes out proactively to understand problems and connects requests to existing ideas.
- Spin-off companies from internal innovation can grow to serve external markets, at which point they grow away from the parent's needs and take the people who built them, making the pattern hard to sustain.
- Peer organisations across the Nordics have historically struggled to collaborate because priorities rarely align, though the AI shift is prompting more contact; bringing in high-profile external experts to present scenarios to large leadership groups is effective at paving the way for perspectives insiders struggled to convey.
- Some organisations use no formal innovation process and consider their lived daily culture their primary innovation tool; they have no innovation group and do not label their work innovation, which makes a pluggable innovation toolkit hard to picture.
- Adjacent fields show a contextual assistant can open doors to a process, support drafting and translate complex arguments for decision-makers, not only give advice.
- Protected morning focus blocks with no calls or email, and deliberate breaks, are used to create room for thinking; structured reflection is an organisational capacity many organisations lack.
- Where no structure around innovation existed, establishing one within a few years meant ideas were carried forward rather than lost; innovation leads offer themselves as a contact point and propose communities for dialogue about innovation.

## Constraints

- Large research-based innovation partnerships struggle: broad partner bases and heavy formal change processes are innovation-killing, and framing everything around responsibility sits in tension with fast continuous improvement.

## Needs

- Where innovation work should be formally anchored within a media organisation is an unresolved question with no shared internal view; the most siloed organisations, where different editorial units think in completely different ways, would need a significant push to adopt a shared framework. (4 mentions)
- A good local prototype is not sufficient; organisations need an internal ecosystem in which solutions can be implemented and scaled across the organisation.

## Beliefs

- 'Innovation theatre', labs, reports and experiments that display activity without producing change, is a recognised risk, as is a tool nobody uses or a framework that ends up as a PDF filed away; a product does not by itself create a long-term mindset. (5 mentions)
- A lab inside the organisation is seen as unable to drive transformative change because existing systems are too slow; a separate AI-native unit is argued to get a clearer mandate, resources and the chance to design processes from scratch.
- Hackathons and ideation weeks generate enthusiasm and concrete ideas across departments, but follow-through is weak: ideas rarely reach production, editorial representation is thin, and it is unclear what to pause and what to prioritise afterwards.
- Innovation success ultimately depends on the people carrying it forward; it produces changes in thinking more than direct revenue, emerges in clusters, and in uncertain times organisations should rely on iteration and hypothesis-driven learning rather than fixed structures.
- Experimental units have been closed in reorganisations after failing to produce enough or to communicate their value; the lab model lost support in favour of experimenting inside products, which pushed innovation toward incremental work, though early experimentation left a higher AI maturity.
- Bringing in talented people is not enough without a pipeline that turns ideas into visible outcomes, or recruits leave as fast as they arrived; restricting a new tool to a small chosen group makes adoption far easier than an organisation-wide rollout.
- What happens in practice often differs from stated ambitions, and organisations constrained by the pace they feel they must keep keep doing things the way they are used to; outside inspiration is welcomed as a way out of that pattern.
- Change is most effective when it comes from the organisation's periphery rather than its core.

<!-- /context/sector/leadership-and-mandate.md -->

---
type: Claim
title: Leadership and mandate
description: Innovation depends on a few individuals and on leaders whose interest, incentives and measures rarely favour long-horizon work.
status: stable
use_when: "long-horizon work needs leadership buy-in, a mandate or resources, or depends on a few individuals whose departure would take the capacity with them"
sources:
  - id: interviews
    resource: interview programme with media organisations, 2026
---

# Leadership and mandate

## Practices

- Building leadership buy-in involves joint presentations, stress-testing the pitch against a strictly numbers-focused stakeholder, and investing time to understand collaborators' differing needs in a complex multi-stakeholder structure; teams can wait a long time to get an audience with senior management. (3 mentions)
- Some organisations experience their constraint as time and resources rather than culture or structure, and see their competitive advantage as speed: a short distance from spotting a need to acting on it, fast decisions on partial information, ideas resolved informally. They fear any formal innovation tool that slows this down, and note the industry's low tolerance for friction.
- Presenting current and future AI use to leadership prompts employees to bring forward their own ideas but also overwhelms some; innovation leads count more failures than successes and see the minimum value of a shared horizons vocabulary as letting leadership acknowledge where the organisation is not yet operating.

## Constraints

- Innovation drive is concentrated in a few key individuals; ideas survive because a specific person carries them, and when that person leaves the capacity goes with them, which is a reason to formalise tacit process knowledge and move from person-dependent to collective innovation. (7 mentions)
- The largest barrier to futures-oriented innovation is human: culture, leadership, understanding and will. Long-term success depends on who holds decision power, what they are measured on, and whether a leader can justify diverting resources from operations and defend investments with no return in the next quarter. (4 mentions)
- Leadership is often absent from innovation work, so decisions get reduced to simple commercial questions; friction also arises from different leaders owning different parts of the organisation.
- Framing AI mainly as a cost-cutting lever, premised on how many editorial staff could be made redundant, makes the work impossible to introduce without provoking fear.
- Incentives at the top are structurally misaligned: a leader whose tenure will end before long-term risks materialise does not feel their urgency.
- Organisations publicly insist no one will be laid off while restructuring continues regardless, leaving staff distrustful of messaging about transformation already under way at the strategic level.

## Needs

- Innovation often happens only under clear pressure; to create legitimate urgency before a crisis is visible, leadership must be able to explain why the existing model is under pressure, which shifts could be decisive, what is risked by waiting and by investing too early, making uncertainties concrete without artificial panic. (4 mentions)
- Innovation across organisational boundaries needs an incentive structure that lets people dare to cross them, clarity about the gatekeepers, and a culture that is open without becoming too collective or uniform. (3 mentions)
- Long-horizon work must be communicable to management and the board: arguments linked to strategy and risk, a visualised portfolio, relevant metrics, small experiments presented as risk reduction, and language for uncertainty that does not sound vague; innovation leads want a tool that helps them present where the organisation is heading. (3 mentions)
- Board and top management must be committed to moving innovation between horizons and must understand, believe in and personally use any tool, translated into their own language and connected to concrete decisions; without ownership at the top, long-horizon work becomes isolated.

## Beliefs

- New solutions only create value if they are simple to implement, sit inside a familiar work situation and give the user a clear early 'wow moment'. (7 mentions)
- Established companies rationally allocate capital to their best customers and underinvest in disruptive innovation, retreating upmarket when threatened; transformation cannot show on a quarterly cycle and boards lack patience for eighteen-month cycles, and while a 70-20-10 allocation is cited, organisations land closer to 99-1-0. (6 mentions)
- The real barrier to senior decision-makers keeping pace with AI is not lack of time but lack of interest or a cautious mindset; some senior figures lack basic understanding of what the tools can do, and keeping pace ought to be treated as a decision rather than something crowded out. (3 mentions)
- Adopting a provocative, future-oriented tool depends on leaders having enough capacity to tolerate being shown that current practice may be wrong; buy-in requires a clear 'what's in it for me', an open mindset and willingness to relinquish control. (2 mentions)
- Senior leadership frames the situation as 'change or die' or 'adapt or die': the organisation cannot run its business for another five years as it has, and the decisive factor is the will to act and learn through implementation rather than having ideas.
- Innovation leaders often see their own strength as making change happen in phases rather than spotting opportunities first.
- The open question for the industry is whether it can build capabilities, culture and structure in time, which may require centralising power and taking decisions unpopular with journalists; media leadership is rarely trained in structured methods and needs more diverse backgrounds.
- An organisation's central challenge cannot be solved by AI alone, since AI has no intention of its own; the underlying issue is organisational clarity about purpose and trust rather than processing speed.
- Making innovation decision-making too collective, standardised and top-down with a near-term cost focus kills experimental ideas before they can live, unless they already have supporting data.

<!-- /context/sector/organisational-memory.md -->

---
type: Claim
title: Organisational memory
description: Institutional knowledge sits in individuals and is lost through turnover, so organisations repeat work and cannot learn from past attempts.
status: stable
use_when: "a plan risks repeating earlier attempts, or the organisation wants to capture what it has learned in a shared knowledge base or 'organisation brain'"
sources:
  - id: interviews
    resource: interview programme with media organisations, 2026
---

# Organisational memory

## Practices

- Individuals, including a growing number of managers, already maintain their own personal AI knowledge bases, task systems and markdown note structures, fed continuously with their own notes; this is individual initiative rather than organisational provision, and some such setups fall out of use. (17 mentions)
- Self-built shared knowledge bases become disorganised over time, making it hard to know whether an answer already exists or must be re-derived.
- Some organisations report strong success with internal AI-based knowledge-sharing practices and archive whole strategy processes as onboarding material for new managers.

## Constraints

- Organisations have no central place or knowledge of where things are stored, data is fragmented across tracking tools, no organisation-wide AI system connects content, and AI has deliberately not been connected to internal systems for security, privacy and rights reasons; escalation paths for connecting AI to internal databases are unclear. (8 mentions)
- People across an organisation independently build near-identical solutions, dashboards and fixes, tweaked slightly each time; repeats go unrecognised because of turnover and changed ways of working, and distilling what actually works across repeated attempts would be valuable. (6 mentions)
- Objectives are set for projects but not stored systematically: no database links a project to its stated objectives and outcomes, follow-up on a released concept ends in a manager's slide deck, tagging depends on people doing it, and tactical and strategic process knowledge is rarely captured even though that is where practitioners change course. (6 mentions)
- A knowledge bank of organisational processes and culture is hard to keep current because both change dynamically; it becomes a technical project needing maintenance, gives an advantage only as long as someone feeds it, and raises the question of who may edit its files. (6 mentions)
- Organisations lack structured knowledge-sharing and rarely evaluate projects afterwards; lessons from larger projects are not carried forward, hypothesis-driven learning stays inside one team, and everyday busyness paradoxically stops teams sharing what works right when they are most successful. (4 mentions)
- Search tools operate only over the article archive; almost no equivalent internal organisational-knowledge layer exists, and organisations increasingly want a general 'organisation brain' covering handbook, history and operational knowledge, on which personalised layers could sit. (4 mentions)
- Shelved ideas are handled arbitrarily: some managers track them in personal workflows, some note them in a large management document, some park them on a frozen list; parking is an individual responsibility with no shared system, so knowledge is lost. (4 mentions)
- No standard or supplier is established for an organisation's AI knowledge base, and AI companies compete to have theirs become the most used. That raises two questions for a newsroom: how it keeps its independence, and how it keeps its knowledge portable between tools. Some answer by building on open source and staying independent of any one technology company. (4 mentions)
- Institutional history can only be created by someone taking time to tell it, to colleagues or to a system, and everyday work pressure does not leave room for that; any solution must make it easy for every department.
- An organisation's own culture and structural constraints, such as shift-roster rules, should be part of the knowledge a tool works from, and any output it generates should be correctly sourced rather than fished from memory.
- An earlier attempt to build a knowledge graph over an article archive stalled because the technology at the time was too complicated.
- If an assistant does not understand the organisation's infrastructure, information gets lost; its instructions must be equipped to convey that infrastructure.

## Needs

- Organisations want to log which internal experiments worked and which did not, and to build a shared 'innovation bank' or best-practice repository that can be pinged during a meeting and consulted for what has worked elsewhere, since this knowledge is currently scattered. (6 mentions)
- An organisational 'second brain' would need to account for what was not said and for how it updates over time, since feeding it more can confuse rather than enrich; the label itself is a false analogy, and the only way to learn what such a system is for is to build one and see where it breaks. (6 mentions)
- Practitioners imagine giving an assistant access to internal communication channels to detect informal success signals, and propose capturing ideas at different steps depending on when they enter a shared knowledge base. (2 mentions)
- Organisations want an assistant with access to internal channels that proactively surfaces what other teams are doing and what works, replicating a colleague's tacit judgement, since their real challenge is cross-team context sharing rather than generating ideas.

## Beliefs

- Institutional knowledge, not only published output, is a core organisational asset: processes, meetings, chats, decisions, roles, tacit knowledge and reporters' notes. Making it accessible to people and to AI systems is seen as the next major step, and much of it currently sits trapped in individuals or in time. (13 mentions)
- Markdown is recommended as the best immediate format for institutional knowledge because it is human- and machine-readable and technology-independent; a first knowledge layer need not be a complex knowledge graph. (4 mentions)
- Practitioners need to see intermediate reasoning and patterns themselves rather than only an AI summary, because confident conclusions across differing inputs require tracing how the analysis got there; AI supports structuring and output, while lived understanding of the organisation and pattern recognition remain human.
- Much 'tacit' knowledge is technically written down, for instance in prompts, but effectively tacit because no one knows where to look; individuals run many separate system prompts before any shared context exists.
- Most innovation efforts start by pitching an exciting new solution rather than first making the organisation's existing tacit knowledge visible, which would give people a path to act instead of starting from scratch.
- Innovation arises where people meet; a knowledge base intersecting with existing domain knowledge could work the same way, generating ideas where established knowledge meets something unfamiliar.
- Knowledge bases built for a whole organisation's AI use are at a very early stage: a few newsrooms have begun to think about them, and the discussion is expected to look different within half a year. A set of files is enough while the base is small. At the scale of a whole organisation it is not, and questions of ontology, a knowledge graph on top, supplier choice, speed and cost follow.
- A personal knowledge base has to fit the person who keeps it and cannot be copied from a colleague; each person ends up finding their own way of working with it. A skill is different, because it is built to do one thing and can be shared as it is. Those who keep such a base describe it as taking mental load off them.

<!-- /context/sector/sector-conditions.md -->

---
type: Claim
title: Sector conditions
description: Distribution, business models, legacy revenue and unexamined assumptions about audiences set the conditions any media plan must create value in, and those conditions are shifting.
status: stable
use_when: "a plan rests on assumptions about distribution, legacy revenue, business models or audiences that the media sector's shifting conditions may no longer support"
sources:
  - id: interviews
    resource: interview programme with media organisations, 2026
---

# Sector conditions

## Practices

- Automation can open new business models and B2B relationships while raising ethical challenges of its own; a problem-first approach challenges every technology request with what problem it solves and whether it is the right one, parking many.
- Some organisations have reorganised their digital side as a product organisation and moved technology from taking orders to sharing ownership of spending decisions, while professionalisation has lengthened the path from idea to test.
- Legacy channels still generate significant revenue and will run for years, so organisations discuss delivering the same content through new technology while making digital products more dynamic.
- Format decisions driven by what users actually did, rather than what they said or the team's gut feeling, can succeed when an organisation briefly breaks its consensus-seeking pattern through logic and psychological safety.

## Constraints

- Many publishers work with decades-old systems and lack technical capacity or an innovation mindset; supporting them matters because where journalism disappears misinformation fills the space, giving sustainable journalism a wider democratic role. (6 mentions)
- The main obstacle to restructuring around AI-native or agent-fed workflows is that a viable business model for that future does not yet exist; an organisation rewiring its newsroom to feed AI agents today would risk closing quickly.
- Growth mechanisms that relied on readers sharing journalism on social media have stopped working as platform dynamics shifted, and some organisations have left platforms earlier than their audiences.

## Beliefs

- AI adoption varies sharply by geography and maturity: some markets are far ahead and Europe is seen as more cautious; some organisations have a dedicated AI implementation lead while others have no clear owner and a 'wild west' of self-chosen tools. (9 mentions)
- Widespread layoffs raise the question of whether media organisations have the right people for a transformed future; defensive moats are scarce, and most organisations extrapolate the present rather than holding a clear three-to-five-year vision of what competitive space to occupy. (3 mentions)
- Vendors and organisations expect to learn from markets and users with a more mature relationship to AI, and see international contexts as operating in a different reality from the Danish one. (3 mentions)
- Vendors position sovereignty, trust, quality and control over data as differentiators as core AI capabilities such as transcription become commodities; 'sovereign' must specify where data, models and control actually sit.
- Initiatives should not be built for yesterday's market; organisations locked into legacy systems and outdated market understanding risk optimising a model losing relevance, and fragmented information sources put the relevance of established media itself in question.
- Newsrooms need to move from production-heavy workflows to treating news as knowledge and intelligence, and every media organisation increasingly has to become a technology company; refusing to build the infrastructure of the AI era risks losing control of distribution as happened with the printing press.
- What counts as innovative is not the activity itself but the scale a technology makes viable as a business model; the real innovation is often the enabling infrastructure rather than the visible product.
- Today's digital news structure is 'paper on a screen'; more fluid content forms are expected to change that structure totally, but such thinking is barely discussed in industry standards bodies.
- Innovation can be about finding the next revenue-generating product or business model for when the existing business weakens.
- The question every newsroom has to keep returning to is what the core value of information is today and which jobs it does for its audience; nobody has an answer to it.

<!-- /context/sector/strategy-planning-and-practice.md -->

---
type: Claim
title: Strategy, planning and practice
description: Strategy set at the top rarely reaches operational levels, planning horizons shrink to what fast markets make plannable, and the methods in use are strategy and sprint tools rather than futures practice.
status: stable
use_when: "strategy set at the top must reach operational levels, planning horizons are shrinking, or the team relies on strategy and sprint tools rather than futures practice"
sources:
  - id: interviews
    resource: interview programme with media organisations, 2026
---

# Strategy, planning and practice

## Practices

- Practitioners cite external references such as sprint methods, facilitation cookbooks, strategy textbooks and business-model canvases as their go-to toolbox. (12 mentions)
- Scenario planning is valued as robustness training rather than prediction, asking what makes sense regardless of which future unfolds; organisations run scenario days with large leadership groups, though some exercises are experienced as too fast and short. (2 mentions)
- Fast-moving organisations plan in short horizons because detailed long-range plans lose relevance: roadmaps of one to two years, quarterly framing for returns, a 'long-term' horizon of about five years, and a stated need to still orient toward longer-term structural change.
- Process knowledge built up by a single internal process lead has lasting value and could be democratised as a best-practice account of good choices and pitfalls; running strategy work internally rather than with external consultants keeps that knowledge in the organisation.
- Staff who took part in a structured strategy process valued clear structure and governance, a shared goal, a single point of coordination and one person holding a strategically informed overview of where the organisation was heading.
- Mission statements along digital-first, agenda-setting lines precede strategic focus areas; analogue templates are digitised with AI tools whose quality the user cannot judge.
- Structured strategy processes in use: shared situation analysis and environmental scan, scenarios for degree of digital development, dilemma sliders stacked across units to reveal hidden disagreement, non-linear priority voting, explicit involvement plans by organisational level, phased timelines, and planning in detail two weeks out, overview three months out, direction two years out.
- Process-management tools in use are experienced by many as old-school project management used mainly for time registration, which stalls the incentive to use them, while a minority value them for long-running projects because decisions can be traced by newcomers.
- A simple two-axis effort-versus-value or impact framework, worked in silence with sticky notes and dot-voting rather than open brainstorming, is used to place and prioritise ideas at a realistic size.
- Some organisations work hypothesis-driven at experiment scale, storing hypotheses in a documentation tool, but such tools are static and hard to retrieve from, prompting experiments with a conversational AI layer over existing documentation.

## Constraints

- Culture and implementation are where organisations struggle most: they are good at workshops and ideas, but no one owns implementation, no dedicated resources exist, and the idea dies once routine takes over; the difference between organisations that succeed at long-term innovation and those stuck in optimisation is execution. (4 mentions)
- Shift rosters set roughly two months ahead under collective agreements mean any change affecting staff must be planned that far in advance, so implementation requires forward planning combined with continuous adjustment and significant investment in involvement and coordination.
- Not everyone in a leadership group can work at the same level of abstraction, so strategic work is driven by fewer people; frontline staff cannot reasonably be asked to imagine away their own jobs, so the boldest strategic thinking rarely comes from them.
- There can be a gap of years between change in the wider world and a media organisation's ability to implement it; switching a whole production flow to a new format can take a year and a half.
- An AI strategy tends to become outdated before it even takes effect.
- The three-horizons vocabulary is not self-evident to the people expected to use it. It is described as a muscle still in training, which has to be made simple and tied to everyday work and existing strategies before it helps, and a tool should not assume that its user knows the framework or the literature behind it.

## Needs

- Organisations want a shared vocabulary and a way to document what has already worked, so that ongoing transformation can be formalised, followed up with goals and shared learning, and used to onboard new staff. (3 mentions)
- Long-term strategic direction must be distinguished from short-term flexible execution; an innovation tool should support long horizons without pretending everything can be planned in detail, and the open question is how to make technology and staff mindset ready for a day that has not yet arrived.
- Organisations need methods to separate noise from real shifts: whether a signal is strong enough, how large an investment is appropriate, which competencies to build now, and when to scale or stop an experiment.
- An AI-mediated trend radar is proposed as a use case for an analytics workflow.

## Beliefs

- Good implementation makes change faster and poor process and culture understanding makes it slower; leadership can decide direction and bring in technology relatively easily, whereas moving the actual people is the hard part, and iterative change only reaches a radical goal if the right process understanding and culture already exist.
- Strategy originates at the top but cannot be implemented without ownership and translation at tactical and operational levels; the levels work with different knowledge, decisions and time horizons, and AI work in media happens mostly at the operational content level rather than at the tactical or strategic knowledge level, so a liaison between levels is essential.
- Succeeding in closed decision phases depends on understanding the specific people in the room rather than on frameworks; the process lead's job is to hear patterns in what leaders say and operationalise them, since phases are similar everywhere but their value depends on facilitation and adaptation.
- Organisational change is framed as managed decline of some parts, repurposing of others and room for new things to emerge, or as an existing and an emerging culture growing side by side; the organisation readies itself for a future it cannot force but knows is coming.
- Uncertainty is paralysing when treated as a problem to solve before acting and productive when treated as a design parameter; fast decisions on partial information are possible where staff can be trusted.
- A foresight output such as a trend report can have limited direct application yet still create value through the discussion and process it triggers.
- Imagining what news delivery could look like five years out and challenging why a fixed news format should be taken for granted is valued as a move, even though such questions are rarely taken seriously in the industry.
- The main barrier to taking future-driven innovation seriously is a lack of courage to accept that it cannot be fully described or reduced to a formula; the interrogatory mindset of investigative journalism maps well onto futures thinking.
- The direction a media organisation says it works towards is often read differently by top management, by staff and by the outside world: the top finds it clear where the others do not. Innovation then scatters, with nothing to hold a result up against and no measure of success, and whether a clear core exists shows up again and again in which innovations succeed.

<!-- /context/signals/ai-moves-into-the-physical-world.md -->

---
type: Signal
title: AI moves into the physical world
description: Humanoid and autonomous robots are leaving controlled automation for spaces built for people, making robotics a flexible operational layer with harder questions of safety and liability.
status: stable
use_when: "a plan for physical operations such as printing, distribution, events or studios assumes automation stays confined to fixed machinery away from people"
depends_on:
  - /context/megatrends/rise-of-embedded-ai.md
  - /canon/concepts/organisational-preparedness.md
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, signal AI moves into the physical world"
---

# AI moves into the physical world

Robotics is entering a new phase. What has been confined to automated arms in advanced manufacturing is now leaving the warehouses. Humanoid robots, autonomous machines and other embodied robotic systems are beginning to operate in spaces built for people, not just machines. This marks a shift from automation as fixed infrastructure to robotics as a more flexible operational layer in the real world.

## Beyond manufacturing and logistics

- With the entry of humanoids, robots are no longer just relevant in manufacturing or logistics. As sensing, perception, mobility, language interfaces and planning improve, robotic systems might take on tasks in more everyday settings, where labour might be scarce, routines are repetitive, or safety is a concern.
- Robotics is becoming part of a wider restructuring of how work is organised and where value is created.

## Benefits and risks

- Robots may help address labour shortages, improve workplace safety, reduce operational friction, and create new forms of service and support.
- Once robotic systems move from controlled automation to semi-autonomous action in dynamic settings, questions of liability, safety, governance, trust and interoperability become much harder. A software failure in a chatbot is one thing. A robotic failure in a workplace, shop floor, hospital or public setting is something else entirely.

## Across the horizons

Robotics begins by improving specific tasks and isolated functions. It then starts to reshape workflows, maintenance systems, and collaboration between humans and machines across space. In the longer term, it may alter labour structures, service expectations, workplace design, and the competitive importance of physical environments built to work seamlessly with intelligent machines. Robotics should not be viewed only as a hardware story. It is also a story about organisational preparedness, systems design, and the future shape of work.

## This includes

- Humanoid robotics
- Autonomous robots
- Robotic systems in operations
- Physical AI in embodied machines

## Questions

- Where in our organisation could robots create genuine operational value, and where are they still too immature to justify adoption?
- Which tasks are best suited for robotic systems, and which still depend on human judgement, dexterity, trust, or care?
- How do we prepare for safety, liability, and accountability when robots begin acting in environments shared with people?
- What organisational and infrastructural changes are needed to integrate robots into workflows, maintenance, training, and decision systems?
- How might robotics change expectations around labour, service, workplace design, and competitive advantage in our sector?

<!-- /context/signals/attention-splinters.md -->

---
type: Signal
title: Attention splinters
description: The shared front page dissolves into personal information oracles that understand each user but are not understood by them, so intimacy replaces engagement as the metric and common ground becomes scarce.
status: stable
use_when: "a plan relies on a shared front page, mass reach or engagement metrics while audiences move into personalised AI feeds that know them but stay opaque to them"
depends_on:
  - /canon/concepts/liquid-content.md
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, sections Det eksistentielle pres, Opmærksomheden splintrer and Potentialet og faren i det flydende"
  - id: root-scharfbillig-2026
    resource: "Scharfbillig, M. et al. (2026) Fractured Reality"
---

# Attention splinters

Liquid content can make our attention splinter into each our own small, personalised medium, at the expense of the shared broad narratives and truths that form a foundation for a democratic society in conversation with itself. The single journalistic story, such as the article, loses vitality as a unit; it may become merely an atom in an AI model.

The shared front page is already more myth than reality for many, but it will disappear even more in the liquid and personal era. The media reality is already being atomised, and such a fragmented information landscape makes the shared public conversation harder. Where engagement has been a carrying metric for social media, intimacy may become it for AI.

## Information oracles

That can lead to information oracles that understand exactly you extremely well, but which you do not really understand, because where does the information actually come from? It is hard to fact-check, or to trust, something we do not understand. At the same time such oracles risk isolating each person. They remove the friction that is necessary to understand others' viewpoints, since it is precisely through shared language and meetings that meaning and ethics arise. It is the ultimate possible tool of manipulation. Social media that create unreal narratives help destabilise democracy itself, creating mistrust and eroding the perception of a shared reality, and generative AI fits perfectly into that dynamic. Newer studies also show how people who use AI heavily risk losing learning, because learning requires a certain friction.

## Common ground

The shared front page showed what other people were also following, and so made the shared public conversation more shared. It is decisive that the producers of content also gain access to the demand signal, and that society keeps a kind of common ground. Right now there are no shared frameworks and structures that reward quality in liquid content.

## What it means for news media

The challenges also constitute a potential. Can news media create the shared front pages of the future, or communities where people gather around stories and news? Bundling of content has already proved relatively successful, including shared subscriptions across media. One can also imagine journalistically oriented organisations developing a healthier type of information oracle, giving relevance and intimacy but set up to challenge and bring opposing viewpoints: products built not to give easy answers that weaken human development, but to make us better in the broadest sense.

<!-- /context/signals/audiences-move-to-creators.md -->

---
type: Signal
title: Audiences move to creators
description: Younger audiences take news from creators, influencers and AI rather than news media, and news avoidance rises, so trust must be earned through competence, integrity and closeness to a community rather than institutional objectivity.
status: stable
use_when: "a plan to reach younger audiences assumes they will come to the brand's own channels and trust institutional objectivity rather than creators and personalities"
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, sections Det eksistentielle pres and Den anden vej: Mennesket først"
  - id: root-reuters-dnr-2026
    resource: "Reuters Institute Digital News Report 2026"
  - id: root-angwin-2024
    resource: "Angwin, J. (2024) The Future of Trustworthy Information: Learning from Online Content Creators, Shorenstein Center"
---

# Audiences move to creators

Trust in journalism has been challenged over time, but in 2026 it reached a ten-year global low. Changed habits among users, especially in the younger generations, have also long pulled away from established news media towards creators and influencers, with news avoidance as a rising phenomenon. That development has accelerated too. Among the young, sixteen per cent use AI for news.

The young have chosen sides: they have chosen video platforms, not the established media. So one has to come to them, and use forms of communication that reach them.

## What is happening

- News creators and influencers have seen marked growth in recent years, with individual interview formats on news and politics reaching hundreds of thousands of views on average. A key to their success is understanding the forms and formats of communication on social media: taking formats that already work there and translating them to news and politics.
- Authenticity is a new currency, and trust arises not from striven-for objectivity but from competence, integrity and goodwill, meaning close contact with one's community.
- Some established media systematically select already-established young creators and then train them, in ethics and research tools for instance. Creators are audience infrastructure: they bring new users to the medium's other offerings.
- Where trust has no reach, it has failed; if established media do not engage, the public service of the future will be built outside them.

## A regional caveat

News media in Denmark and the Nordic countries stand stronger than almost anywhere else. Young Danes largely back news media, and usage figures are often far better than abroad. That gives a starting point and a surplus to act. But the tendencies seen elsewhere in the West exist here too, and everything suggests they will only grow in strength in the coming years.

<!-- /context/signals/convenience-over-accuracy.md -->

---
type: Signal
title: Convenience over accuracy
description: A growing share of news users accept approximately correct AI answers because they are more convenient, which undercuts a news structure built to deliver precise information.
status: stable
use_when: "a plan or paywall rests on audiences valuing precise, verified news enough to choose or pay for it over approximately right AI answers"
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, sections Det eksistentielle pres and Hvad hvis folk er … ligeglade?"
  - id: root-birkemose-2026
    resource: "Birkemose, J. (2026) Mediernes trumfkort trues af ny kultur"
  - id: root-cjr-2026
    resource: "AI Versus Accuracy? We're Willing to Make the Trade-Off, Columbia Journalism Review, 2026"
---

# Convenience over accuracy

Something suggests that more news users are already getting a different relationship to truth and facts. The majority in two studies were perfectly satisfied with merely approximately correct information from AI, because it was more convenient than classic news media, even though those were more correct. When the whole structure of news media is set up to deliver precisely accurate information, that tendency constitutes a possible existential challenge.

## What it challenges

- The whole structure of news media is set up to deliver precise information, so users who are indifferent to precision remove the premise of that structure.
- It raises the question whether people will pay at all for information being of slightly higher quality, and whether free and convenience are in fact more important. Key people in even well-established media ask themselves the same question.
- Knowledge is never finished or fixed, and often it is simply wrong; AI-generated overviews err in roughly one answer in ten, and the concept of authority is slipping.

## What it calls for

If news media are to succeed, it probably requires pronounced innovation of forms and formats that give users the desire for more truthful information, and show very clearly why it is important. That task falls to news media, and to their clarity about who they are, but also to politicians and others who support a viable press. Developing self-correcting mechanisms that people will actually use or pay for needs many different disciplines: not just tech experts, politicians, financiers and communicators, but philosophers, anthropologists, artists and psychologists.

<!-- /context/signals/cyber-security-of-ai-mediated-infrastructures.md -->

---
type: Signal
title: The cyber security of AI-mediated infrastructures
description: As AI connects to the systems that shape decisions and operations, the attack surface widens to model manipulation, synthetic identity and retrieval poisoning, and security becomes strategic.
status: stable
use_when: "a plan connects AI to archives, workflows, email or publishing systems, or treats AI security as an IT matter rather than a risk to trust and operations"
depends_on:
  - /canon/concepts/organisational-preparedness.md
  - /canon/concepts/three-horizons-of-ai-mediated-transformation.md
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, signal The cyber security of AI-mediated infrastructures"
---

# The cyber security of AI-mediated infrastructures

As AI is deployed across organisational and societal infrastructures, cyber security moves from a technical concern to a strategic one. The attack surface is expanding fast, not only because organisations are adopting more AI, but because AI is increasingly connected to the systems that shape decisions, workflows, access and operations.

## New risks

- Synthetic media can be used to impersonate executives, deceive employees, and manipulate public trust at scale.
- Prompt injection and jailbreaks can push AI systems to ignore safeguards, leak sensitive information, or take unintended actions.
- Data entered into AI tools can expose confidential knowledge, while agentic systems connected to email, files, browsers, workflows or financial tools create new paths for exploitation if they are compromised.
- Poisoned data, manipulated retrieval sources and corrupted models can distort outputs from within, quietly undermining decision making without triggering immediate alarm.

## Old and new vulnerabilities together

- Traditional risks such as phishing, credential theft and infrastructure compromise remain in place, now joined by model manipulation, synthetic identity, automated exploitation, retrieval poisoning, and system wide weaknesses caused by tightly coupled AI infrastructures.
- The challenge is intensified by the dual use nature of many of these technologies. The same software can enable productivity, surveillance, misinformation, disruption or defence, depending on who controls it and for what purpose. This mirrors the wider concern that emerging technologies blur civilian and security applications.

## Security as preparedness

- Cyber security needs to be understood as part of organisational preparedness. It is not enough to defend against known threats.
- Organisations need to ask how AI-mediated systems behave under pressure, misuse, conflict or failure, and how much opacity, dependency and loss of control they are willing to accept in exchange for speed and efficiency.
- Resilience, fallback mechanisms, verification and governance become just as important as prevention.

## Across the horizons

In Horizon 1, the priority is securing current tools, data and workflows against emerging AI enabled threats. In Horizon 2, organisations need to redesign processes and oversight models to make human and AI collaboration more resilient. In Horizon 3, they may need to prepare for an environment where cyber conflict, synthetic manipulation, information disorder and contested digital infrastructures are persistent conditions of competition and governance.

## This includes

- Cybersecurity
- AI security
- Dual use technologies

## Questions

- How does the growth of AI-mediated infrastructure change our threat landscape, not only technically but strategically?
- Which systems or workflows create unacceptable levels of dependency or opacity if they are compromised?
- How can we design for resilience, fallback, and recovery rather than assuming continuous stability?
- What governance is needed to manage dual use risks and the blurred boundaries between civilian, commercial, and security applications?
- How do we build leadership awareness of AI security issues before they escalate into reputational or operational crises?

<!-- /context/signals/from-static-to-liquid.md -->

---
type: Signal
title: From static to liquid
description: Content is becoming liquid, adapting in real time to context and intent, so value moves from the interface that wins the click to the systems that shape the answer.
status: stable
use_when: "a plan invests in fixed articles, formats or interfaces that win the click, while answers are increasingly assembled in real time by AI systems"
depends_on:
  - /canon/concepts/liquid-content.md
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, signal From static to liquid"
---

# From static to liquid

The digital economy has historically been built on information and access to that information. Since the early internet, organisations created reach by producing more content, capturing attention, and securing visibility in search. Generative AI is starting to reorganise that logic.

## From information to context

- In an AI-mediated world, competitive advantage depends less on simply making information available and more on understanding what matters in a given moment, for a given person, in a given situation. The shift is moving from information to context. From static to liquid.
- Liquid content dynamically adapts in real time across formats, platforms, contexts and users rather than existing as one fixed version.
- This is already visible in AI-driven search interfaces such as Perplexity and Google AI Overview, where synthesised answers appear directly inside the interface rather than through links to external websites. If that direction continues, we are moving toward a zero-click ecosystem where you get all you need without having to click.
- Recent developments in so-called vibe coding for building websites, digital products and tools point to a future in which both workflows and products can be iterated and continuously reimagined. In both cases, value lies with the accessibility to the right type of knowledge, context and situational awareness of where it is being applied.

## From attention to intention

- The attention economy begins to give way to the intention economy. Instead of competing mainly for visibility, organisations need to interpret the intent behind an interaction and respond in ways that are relevant, timely and situationally aware.
- Context-aware systems can adapt interfaces, recommendations, support and content in real time. This is already visible in small pockets of future in generative commerce, adaptive assistants and more responsive work tools. Personal relevance, timing and situational fit become strategic assets in their own right.
- The implications go far beyond retail or media. When AI systems become the first point of contact, organisations are no longer competing only for attention in crowded information environments. They are competing for inclusion in the systems that interpret intent, shape visibility, and guide action before a user ever reaches a traditional interface. Value may shift away from the interface that attracts the click and toward the infrastructure, context and trusted service that shape the response itself in the moment.

## Challenges

- The quality of liquid content depends on context, data richness, inference and interpretation, which raises questions around privacy, misreading, manipulation and fairness.
- Tacit knowledge, social cues and cultural understanding remain difficult to capture through data alone.
- As organisations lose some control over static content in a more liquid digital ecosystem, the challenge is not about simply producing more content, since the static 'artifact' of content is no longer where the value lies. It is about finding new ways to stay relevant.

## Across the horizons

This shift could begin with a weaker link between visibility and value, as context, timing and intent become increasingly important. It then moves toward products, services and workflows built around more adaptive and fluid interactions. Over time, value may shift away from static content and clicks, and toward systems shaped on new dimensions of meaning, relevance and trust.

## This includes

- Liquid content
- Context aware AI
- Intent based interfaces
- Generative services and commerce

## Questions

- What new services or business models become possible when interfaces respond to intent rather than traditional search behaviour?
- How do we prepare for a possible zero click ecosystem where AI interfaces intermediate access to information and services?
- What kinds of contextual understanding would create genuine value for our customers, employees, or partners, and what kinds would feel intrusive or manipulative?
- How do we collect and use contextual data responsibly, with clear limits, transparency, and consent?
- What capabilities do we need to design for relevance and adaptability without undermining our values and ethical guidelines?

<!-- /context/signals/geopolitics-of-tech.md -->

---
type: Signal
title: The geopolitics of tech
description: Technology is strategic infrastructure shaped by energy, chips, minerals and export controls, so dependencies that once looked efficient become strategic vulnerabilities.
status: stable
use_when: "a plan depends on foreign cloud, AI models or platforms and treats supplier choice as a cost question rather than a strategic dependency"
depends_on:
  - /context/megatrends/shifting-world-order.md
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, signal The geopolitics of tech"
---

# The geopolitics of tech

One of the clearest geopolitical shifts is that, although technology was never neutral, this is now becoming far more visible.

## Technology as strategic infrastructure

- Technology is shaped by energy access and prices, water availability, semiconductor supply chains, rare earth mineral extraction, export controls and trade agreements. Access to AI depends not only on software and models, but on who can secure the physical and geopolitical conditions required to build and run them.
- The old image of software as borderless, frictionless and globally interchangeable is giving way to a more regionalised and contested infrastructure landscape, and awareness of who governs and programmes technologies from LLMs to electric vehicles. Resilience, localisation and strategic autonomy are becoming more important than cost optimisation alone, evident through a return to state industrial policy.
- Europe offers a clear signal. The EuroStack agenda argues for European capacity across the digital stack, from connectivity and cloud to AI and platforms. France has expanded sovereign state-operated tools such as Tchap and La Suite for public-sector communication and collaboration. The coming EU Tech Sovereignty Package is expected to push further on cloud, chips, open source and AI infrastructure. Geopolitical risk, trade pressure and concern over dependence on foreign providers are changing the norms around who should own, operate and control critical digital systems.

## What it means for organisations

- Infrastructure choices can no longer be treated as purely technical or financial decisions. Dependencies that once looked efficient may become strategic vulnerabilities. Supply chains can fragment. Regulation can diverge. Access to markets may be given, but often constrained by rivalry between states, blocs and standards regimes.
- Power is unevenly distributed across the technology stack. Some actors shape the terms of access to compute, chips, platforms and cloud infrastructure. Others remain downstream, dependent on systems they do not control. Apparently technical questions become contentious: who controls the mining and processing of rare earth minerals, who can manufacture advanced AI chips at scale, who can secure the energy and water required for advanced data centres, and who controls the infrastructure in space critical for connectivity. As AI becomes more economically significant, these are emerging as levers of power in their own right. They shape what organisations can build, buy, integrate and rely on.
- Preparedness requires an understanding of contemporary infrastructural dependencies and the geopolitical order these rely upon, a stronger scenario awareness, and a willingness to always think politically about technology.

## The AGI frontier

- Artificial General Intelligence (AGI) refers to systems capable of performing any intellectual task a human can, and potentially far beyond. The race towards achieving such general-purpose frontier systems is inherently geopolitical.
- If AGI-level systems were developed by a small number of firms or states, the consequences could extend well beyond productivity gains: a system capable of autonomously running scientific research, drafting legislation, managing critical infrastructure, or conducting cyber operations at a speed and scale no human institution could match or monitor. Whichever actors controlled such a system would hold an asymmetric advantage in economic output, military capability, and the ability to shape information at scale. The resulting concentration of power could prove extremely difficult to govern and potentially destabilise the wider international order. The question is not only about the capability of such systems, but who, if anyone, is in control.

## Across the horizons

This shift begins as a question of supply chain risk and cost, as organisations become more aware of how dependence on external infrastructures can create strategic vulnerability. In the long term, a fragmented technological order may force organisations and governments to rethink sourcing, ownership, and the conditions for staying adaptive and competitive.

## This includes

- Technology sovereignty
- Strategic autonomy
- AI infrastructure competition

## Questions

- Which technological dependencies in our organisation could become strategic vulnerabilities under geopolitical stress?
- How should we think about sovereignty and autonomy in relation to our own data, infrastructure, and suppliers?
- What scenarios could materially change our access to key technologies, markets, or partners over the next few years?
- How do regulatory divergence and strategic rivalry affect our long-term innovation choices today?
- What capabilities do we need to stay adaptive if the technological landscape fragments further along geopolitical lines?

<!-- /context/signals/machine-audiences.md -->

---
type: Signal
title: Machine audiences
description: An increasing share of the audience is agents that information passes through, so content built as artefacts for humans loses value against structured data and clear context for machines.
status: stable
use_when: "a plan assumes the audience is human readers, while a growing share of traffic is AI agents that want structured data and clear context rather than narrative"
depends_on:
  - /canon/concepts/liquid-or-human-first.md
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, section Samarbejde: De innovationer, der er svære at løfte alene"
  - id: root-fang-2026
    resource: "Fang, S. (2026) Welcome to the World of Machine Audiences, The Economist"
---

# Machine audiences

A particular point in the relationship between media and the AI entry points concerns whom media produce content for: human users or a machine audience. Traffic from the latter takes up more and more. The customer or reader is agents that the medium's information passes through. That challenges the business model for publishers when the audience is the machine, and it requires commercial innovation. News media are geared to produce artefacts, not data for agents.

## What it challenges

- News media have to move higher up the value chain. Otherwise they will struggle with what has been called the largest cultural shift ever for news organisations, against which digitisation was a piece of cake.
- When the customer is an agent, some classic journalistic forms become less valuable. A journalistic narrative of two thousand words is not optimal for AI agents; a list and clear context are more usable. A narrative can still create good value for people, and support what can be called community journalism.
- Many media are not conscious enough of the two types of content and the two types of user, and they do not use two rigorous approaches.

## What it calls for

As with the choice between liquid and human-first content, it is about choosing very clearly, or having very great awareness of when you make what. Some media have begun to make two kinds of content: one for machines, for example with lists, in front of the paywall, and another kind for people behind the paywall.

<!-- /context/signals/machines-as-the-primary-audience.md -->

---
type: Signal
title: Machines as the primary audience
description: A growing share of what is published is read first, and often only, by AI systems acting for people and by agents acting for other agents, and the protocols of that economy are being written now while its standards are still soft.
status: stable
use_when: "a plan assumes its journalism will be read by people on the newsroom's own pages, or that the article stays the unit of information and of value"
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: root-naij-fojo-2026-fang
    resource: "Fang, S. (2026), The information revolution will not be televised, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
---

# Machines as the primary audience

## The two shifts

- Machines are becoming the primary audience for information. A growing share of what is published, recorded or measured will be read first, and often only, by AI systems acting for people, and increasingly by agents acting for other agents.
- Information changes category. For most of its history, news, information and knowledge have been a final good, produced before consumption and read by a person who may or may not act on it. In an agentic economy they become an intermediate input into a decision, a transaction or an automated process, and in most cases may never be rendered for a human at all.

## Signs

- In October 2026, Meta and Sierra announced a protocol for how personal agents deal with businesses, with Walmart, Shopify and Stripe on board.
- Agent protocols such as MCP and content credentials such as C2PA are early versions of a shared protocol and standard unit for information. Data cooperatives such as Switzerland's MIDATA, whose members decide who may use their health data, are an early version of trusted holders of dispersed knowledge. Probabilistic news, which attaches explicit likelihoods to claims, is an early version of calibrated confidence. Crossref's Crossmark, which flags corrected and retracted research, is an early version of corrections that reach every system that used the original.
- The agentic information economy does not yet have a standard way to represent a piece of information, let alone the institutions to build on one.

## What it signals

- Shuwei Fang's reading: the foundations of the agentic economy are being laid, but the information systems it runs on lag behind. Whether journalism's instincts, independence, disclosure, scrutiny and public correction, become the blueprints is being decided now, while the standards are still soft.

<!-- /context/signals/neurotechnology-and-the-cognitive-dimensions-of-ai.md -->

---
type: Signal
title: Neurotechnology and the cognitive dimensions of AI
description: Cognitive offloading to AI and technologies that touch the nervous system are reshaping the conditions under which people think, judge and act.
status: stable
use_when: "a plan hands research, editing or judgement to AI, or builds audience products that do the thinking for users, without asking which cognitive skills are lost"
depends_on:
  - /context/megatrends/rise-of-embedded-ai.md
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, signal Neurotechnology & the cognitive dimensions of AI"
---

# Neurotechnology and the cognitive dimensions of AI

One of the more revealing signals to watch is the growing convergence between AI, neuroscience and neurotechnology. It points to a broader shift in how organisations will need to think about cognition, agency, and the changing boundary between human intelligence and machine intelligence.

## Cognitive offloading

- As the historian of technology Melvin Kranzberg noted, "Technology is neither good nor bad, nor is it neutral." In an AI-mediated world this insight becomes particularly relevant as intelligent systems begin to shape how we think, feel and navigate the world.
- Public concern is surfacing in informal language. Terms such as AI brain fry capture the idea of mental fatigue from excessive use or oversight of AI tools beyond one's cognitive capacity, as well as a growing anxiety that constant reliance on intelligent systems may dull attention, weaken reflection, and reduce our willingness to think through problems ourselves. Behind the phrase is a serious strategic, if not existential, question: what happens if convenience steadily replaces cognitive effort?
- By delegating tasks that involve critical thinking, creativity and complex reasoning to machines, AI can be understood to be augmenting the cognitive capacity of human beings. However, augmentation requires a form of cognitive offloading. Calculators and computers dramatically extended what we can solve, yet most of us can no longer do the arithmetic we once learned in school. AI augmentation works the same way. Every gain in capability comes with some degree of offloading. This raises profound questions around technological dependence, agency, and what it means to be human.

## Neurotechnology sharpens the question

- Technologies that interact directly with the nervous system, from brain computer interfaces to stimulation-based therapies and neuroadaptive systems, suggest a future where the line between assistance, augmentation and intervention becomes even harder to detect and maintain. The boundary between human and machine thought will only continue to blur.
- In the short term, these developments are concentrated in health, rehabilitation and specialised treatment. Over time, they may shape wider debates about memory, attention, training, emotional regulation, decision support and mental autonomy.
- The issue is no longer only what machines can know or generate. It is how deeply they may come to influence the conditions under which people think, judge and act.

## An early warning signal for organisations

- The challenge is not that every company needs a neurotechnology strategy. It is that leaders need a clearer view of the cognitive consequences of AI-mediated futures.
- If more tasks are delegated to systems that predict, prompt, summarise and decide, then cognitive offloading becomes part of the operating model. Some of that will be useful. Some of it may quietly erode the very human attributes organisations say they value, such as judgement, curiosity, learning and independent thinking.
- Neurotechnology is not a narrow frontier. It is a glimpse of a wider future in which tech reaches into the core of human cognition itself.

## Across the horizons

This shift begins as cognitive augmentation, with AI helping people think faster by searching, summarising, prompting, and reducing friction in everyday cognitive tasks. Over time, cognition is treated as an organisational design issue, as workflows, training and decision systems are increasingly built around cognitive offloading and human-AI coordination. In the long term, the frontier may become far more radical, with the conditions for thinking and exercising agency themselves reshaped by AI and neurotechnology.

## This includes

- Neurotechnology
- Cognitive offloading
- Brain computer interfaces
- AI brain fry

## Questions

- Which forms of AI support strengthen human judgement, and which make people mentally passive over time?
- What cognitive capabilities should organisations deliberately protect, even when AI can perform the task faster?
- How do we design working routines that reduce overload without outsourcing too much thinking?
- What ethical boundaries matter when AI and neurotechnology move closer to attention, emotion, and agency?
- How can leaders build organisations that remain cognitively resilient in increasingly automated decision environments?

<!-- /context/signals/newsrooms-start-to-explain-their-ai-choices.md -->

---
type: Signal
title: Newsrooms start to explain their AI choices
description: In 2026 a record eight Pulitzer awardees disclosed AI use, major newsrooms published how they used it, and a manifesto for romantic journalism said why its signatories limit it, early signs of explicit communication either way.
status: stable
use_when: "a plan uses AI in the journalism without deciding whether and how to tell the public, or assumes that nobody explains their AI choices"
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: root-naij-fojo-2026-nielsen
    resource: "Nielsen, R. K. (2026), Four different responses to public skepticism around AI in news, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
---

# Newsrooms start to explain their AI choices

Examples collected by Rasmus Kleis Nielsen of newsrooms communicating explicitly about what they do with generative AI and why, in both directions.

## Explaining intense use

- A record number of Pulitzer Prize awardees, eight, disclosed AI use in 2026.
- The New York Times published a human-computer interaction paper on the development and use of the Epstein Files Engine, an in-house AI agent running database queries across corpora.
- Bloomberg's AI researchers contributed eight papers to the 2026 Association for Computational Linguistics conference, on subjects from agentic systems to responsible AI and financial language processing.
- Journalists at Die Zeit and Der Spiegel explained how they used AI to build a searchable database of Nazi Party members.

## Explaining limited use

- A manifesto for the romantic school of journalism was launched at the 2026 International Journalism Festival in Perugia by Lea Korsgaard of Zetland and Joshi Herrmann of Mill Media: limited use of generative AI on the editorial side, explicitly communicated, to stand apart from a profession much of the public assumes is already using it intensely.

## What it signals

- These are not only examples of using or not using AI. They are steps of explicitly communicating how it is used, what for and why. The disclosures are largely oriented at fellow professionals, but they contain the kernel of a more explicit communication about what generative AI in news can mean beyond making it cheaper.
- Nielsen finds it hard to identify established publishers that combine intense AI use with explicit communication; these are the nearest examples.

<!-- /context/signals/platforms-move-from-distribution-to-content.md -->

---
type: Signal
title: Platforms move from distribution to content
description: Having taken advertising and distribution, tech companies that own the AI entry points are now taking the content itself, and with it news media's control over their work and their direct relationship to users.
status: stable
use_when: "a plan depends on platform or AI distribution, licensing deals or a direct relationship with users that the tech companies owning the AI entry points could take over"
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, sections Det eksistentielle pres and Samarbejde: De innovationer, der er svære at løfte alene"
---

# Platforms move from distribution to content

Social media and other platforms, often owned by tech giants, have been dominant for a number of years. But for the first time ever, more people now get their news directly from platforms, not from news media. If people increasingly get their knowledge, information and news directly via AI, it can remove news media's control over their own content and their invaluable direct relationship to users. It moves power over information, and over journalism, away from news media and towards the tech companies that own the AI entry points.

Earlier, tech platforms largely outcompeted news media on distribution and advertising. Now they are going after taking over the content as well. That hits not only the business foundation but the very influence and relevance of news media.

Figure: three boxes in a horizontal row. The first two, "Advertising" and "Distribution", are drawn with a solid line; the third, "Content", is dashed. Above the first two stands "The technology companies took these areas", with two arrows pointing down at them. Below the dashed box an arrow points up towards the text "Now they are going after this".

## The access model shakes

The dominant or growing information entry points, platforms and increasingly AI entry points, are controlled and developed by foreign tech companies. Even where media are strong, that challenges the direct relationship between the news medium's brand and journalism and the user. It shakes what can be called journalism's access model. Publishers are losing control over their content, and whoever controls the assembly of information has the power; no news media have that control. The result can be their gradually disappearing relevance. If the front page dies, where does the medium's best content live? Does it become interfaces supported by new AI devices? And does the future of media become to be content factories for the entry points that users find give the greatest value?

## What it calls for

In the short term, collaboration between media can concern securing real payment for the content used in AI products, possibly via a form of subscription; securing visibility; letting people move easily on to the medium itself; and keeping a degree of control over the content. Alliances between large news organisations and licensing initiatives are already under way. They are decisive for a certain negotiating position towards the tech companies and for innovating towards systems and business models in which news media can also thrive in the new information ecosystem. It may also indicate that the AI companies need some of the journalistic content: AI platforms increasingly rely on trusted news content to understand and respond to real-time events, and agreements giving AI assistants access to news in real time have been seen as a structural shift in the AI ecosystem.

In the longer term the need for collaboration goes beyond licensing agreements. Are news media merely to be content factories, or can they build a new trusted layer: new interfaces, or layers, that people will use, also as an alternative to AI products and platforms? That will require large, broad collaborations, and it concerns not only the existence and business models of media. Who owns the information infrastructure is a core democratic question. It may call for collaboration with legislators and governments, and with other institutions in society within research, financing, technology and education. Such collaborations will require many difficult trade-offs, not least regarding the independence of news media and their classic internal competition.

<!-- /context/signals/public-scepticism-of-ai-in-news.md -->

---
type: Signal
title: Public scepticism of AI in news
description: Surveyed publics expect news made mostly by AI to be cheaper, less transparent and less trustworthy, assume news media already use it often, and are more pessimistic about AI in news than about AI in search or social media.
status: stable
use_when: "a plan assumes the audience will welcome AI in the journalism, will not notice it, or will credit a newsroom for not using it"
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: root-naij-fojo-2026-nielsen
    resource: "Nielsen, R. K. (2026), Four different responses to public skepticism around AI in news, in Stenbom Swedling, A. (ed.), Futures of Journalism, Nordic AI Journalism and Fojo Media Institute"
---

# Public scepticism of AI in news

Findings from online surveys of nationally representative samples of adults, conducted in 2025 across mostly high-income countries in Europe, North America and Asia, as summarised by Rasmus Kleis Nielsen. They will not represent every country or every community.

## What people expect of AI-made news

- Asked whether news produced mostly by artificial intelligence with some human oversight would be more or less of various qualities than news produced entirely by human journalists, more respondents say it will be more up to date, easier to understand and informative than say the opposite.
- There are significantly more pessimists than optimists on whether such news will be transparent and, crucially, trustworthy.
- The quality most people expect of it: cheaper to make.

## What people assume news media already do

- A majority answer that news media use generative AI "always" or "often", a rate behind only search engine and social media companies.
- So whether or not a given journalist or publisher uses AI, much of the public is likely to assume they do, and its beliefs about what that means, less transparent, less trustworthy, cheaper, are likely to be priced in either way.

## Not a general crisis of trust

- Trust in news media is in long-term decline in much of the world, as it is for governments and political parties, but trust in the civil service, the legal system and science has held up or increased in many countries over the same period.
- Asked how generative AI will change their experience of various sectors, optimists outnumber pessimists for most sectors, except news media, governments and political parties. The contrast between optimism about search engine and even social media companies and pessimism about news media is particularly striking.

## Context

- Generative AI use is growing roughly twice as fast as internet use did in the 1990s and early 2000s, and many users find a fair share of synthetic content useful and valuable.
- Nielsen's reading: many kinds of content are likely to grow ever more commoditised, but relations are not, so the relationship between journalism and the public it claims to serve will only grow more important.

<!-- /context/signals/quantum-the-next-era.md -->

---
type: Signal
title: Quantum – the next era
description: Quantum could move the limits of computation, simulation and discovery beyond today's imagination, so it deserves structured attention now to avoid strategic surprise.
status: stable
use_when: "a long-range technology, security or data plan leaves out shifts in computing that could break encryption or change what can be modelled, and no one owns watching them"
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, signal Quantum – the next era"
---

# Quantum – the next era

Quantum is a continuing signal that needs attention. In 2026, most organisations do not need a quantum strategy. It is simply too hard to act upon. But large organisations should now consider creating a quantum taskforce, or assigning clear ownership of the topic across strategy, innovation, cybersecurity, research or foresight. The exact setup is less important than the fact that quantum now deserves structured attention. It should be on the radar. Quantum has the potential to shift the technological ground beneath entire industries and societies.

## The harder challenge is imagination

- The central challenge is not only whether quantum will work, or when it will mature. The harder challenge is whether organisations can even imagine the reality it may unlock.
- Most firms are still asking whether quantum will produce useful applications. That is too limited a question. The deeper issue is whether leaders are prepared for a world in which the limits of computation, simulation and scientific discovery move beyond today's imagination. If that happens, the impact will not be confined to R&D teams. It could radically change how firms create value, where advantage sits, and which capabilities begin to count.
- A useful comparison is the printing press. It did not simply improve communication. It altered the infrastructure of knowledge, reduced the cost of coordination, widened access to information, and helped create new centres of power. Quantum could have a similarly structural effect in areas where current computational limits shape what can be invented, secured or understood. If practical thresholds are crossed, advantage may shift towards organisations able to use quantum to solve problems that others still cannot reach.

## Getting the timing right

- Many companies either dismiss quantum as too early, or wait until it becomes impossible to ignore.
- A better response is to build preparedness without getting pulled into hype: tracking technical progress, watching investment flows, paying attention to standards and regulation, and asking where quantum could intersect with the organisation's future business model, research agenda or security posture.
- The point is not to predict the exact moment of arrival. It is to avoid strategic surprise.

## Across the horizons

Quantum will look distant from Horizon 1, where near term delivery dominates. In Horizon 2, it becomes a question of literacy, scanning, preparedness and selective experimentation. In Horizon 3, it becomes a possible source of scientific acceleration, market reshuffling and strategic asymmetry. Quantum belongs here not as a near term certainty, but as a signal of a future shift that leaders cannot afford to notice too late.

## This includes

- Quantum computing
- Post quantum security
- Quantum enabled discovery
- Optimisation and simulation

## Questions

- Where could quantum alter the basis of value creation in our sector?
- Do we need a quantum taskforce, or another organisational mechanism, to monitor developments and translate them into strategic relevance?
- Are we prepared for a future in which the limits of modelling, discovery, and optimisation begin to shift?
- How exposed are our systems, data, and security assumptions to quantum enabled disruption?
- What would we need to see before quantum moves from a signal to active priority in our organisation?

<!-- /context/signals/reshuffling-of-ecosystems.md -->

---
type: Signal
title: The reshuffling of ecosystems
description: AI is moving value from the product to the system around it, so advantage shifts to whoever interprets intent, coordinates data and becomes the trusted layer for decisions.
status: stable
use_when: "a plan defends the product or content the organisation makes while value moves to whoever interprets intent, coordinates data and owns the trusted layer"
depends_on:
  - /context/megatrends/rise-of-embedded-ai.md
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, signal The reshuffling of ecosystems"
---

# The reshuffling of ecosystems

One of the clearest signals is an early reshuffle of competitive ecosystems. AI is starting to change where value is created and captured, not only inside organisations, but across the wider system of platforms, ecosystems, interfaces, infrastructure layers, service providers and end users. As AI becomes embedded across these layers, value does not disappear. It moves.

## From the object to the system

- AI is changing the centre of gravity in many industries. In an AI-mediated economy, advantage may shift from owning the thing to shaping the flow around it.
- The strongest position may belong less to the company that makes the product, and increasingly to the one that interprets intent, coordinates data, and becomes the trusted layer through which decisions are made. This is the reshuffle, when value moves from the object to the system around it.
- AI is rearranging relationships between infrastructure providers, model companies, interface owners, data holders, service layers and end users across global value chains. Organisations can no longer assume that their historical place in their market will hold.

## Which skills become valuable

- Demand is rising for capabilities such as AI literacy, context engineering, output verification, and the ability to manage agentic workflows. Communication, interdisciplinary thinking, and the ability to work critically with AI-generated outputs remain essential.
- The deeper capability required for executive decision-makers becomes system literacy: the ability to understand how value is created across new ecosystems, where dependencies are shifting, and how changes in one layer can alter the logic of the whole.
- Future relevance is likely to depend on which of these capabilities organisations build, combine and embed across the workforce, not as isolated crafts but as ways of navigating the system.
- The organisations that understand how the ecosystem is being reconfigured, and can reposition themselves within it, might be the ones that stay relevant. Ecosystem thinking is becoming a core leadership capability.

## Across the horizons

This reshuffle can be easy to miss at first because it often appears as interface improvement, process automation or better tooling. Over time it changes partnerships, power positions, and the basis on which companies compete and stay relevant.

## This includes

- AI platforms
- Data value chains
- Competition between infrastructure layers

## Questions

- Where is value likely to move in our sector as AI changes the relationship between interfaces, data, infrastructure, and end users?
- Are we defending the right part of the value chain, or optimising a layer that may become commoditised?
- What new partners, competitors, or cross industry players should we now consider part of our future strategic landscape?
- How do we build strengths in trust, orchestration, and integration, rather than relying only on current product logic?
- What signals suggest that our ecosystem is being reshuffled faster than our strategy assumes?

<!-- /context/signals/rise-of-agentic-organisations.md -->

---
type: Signal
title: The rise of agentic organisations
description: AI agents that pursue goals and interact with other agents are embedding themselves inside operations, turning organisations into systems of humans and agents working together.
status: stable
use_when: "a plan brings AI agents into editorial or business workflows without settling who decides, who is accountable and where human judgement stays"
depends_on:
  - /context/megatrends/rise-of-embedded-ai.md
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, signal The rise of agentic organisations"
---

# The rise of agentic organisations

Agentic AI is, in a basic explanation, AI that can pursue goals through actions, not just generate responses. In 2026, a visible shift is starting where agents not only perform assigned tasks, but also interact with other AI agents in ways that open up new paths not fully anticipated in the original prompt. This shapes how work is created, coordinated and executed, and points towards the emergence of agentic organisations, where AI becomes embedded within operational systems rather than sitting at the edge of them.

## What is already happening

- Agents have already begun to take on substantial roles to optimise workflows. This changes expectations around speed, accountability and collaboration. The release of OpenClaw has brought about widespread concerns regarding the safety of highly autonomous agentic AI assistants, but also highlights the potential of these technologies to transform personal workflows as they increase in maturity.
- Interfaces that translate intent directly into workflow systems allow individuals and teams to build, test and deploy applications at unprecedented speed. As the cost and friction of building software decline, traditional software models may shift, with the possibility that some forms of software as a service capture less value in the value chain as capabilities become more embedded, modular and agent driven, also known as the SaaScopolypse.
- Together these developments suggest that organisations increasingly operate as dynamic systems of humans and AI agents working in collaboration. The important question is how they reshape coordination, knowledge flows and decision making inside organisations all together.

## What leaders will need to deal with

- Where does human judgement remain essential, where can agentic systems create leverage, and how are trust, accountability and organisational values maintained when actions are partially automated?
- At a deeper human level, whether organisations need to reintroduce intentional cognitive friction into their processes, so the removal of friction does not slide into overdependence or, eventually, a significant loss of control over the agentic workforce.

## Across the horizons

Agentic systems initially enhance existing tasks and workflows. Over time they begin to reorganise collaboration and decision making across teams. In the longer term, they may reshape the very structure of organisations, as agency and responsibility are increasingly shared between people and intelligent systems.

## This includes

- Agentic AI
- AI-mediated workflows
- Hybrid human and AI teams

## Questions

- Which parts of our organisation are ready for agent supported workflows, and which require stronger human judgement or accountability?
- How should roles, responsibilities, and escalation paths change when AI agents begin to act across multiple functions?
- What forms of oversight, logging, and transparency are needed to keep agentic systems aligned with our values and risk thresholds?
- How can we build organisational trust in human and AI collaboration without creating complacency or anthropomorphising the systems?
- What new aptitudes will leaders need if the organisation increasingly operates through a mix of human judgement and machine-initiated actions?

<!-- /context/signals/simulations-on-the-rise.md -->

---
type: Signal
title: Simulations on the rise
description: AI-driven simulation, synthetic data and digital twins let organisations rehearse futures and test decisions before reality forces adaptation.
status: stable
use_when: "a plan or decision could be rehearsed before launch, for instance by testing audience or advertiser responses with simulations, synthetic data or digital twins"
depends_on:
  - /canon/concepts/scenarios.md
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, signal Simulations on the rise"
---

# Simulations on the rise

AI is turning simulation into a core preparedness capability, allowing organisations to test futures in playful manners before they must live through them. Many of the challenges organisations face now are complex, uncertain and systemic. Traditional wargaming often struggles to account for second order effects, feedback loops, or the way multiple shifts interact as conditions change.

## A new experimental space

- AI driven simulation creates a new experimental space for foresight, leadership, training, innovation and decision making. It allows organisations to explore plausible scenarios, rehearse responses, and experience how systems, teams, strategies and other implications may behave as different futures begin to unfold.
- One frontier is the use of synthetic data, AI generated datasets, simulated personas and agent populations. Such data allow organisations to test features, service journeys, behavioural responses and alternative future conditions before exposing real customers or sensitive data to emerging products.
- Used well, simulation can turn experimentation into a practical and even playful way for organisations to engage with possible futures. Used inadequately, it can produce false confidence, especially when the modelled world is too neat, too biased, or too far removed from how people actually behave.

## The link between foresight and practice

- Simulation provides a strong link between foresight and any given future practice. When scenario work, digital twins, agent based modelling or synthetic data are grounded in real organisational uncertainties, futures become easier to test.
- Instead of relying on static narratives, organisations can explore how different situations might unfold, where pressure points could emerge, and which decisions hold up across several possible worlds.
- It can also bring in a wider set of voices, giving more people a role in shaping how those futures are explored.

## Across the horizons

AI enhanced simulation may look like a support tool for planning and training today. Over time, it may become an invaluable resource for rehearsing decisions, testing assumptions, exposing hidden dependencies, and building preparedness before reality forces adaptation.

## This includes

- Simulation environments
- Synthetic data
- Digital twins
- AI-driven foresight systems

## Questions

- Which strategic decisions in our organisation would benefit most from simulation before real world execution?
- How can we connect simulation tools with foresight, risk management, and leadership development rather than treating them as separate activities?
- What data, assumptions, and governance are needed to make simulations useful without confusing plausible models with certainty?
- How might simulation change the speed and quality of organisational learning in times of volatility or crisis?
- Where could simulated environments become a core resource for preparedness, experimentation, and strategic communication?

<!-- /context/signals/sustainability-challenges-of-ai-infrastructure.md -->

---
type: Signal
title: Sustainability challenges of AI infrastructure
description: Compute growth, data centres, cooling and material extraction push sustainability upstream into infrastructure choices, model selection and procurement.
status: stable
use_when: "a plan scales AI use, compute or data infrastructure without weighing its energy, water and climate costs or how audiences and regulators will judge them"
depends_on:
  - /context/megatrends/green-transition.md
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: ref-futures-of-technology-2
    resource: "CIFS H3 AI Lab (2026), Exploring the Futures of Technology 2.0, signal Sustainability challenges of AI infrastructure"
---

# Sustainability challenges of AI infrastructure

The expansion of AI infrastructure carries environmental consequences that cannot be ignored. Compute growth, data centre demand, cooling, water purification, material extraction and energy use all raise questions about the sustainability of AI infrastructure at scale.

## An uncertain footprint

- The future carbon and water footprint of AI remains highly uncertain. Affordable and capable low-carbon and water-efficient AI models may emerge, but the long-term sustainability of AI systems will depend on technical advances in chip design, computational engineering and data centre architecture, alongside laws, energy policy, and the state of public attitudes toward resource extraction and use.
- The issue becomes more complex in a world where AI regulation and the sustainability and climate agenda are developing along diverging paths.

## Sustainability moves upstream

- Sustainability will move upstream into infrastructure choices, model selection, procurement and responsible use.
- Decisions need to be made about how to match the resource intensity of infrastructure to the value created for the organisation, and whether more efficient approaches to AI use are being overlooked in the rush to gain short-term productivity increases.

## Across the horizons

Sustainability starts as a question of investing in efficiency, environmental technology, and measuring impact. Over time, solutions may emerge in the form of sustainable models, with trade-offs between computation power and resource intensity. In the longer term, sustainability concerns may end up reshaping which technological pathways are seen as legitimate at all in the wider economy.

## This includes

- Energy demand of AI
- Water intensity
- Supply chains for compute
- Sustainable digital infrastructure

## Questions

- How do we assess the environmental cost of our AI related infrastructure decisions rather than treating them as invisible backend choices?
- Where can smaller models, edge solutions, or more selective deployment create better balance between value and resource intensity?
- How should sustainability criteria influence procurement, partnerships, and technology architecture?
- What role can our organisation play in shaping more responsible norms for digital infrastructure and compute consumption?
- How do we communicate honestly about both the benefits and the environmental trade offs of AI adoption?

<!-- /context/signals/the-great-information-repricing.md -->

---
type: Signal
title: The great information repricing
description: Value migrates from the content layer to the intelligence layer, leaving awareness journalism to structural collapse, decision-reducing intelligence to high margins, and civic journalism to non-market funding.
status: stable
use_when: "a business model counts on selling general news awareness, while value moves to intelligence that reduces uncertainty for decisions and to grant-funded civic journalism"
depends_on:
  - /canon/concepts/truth-as-gold.md
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, section HOW TO: Mere brugbarhed eller offentligt gode?"
  - id: root-marconi-2026
    resource: "Marconi, F. (2026) Who Will Monetize Truth? A Thesis for the Future of the Information Business"
---

# The great information repricing

Much suggests that clear usefulness is essential when it comes to monetising truth in these years. Profit margins are markedly larger on selling intelligence and solutions that companies and people can use very directly than on classic journalism. Value is migrating from the content layer to the intelligence layer.

Figure: a scatter plot of revenue per employee against the share of revenue from intelligence and data products. Classic news media sit bottom left with near-zero margins and a consumer news subscription as their peak product; data and intelligence companies rise up and to the right along a dashed "repricing curve", with margins above thirty-five per cent and an institutional terminal as their peak product. The gap is described as a pricing ratio of 275 to 1 for the exact same raw material.

## The ecosystem taxonomy

| | The intelligence business | The attention aggregator | The public good |
|---|---|---|---|
| Product | Reduced uncertainty for decisions | Awareness of past events | Civic accountability |
| Distribution | Embedded in professional workflow | Social and search feeds | Public access |
| Economics | High margin, extreme pricing power | Structural collapse, as AI makes awareness free | Non-market, requires philanthropic or grant funding |

## What it means for news media

Put simply, there is money in the solution economy. But ordinary journalism, which one cannot necessarily use very directly in one's life, may rather have to be understood as a public good. The development poses new challenges to financing, and perhaps to the need for support, and possibly calls for news media to focus at least parts of their offering into a solution economy. Otherwise it will, as now, largely not be media but domain experts and others who build that type of information business.

A major report on the new AI landscape does not mention news media as a specific category at all, only as infrastructure. If content becomes infrastructure, verification becomes the product. Can news media develop formats for that within a new solution and intelligence economy, so that truth actually becomes gold?

<!-- /context/signals/the-knowledge-freezer.md -->

---
type: Signal
title: The knowledge freezer
description: Fewer journalistic stories produced under pressure from AI degrade the AI that depends on them, in a self-reinforcing negative loop.
status: stable
use_when: "a plan assumes AI companies can keep drawing on journalism while newsrooms shrink, or weighs licensing content to AI without asking what happens when fewer stories are made"
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, section Samarbejde: De innovationer, der er svære at løfte alene"
  - id: root-marconi-2026
    resource: "Marconi, F. (2026) Who Will Monetize Truth? A Thesis for the Future of the Information Business"
---

# The knowledge freezer

AI platforms increasingly rely on trusted news content to understand and respond to real-time events, which indicates that the AI companies need some of the journalistic content. Agreements giving AI assistants access to news in real time have been seen as a structural shift in the AI ecosystem.

A darker version of that relationship of dependence was mapped in 2026 under the heading "the knowledge freezer". The risk is that fewer journalistic stories are made, because news media are pressed by AI. Over time AI can therefore not draw on as many news stories within certain fields, so the quality of AI also falls, in a self-reinforcing negative loop.

## What it challenges

- The dependence runs both ways: AI needs the journalistic content it is displacing.
- A fall in the volume of journalism in a field does not only hurt the media producing it; it degrades every AI answer that relies on that field.

<!-- /context/signals/the-zero-click-era.md -->

---
type: Signal
title: The zero-click era
description: AI answers replace search and links, so traffic to news sites falls steeply and referral from outside can no longer be assumed in any plan.
status: stable
use_when: "a plan relies on search or social referrals still delivering audience when it pays off, rather than on a direct relationship with users who choose to come"
stale_after: 2028-01-01T00:00:00Z
sources:
  - id: root-mosbech-2026
    resource: "Mosbech, H. (2026) Eksistentiel innovation: Journalistikkens fremtid i den flydende æra, Center for Journalistik, SDU, sections Det eksistentielle pres and Skab dybere fællesskaber"
---

# The zero-click era

The use of AI products such as chatbots to get knowledge and information has exploded in recent years. To some extent it already replaces functions that news media could previously fill, especially among the young, of whom sixteen per cent use AI for news. At the same time AI-generated search results and similar products fundamentally change how we find and use information: a movement away from search and links towards a single interface where we get answers to our questions.

The so-called zero-click era already appears readable in drastically falling traffic to news media. In the United States, half of the fifty largest news sites lost a fifth of their traffic in the year to April 2026. Some lost half or more, and dominant national and international news brands also bled traffic.

Figure: a bubble chart of the fifty largest news sites, showing year-on-year percentage change in web traffic to April 2026, with bubble size as monthly visits. A few sites appear as growing bubbles at the far left, one at around plus one hundred and fifty per cent and a newsletter platform at around plus twenty-five per cent; the rest of the field is dominated by falling bubbles following a downward trend line towards about minus thirty per cent, with the marked national and international brands in the range of about minus five to minus twenty per cent.

The development points to the structure of the internet being under radical change.

## Wider effects

- AI-generated overviews make errors in roughly one answer in ten, according to one analysis.
- Far fewer people visit a national public health information site than a year earlier, because they get their answers directly from AI, so an information crisis can become a health crisis.

## What it means for news media

Building community is also about the less lofty task of building a direct relationship to the user: being a destination for users and building a direct relation, rather than merely becoming a supplier of content for others. Results have been achieved by working from the assumption of receiving zero search traffic, so that everything comes to depend on building a direct relationship. Without traffic from outside, the question has to be asked very directly: why should people come to you?
